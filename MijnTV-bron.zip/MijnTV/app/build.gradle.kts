plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "nl.michel.iptv"
    compileSdk = 35

    defaultConfig {
        applicationId = "nl.michel.iptv"
        minSdk = 21
        targetSdk = 34
        versionCode = 33
        versionName = "1.33"
    }

    signingConfigs {
        create("vast") {
            storeFile = file("mijntv.keystore")
            storePassword = "mijntv123"
            keyAlias = "mijntv"
            keyPassword = "mijntv123"
        }
    }

    buildFeatures { buildConfig = true }

    // Twee versies: "michel" (alles) en "vrienden" (algemeen, ingebouwde TMDB-sleutel, zonder Trakt/Nuvio)
    flavorDimensions += "versie"
    productFlavors {
        create("michel") {
            dimension = "versie"
            buildConfigField("boolean", "HAS_TRAKT", "true")
            buildConfigField("boolean", "HAS_NUVIO", "true")
            buildConfigField("boolean", "HAS_ENIGMA", "true")
            buildConfigField("String", "TMDB_KEY", "\"\"")
            resValue("string", "app_name", "MijnTV")
        }
        create("vrienden") {
            dimension = "versie"
            applicationIdSuffix = ".vrienden"
            buildConfigField("boolean", "HAS_TRAKT", "false")
            buildConfigField("boolean", "HAS_NUVIO", "false")
            buildConfigField("boolean", "HAS_ENIGMA", "false")
            // Vrienden vullen hun eigen (gratis) TMDB-sleutel in
            buildConfigField("String", "TMDB_KEY", "\"\"")
            resValue("string", "app_name", "MijnTV")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("vast")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.core:core:1.13.1")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("com.github.bumptech.glide:glide:4.16.0")
}
