plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "nl.michel.iptv"
    compileSdk = 35

    defaultConfig {
        applicationId = "nl.michel.iptv"
        minSdk = 21
        targetSdk = 34
        versionCode = 13
        versionName = "1.13"
    }

    signingConfigs {
        create("vast") {
            storeFile = file("mijntv.keystore")
            storePassword = "mijntv123"
            keyAlias = "mijntv"
            keyPassword = "mijntv123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("vast")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.core:core:1.13.1")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("com.github.bumptech.glide:glide:4.16.0")
}
