plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "nl.michel.iptv"
    compileSdk = 35

    defaultConfig {
        applicationId = "nl.michel.iptv"
        minSdk = 21
        targetSdk = 34
        versionCode = 111
        versionName = "1.11"
        // Alleen ARM (Shield, Android TV-boxen): houdt de app met VLC compact
        // Google Drive-koppeling (cloud-back-up); komt uit GitHub Secrets, staat niet in de code
        buildConfigField("String", "GOOGLE_CLIENT_ID", "\"${System.getenv("GOOGLE_CLIENT_ID") ?: ""}\"")
        buildConfigField("String", "GOOGLE_CLIENT_SECRET", "\"${System.getenv("GOOGLE_CLIENT_SECRET") ?: ""}\"")
        // Voor updatemeldingen: de GitHub-repo waar de app gebouwd wordt (vult GitHub zelf in)
        buildConfigField("String", "GITHUB_REPO", "\"${System.getenv("GITHUB_REPOSITORY") ?: ""}\"")
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    signingConfigs {
        create("vast") {
            storeFile = file("mijntv.keystore")
            storePassword = "mijntv123"
            keyAlias = "mijntv"
            keyPassword = "mijntv123"
        }
    }

    buildFeatures { buildConfig = true }

    // Twee versies: "michel" (alles) en "public" (algemeen, zonder Trakt/Nuvio/Enigma2)
    flavorDimensions += "versie"
    productFlavors {
        create("michel") {
            dimension = "versie"
            buildConfigField("boolean", "HAS_TRAKT", "true")
            buildConfigField("boolean", "HAS_NUVIO", "true")
            buildConfigField("boolean", "HAS_ENIGMA", "true")
            buildConfigField("String", "TMDB_KEY", "\"\"")
            resValue("string", "app_name", "MijnTV")
        }
        create("public") {
            dimension = "versie"
            applicationIdSuffix = ".public"
            buildConfigField("boolean", "HAS_TRAKT", "false")
            buildConfigField("boolean", "HAS_NUVIO", "false")
            buildConfigField("boolean", "HAS_ENIGMA", "false")
            // Vrienden vullen hun eigen (gratis) TMDB-sleutel in
            buildConfigField("String", "TMDB_KEY", "\"\"")
            resValue("string", "app_name", "MijnTV Public")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("vast")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.core:core:1.13.1")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("com.github.bumptech.glide:glide:4.16.0")
    // VLC als tweede speler-engine (zelfde als DreamPlayer)
    implementation("org.videolan.android:libvlc-all:3.6.0")
}
