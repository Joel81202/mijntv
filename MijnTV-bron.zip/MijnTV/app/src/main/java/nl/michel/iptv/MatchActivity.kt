package nl.michel.iptv

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Calendar
import java.util.Locale

/** Eén wedstrijd met alle zenders waarop hij te zien is. */
data class Match(
    val start: Long,
    val end: Long,
    val home: String,
    val away: String,
    val competition: String,
    val channels: List<Pair<Item, Program>>,
    /** "pre", "in" (bezig) of "post" (afgelopen); leeg = alleen uit de tv-gids bekend */
    val state: String = "",
    val score: String = "",
    val clock: String = ""
)

/** Wedstrijd uit het speelschema (ESPN), nog zonder zender. */
data class Fixture(
    val start: Long, val home: List<String>, val away: List<String>,
    val homeName: String, val awayName: String, val competition: String,
    val state: String, val score: String, val clock: String
)

/** Zoekt voetbalwedstrijden in de tv-gids van al je zenders. */
object MatchCenter {
    private val competitions = linkedMapOf(
        "champions league" to "Champions League", "europa league" to "Europa League",
        "conference league" to "Conference League", "eredivisie" to "Eredivisie",
        "keuken kampioen" to "Keuken Kampioen Divisie", "kkd" to "Keuken Kampioen Divisie",
        "eerste divisie" to "Eerste Divisie", "knvb" to "KNVB Beker", "toto knvb" to "KNVB Beker",
        "premier league" to "Premier League", "fa cup" to "FA Cup", "carabao" to "Carabao Cup",
        "efl" to "EFL", "championship" to "Championship", "bundesliga" to "Bundesliga",
        "dfb" to "DFB-Pokal", "laliga" to "LaLiga", "la liga" to "LaLiga", "copa del rey" to "Copa del Rey",
        "serie a" to "Serie A", "coppa italia" to "Coppa Italia", "ligue 1" to "Ligue 1",
        "jupiler pro league" to "Jupiler Pro League", "pro league" to "Jupiler Pro League",
        "nations league" to "Nations League", "wk-kwalificatie" to "WK-kwalificatie",
        "ek-kwalificatie" to "EK-kwalificatie", "world cup" to "WK", "oranje" to "Oranje",
        "supercup" to "Supercup", "super cup" to "Supercup", "mls" to "MLS", "saudi pro" to "Saudi Pro League",
        "eredivisie vrouwen" to "Eredivisie Vrouwen", "voetbal" to "Voetbal", "football" to "Voetbal", "soccer" to "Voetbal"
    )

    private val otherSports = listOf(
        "tennis", "darts", "formule", "formula", " f1", "f1 ", "wielren", "cycling", "nba", "nfl", "nhl", "ijshockey",
        "hockey", "handbal", "basketbal", "basketball", "volleybal", "rugby", "snooker", "golf", "ufc", "boks",
        "boxing", "schaats", "mma", "motogp", "padel", "korfbal", "baseball", "cricket", "atletiek", "wwe"
    )

    private val notLive = listOf(
        "samenvatting", "studio", "voorbeschouwing", "nabeschouwing", "highlights", "magazine", "review",
        "goals", "analyse", "praat", "talk", "herhaling", "(h)", "replay", "classics", "terugblik", "preview"
    )

    private val sportChannel = Regex("sport|espn|viaplay|dazn|bein|canal\\+|tnt|sky|ziggo|eleven|arena|setanta|premier", RegexOption.IGNORE_CASE)

    /** "Eredivisie: Ajax - PSV", "Live: Arsenal v Chelsea", "Feyenoord – AZ (live)" */
    private val matchRe = Regex(
        "^(?:[^:]{2,40}:\\s*)?(?:live:?\\s*)?([\\p{L}0-9 .'&/-]{2,32}?)\\s+(?:-|–|—|vs\\.?|v\\.?|tegen)\\s+([\\p{L}0-9 .'&/-]{2,32}?)\\s*(?:\\(.*\\))?\\s*$",
        RegexOption.IGNORE_CASE
    )

    private fun norm(s: String) = s.lowercase(Locale.ROOT).filter { it.isLetterOrDigit() }

    // ---------- Speelschema van ESPN (geen sleutel nodig) ----------

    private val leagues = linkedMapOf(
        "ned.1" to "Eredivisie", "ned.2" to "Keuken Kampioen Divisie", "ned.cup" to "KNVB Beker",
        "uefa.champions" to "Champions League", "uefa.europa" to "Europa League", "uefa.europa.conf" to "Conference League",
        "eng.1" to "Premier League", "eng.fa" to "FA Cup", "eng.league_cup" to "Carabao Cup",
        "esp.1" to "LaLiga", "ger.1" to "Bundesliga", "ita.1" to "Serie A", "fra.1" to "Ligue 1",
        "bel.1" to "Jupiler Pro League", "uefa.nations" to "Nations League", "fifa.worldq.uefa" to "WK-kwalificatie",
        "uefa.euroq" to "EK-kwalificatie", "fifa.world" to "WK", "uefa.euro" to "EK"
    )

    private val generic = setOf(
        "fc", "sc", "afc", "cf", "ac", "as", "ss", "sv", "vv", "club", "city", "united", "utd", "real", "sporting",
        "de", "the", "and", "van", "fk", "sk", "bk", "if", "cd", "ud", "rc", "ca", "sd", "us", "1", "04", "05", "09",
        "rotterdam", "amsterdam", "athletic", "atletico", "borussia", "olympique", "stade", "hotspur", "wanderers", "rovers"
    )

    private fun tokens(vararg names: String): List<String> {
        val words = names.flatMap { n -> n.lowercase(Locale.ROOT).split(Regex("[^\\p{L}0-9]+")) }
            .filter { it.length >= 3 && it !in generic }
        // Korte clubnamen zoals "AZ" of "PSV" als geheel meenemen
        val short = names.map { it.lowercase(Locale.ROOT).trim() }.filter { it.length in 2..4 && it.all { c -> c.isLetter() } }
        return (words + short).distinct()
    }

    /** Woord in tekst; korte namen alleen als los woord ("az" niet in "plaza"). */
    private val wordRe = java.util.concurrent.ConcurrentHashMap<String, Regex>()

    private fun has(text: String, tok: String): Boolean {
        if (!text.contains(tok)) return false
        if (tok.length > 4) return true
        val re = wordRe.getOrPut(tok) { Regex("(^|[^\\p{L}0-9])" + Regex.escape(tok) + "($|[^\\p{L}0-9])") }
        return re.containsMatchIn(text)
    }

    private fun fetchLeague(code: String, label: String, range: String): List<Fixture> {
        val url = "https://site.api.espn.com/apis/site/v2/sports/soccer/$code/scoreboard?dates=$range&limit=200"
        val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 12000
        c.setRequestProperty("User-Agent", "MijnTV")
        try {
            if (c.responseCode !in 200..299) return emptyList()
            val o = org.json.JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val out = ArrayList<Fixture>()
            val iso = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'", Locale.ROOT).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
            val events = o.optJSONArray("events") ?: return emptyList()
            for (i in 0 until events.length()) {
                val e = events.getJSONObject(i)
                val start = runCatching { iso.parse(e.optString("date"))!!.time }.getOrNull() ?: continue
                val comp = e.optJSONArray("competitions")?.optJSONObject(0) ?: continue
                val teams = comp.optJSONArray("competitors") ?: continue
                var h: org.json.JSONObject? = null; var a: org.json.JSONObject? = null
                for (j in 0 until teams.length()) {
                    val t = teams.getJSONObject(j)
                    if (t.optString("homeAway") == "home") h = t else a = t
                }
                if (h == null || a == null) continue
                val ht = h.optJSONObject("team") ?: continue
                val at = a.optJSONObject("team") ?: continue
                val st = (comp.optJSONObject("status") ?: e.optJSONObject("status"))?.optJSONObject("type")
                val state = st?.optString("state") ?: "pre"
                val score = if (state == "pre") "" else "${h.optString("score")} – ${a.optString("score")}"
                val clock = (comp.optJSONObject("status") ?: e.optJSONObject("status"))?.optString("displayClock") ?: ""
                out.add(
                    Fixture(
                        start,
                        tokens(ht.optString("displayName"), ht.optString("shortDisplayName"), ht.optString("name")),
                        tokens(at.optString("displayName"), at.optString("shortDisplayName"), at.optString("name")),
                        ht.optString("shortDisplayName").ifEmpty { ht.optString("displayName") },
                        at.optString("shortDisplayName").ifEmpty { at.optString("displayName") },
                        label, state, score, clock
                    )
                )
            }
            return out
        } finally { c.disconnect() }
    }

    fun fixtures(now: Long = System.currentTimeMillis()): List<Fixture> {
        val fmt = java.text.SimpleDateFormat("yyyyMMdd", Locale.ROOT).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
        val range = fmt.format(java.util.Date(now - 86_400_000L)) + "-" + fmt.format(java.util.Date(now + 6 * 86_400_000L))
        val pool = java.util.concurrent.Executors.newFixedThreadPool(6)
        try {
            val futures = leagues.map { (code, label) -> pool.submit<List<Fixture>> { runCatching { fetchLeague(code, label, range) }.getOrDefault(emptyList()) } }
            return futures.flatMap { runCatching { it.get(20, java.util.concurrent.TimeUnit.SECONDS) }.getOrDefault(emptyList()) }
        } finally { pool.shutdownNow() }
    }

    /** Speelschema + tv-gids: bij elke wedstrijd de zenders zoeken; aangevuld met wedstrijden die alleen in de gids staan. */
    fun build(channels: List<Item>, fixtures: List<Fixture>, now: Long = System.currentTimeMillis()): List<Match> {
        data class P(val ch: Item, val p: Program, val text: String)
        val from = now - 2 * 86_400_000L
        val until = now + 7 * 86_400_000L
        val progs = ArrayList<P>()
        for (ch in channels) for (p in Epg.programs(ch)) {
            if (p.end < from || p.start > until) continue
            progs.add(P(ch, p, (p.title + " " + p.desc.take(300)).lowercase(Locale.ROOT)))
        }
        progs.sortBy { it.p.start }
        val starts = LongArray(progs.size) { progs[it].p.start }
        val out = ArrayList<Match>()
        for (f in fixtures) {
            if (f.state == "post" && f.start < now - 30 * 3600_000L) continue
            val lo = java.util.Arrays.binarySearch(starts, f.start - 4 * 3600_000L).let { if (it < 0) -it - 1 else it }
            val hits = ArrayList<Pair<Item, Program>>()
            var i = lo
            while (i < progs.size && starts[i] <= f.start + 20 * 60_000L) {
                val x = progs[i]
                if (x.p.end >= f.start + 30 * 60_000L && f.home.any { has(x.text, it) } && f.away.any { has(x.text, it) } &&
                    notLive.none { x.p.title.lowercase(Locale.ROOT).contains(it) }
                ) hits.add(Pair(x.ch, x.p))
                i++
            }
            val chans = hits.distinctBy { it.first.favKey }
                .sortedWith(compareBy({ !Repo.isCurrent(it.first) }, { it.first.name.length }))
            out.add(Match(f.start, f.start + 110 * 60_000L, f.homeName, f.awayName, f.competition, chans, f.state, f.score, f.clock))
        }
        // Wedstrijden die alleen in de tv-gids staan (andere competities)
        for (m in find(channels, now)) {
            val known = fixtures.any { f ->
                Math.abs(f.start - m.start) < 3 * 3600_000L &&
                    f.home.any { has((m.home + " " + m.away).lowercase(Locale.ROOT), it) } &&
                    f.away.any { has((m.home + " " + m.away).lowercase(Locale.ROOT), it) }
            }
            if (!known) out.add(m)
        }
        return out.sortedBy { it.start }
    }

    fun find(channels: List<Item>, now: Long = System.currentTimeMillis()): List<Match> {
        val from = now - 3 * 3600_000L
        val until = now + 7 * 86_400_000L
        val found = ArrayList<Triple<Item, Program, Pair<String, String>>>()
        val compOf = HashMap<Program, String>()
        val catNames = Repo.liveCats.associate { it.id to it.name }
        for (ch in channels) {
            val cat = catNames[ch.categoryId] ?: ""
            val isSportCh = sportChannel.containsMatchIn(ch.name) || sportChannel.containsMatchIn(cat)
            for (p in Epg.programs(ch)) {
                if (p.end < from || p.start > until) continue
                val text = (p.title + " " + p.desc.take(200)).lowercase(Locale.ROOT)
                if (notLive.any { p.title.lowercase(Locale.ROOT).contains(it) }) continue
                if (p.end - p.start > 4 * 3600_000L || p.end - p.start < 60 * 60_000L) continue
                val m = matchRe.find(p.title.trim()) ?: continue
                val comp = competitions.entries.firstOrNull { text.contains(it.key) }?.value
                if (comp == null) {
                    if (!isSportCh || otherSports.any { text.contains(it) }) continue
                } else if (otherSports.any { p.title.lowercase(Locale.ROOT).contains(it) }) continue
                val home = m.groupValues[1].trim()
                val away = m.groupValues[2].trim()
                if (home.any { it.isDigit() } && home.length < 4) continue
                if (norm(home).length < 2 || norm(away).length < 2) continue
                val prefix = p.title.substringBefore(":", "").trim()
                compOf[p] = comp ?: prefix.takeIf { it.length in 3..30 && !it.equals("live", true) } ?: "Voetbal"
                found.add(Triple(ch, p, Pair(home, away)))
            }
        }
        // Zelfde wedstrijd op meerdere zenders samenvoegen
        val groups = LinkedHashMap<String, MutableList<Triple<Item, Program, Pair<String, String>>>>()
        for (f in found.sortedBy { it.second.start }) {
            val key = norm(f.third.first) + "|" + norm(f.third.second)
            val existing = groups.keys.firstOrNull { k ->
                k.startsWith("$key#") && Math.abs(k.substringAfter("#").toLong() - f.second.start) < 45 * 60_000L
            }
            groups.getOrPut(existing ?: "$key#${f.second.start}") { ArrayList() }.add(f)
        }
        return groups.values.map { list ->
            val first = list.minByOrNull { it.second.start }!!
            val chans = list.distinctBy { it.first.favKey }
                .sortedWith(compareBy({ !Repo.isCurrent(it.first) }, { it.first.name.length }))
                .map { Pair(it.first, it.second) }
            Match(first.second.start, first.second.end, first.third.first, first.third.second, compOf[first.second] ?: "Voetbal", chans)
        }.sortedBy { it.start }
    }
}

class MatchActivity : AppCompatActivity() {
    companion object {
        /** Speelschema blijft even bewaard (scheelt laden bij opnieuw openen). */
        private var cache: List<Fixture>? = null
        private var cacheTime = 0L
        var fixtureCache: List<Fixture>?
            get() = if (System.currentTimeMillis() - cacheTime < 10 * 60_000L) cache else null
            set(v) { cache = v; cacheTime = System.currentTimeMillis() }
    }

    private lateinit var list: RecyclerView
    private lateinit var status: TextView
    private lateinit var empty: TextView
    private val adapter = MatchAdapter()
    private val epgListener: () -> Unit = { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_match)
        list = findViewById(R.id.matchList)
        status = findViewById(R.id.matchStatus)
        empty = findViewById(R.id.matchEmpty)
        list.layoutManager = LinearLayoutManager(this)
        list.itemAnimator = null
        list.adapter = adapter
        Epg.addListener(epgListener)
        Epg.load()
        refresh()
    }

    override fun onDestroy() {
        Epg.removeListener(epgListener)
        super.onDestroy()
    }

    private fun dayStart(ms: Long) = Calendar.getInstance().apply {
        timeInMillis = ms
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun refresh() {
        status.text = if (Epg.loaded) "Speelschema + tv-gids van al je zenders" else "Tv-gids wordt geladen… (zenders volgen)"
        val channels = Repo.live.toList()
        Bg.go({
            val fx = fixtureCache ?: MatchCenter.fixtures().also { if (it.isNotEmpty()) fixtureCache = it }
            MatchCenter.build(channels, fx)
        }) { r ->
            if (isFinishing) return@go
            val matches = r.getOrNull().orEmpty()
            val now = System.currentTimeMillis()
            val rows = ArrayList<Any>()
            fun isLive(m: Match) = if (m.state.isNotEmpty()) m.state == "in" else m.start <= now && m.end > now
            val live = matches.filter { isLive(it) }
            if (live.isNotEmpty()) { rows.add("🔴  Nu live"); rows.addAll(live) }
            matches.filter { !isLive(it) && (it.start > now || it.state == "post") && it.start > dayStart(now) }
                .groupBy { dayStart(it.start) }.toSortedMap().forEach { (d, ms) ->
                val label = Epg.day(d)
                rows.add(if (label == "Vandaag" || label == "Morgen") label else label.replaceFirstChar { it.uppercase() })
                rows.addAll(ms)
            }
            val firstFocus = list.hasFocus()
            adapter.rows = rows
            adapter.notifyDataSetChanged()
            empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
            empty.text = if (Epg.loaded) "Geen voetbalwedstrijden gevonden voor de komende dagen"
            else "Tv-gids wordt geladen…"
            if (!firstFocus) list.post {
                val i = rows.indexOfFirst { it is Match }
                if (i >= 0) list.findViewHolderForAdapterPosition(i)?.itemView?.requestFocus()
            }
        }
    }

    private fun open(m: Match) {
        if (m.channels.isEmpty()) {
            Toast.makeText(this, "Geen zender gevonden in je tv-gids voor deze wedstrijd", Toast.LENGTH_LONG).show()
            return
        }
        if (m.channels.size == 1) { watch(m, m.channels[0]); return }
        val labels = m.channels.map { (ch, _) ->
            (if (Repo.apis.size > 1) (Repo.names[ch.src] ?: "") + "  ·  " else "") + ch.name as CharSequence
        }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("${m.home} – ${m.away}")
            .setItems(labels) { _, which -> watch(m, m.channels[which]) }
            .show()
    }

    private fun watch(m: Match, pick: Pair<Item, Program>) {
        val (ch, p) = pick
        val now = System.currentTimeMillis()
        when {
            p.start <= now + 10 * 60_000L && p.end > now -> {
                PlayQueue.set(m.channels.map { it.first }, ch)
                startActivity(Intent(this, PlayerActivity::class.java))
            }
            p.end <= now && Epg.canCatchup(ch, p, now) -> {
                val item = Epg.catchupItem(ch, p)
                PlayQueue.set(listOf(item), item)
                startActivity(Intent(this, PlayerActivity::class.java))
            }
            p.start > now -> Toast.makeText(this, "Begint ${Epg.day(p.start).lowercase()} om ${Epg.time(p.start)} op ${ch.name}", Toast.LENGTH_LONG).show()
            else -> Toast.makeText(this, "Deze wedstrijd is afgelopen", Toast.LENGTH_SHORT).show()
        }
    }

    inner class MatchAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        var rows: List<Any> = emptyList()

        inner class DayVH(v: View) : RecyclerView.ViewHolder(v) { val day: TextView = v.findViewById(R.id.mDay) }
        inner class MatchVH(v: View) : RecyclerView.ViewHolder(v) {
            val time: TextView = v.findViewById(R.id.mTime)
            val live: TextView = v.findViewById(R.id.mLive)
            val teams: TextView = v.findViewById(R.id.mTeams)
            val info: TextView = v.findViewById(R.id.mInfo)
        }

        override fun getItemCount() = rows.size
        override fun getItemViewType(position: Int) = if (rows[position] is Match) 1 else 0

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val inf = LayoutInflater.from(parent.context)
            return if (viewType == 1) MatchVH(inf.inflate(R.layout.item_match, parent, false))
            else DayVH(inf.inflate(R.layout.item_match_day, parent, false))
        }

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
            val row = rows[position]
            if (h is DayVH) { h.day.text = row as String; return }
            val m = row as Match
            h as MatchVH
            val now = System.currentTimeMillis()
            val live = if (m.state.isNotEmpty()) m.state == "in" else m.start <= now && m.end > now
            h.time.text = when {
                m.state == "post" -> "Einde"
                live && m.clock.isNotEmpty() -> m.clock
                else -> Epg.time(m.start)
            }
            h.live.visibility = if (live) View.VISIBLE else View.GONE
            h.teams.text = if (m.score.isNotEmpty()) "${m.home}   ${m.score}   ${m.away}" else "${m.home}  –  ${m.away}"
            val names = m.channels.map { it.first.name }.distinct()
            val shown = if (names.isEmpty()) "zender onbekend"
                else names.take(3).joinToString(", ") + if (names.size > 3) "  +${names.size - 3}" else ""
            h.info.text = "${m.competition}   ·   📺 $shown"
            h.itemView.alpha = if (m.state == "post" && names.isEmpty()) 0.6f else 1f
            h.itemView.setOnClickListener {
                val i = h.bindingAdapterPosition
                if (i != RecyclerView.NO_POSITION) (rows[i] as? Match)?.let { open(it) }
            }
        }
    }
}
