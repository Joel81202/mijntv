package nl.michel.iptv

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

enum class Type { LIVE, MOVIE, SERIES, EPISODE, CATCHUP }

data class Category(val id: String, val name: String)

data class Item(
    val id: String,
    val name: String,
    val icon: String,
    val categoryId: String,
    val type: Type,
    val ext: String = "",
    val plot: String = "",
    val rating: String = "",
    val year: String = "",
    val backdrop: String = "",
    val added: Long = 0L,
    val num: String = "",
    val epg: String = "",
    val tmdb: String = "",
    val duration: String = "",
    val archive: Int = 0,
    val start: Long = 0L,
    val durationMin: Int = 0
) {
    val favKey: String get() = "${type.name}:$id"
}

data class EpgEntry(val title: String, val start: Long, val end: Long, val desc: String)

data class Season(val number: String, val episodes: List<Item>)

data class Details(
    val plot: String,
    val year: String,
    val rating: String,
    val genre: String,
    val duration: String,
    val backdrop: String,
    val seasons: List<Season> = emptyList(),
    val cast: String = "",
    val director: String = ""
)

private fun backdropOf(o: JSONObject): String {
    val arr = o.optJSONArray("backdrop_path")
    if (arr != null) return if (arr.length() > 0) arr.optString(0, "") else ""
    return o.s("backdrop_path")
}

/** "00:42:10", "2530" (sec) of "42" (min) -> "42 min" */
fun fmtDuration(raw: String): String {
    if (raw.isEmpty()) return ""
    val mins = if (raw.contains(":")) {
        val p = raw.split(":").mapNotNull { it.trim().toIntOrNull() }
        when (p.size) {
            3 -> p[0] * 60 + p[1]
            2 -> p[0]
            else -> 0
        }
    } else {
        val n = raw.toIntOrNull() ?: 0
        if (n > 300) n / 60 else n
    }
    if (mins <= 0) return ""
    return if (mins >= 60) "${mins / 60}u ${mins % 60}m" else "$mins min"
}

private fun yearOf(o: JSONObject): String {
    for (k in listOf("releaseDate", "releasedate", "release_date", "year")) {
        val v = o.s(k)
        if (v.length >= 4) return v.take(4)
    }
    return ""
}

fun JSONObject.s(key: String): String = if (!has(key) || isNull(key)) "" else optString(key, "")

fun JSONArray.objects(): List<JSONObject> = (0 until length()).mapNotNull { optJSONObject(it) }

private fun parseArray(text: String): JSONArray {
    val t = text.trim()
    return if (t.startsWith("[")) JSONArray(t) else JSONArray()
}

private fun b64(s: String): String = try {
    String(Base64.decode(s, Base64.DEFAULT), Charsets.UTF_8)
} catch (e: Exception) {
    s
}

object Http {
    fun get(address: String, headers: Map<String, String> = emptyMap()): String {
        var url = URL(address)
        repeat(6) {
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 90000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", Xtream.UA)
            for ((k, v) in headers) c.setRequestProperty(k, v)
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc == null) throw IOException("Ongeldige doorverwijzing")
                url = URL(url, loc)
            } else if (code !in 200..299) {
                c.disconnect()
                throw IOException("Server gaf foutcode $code")
            } else {
                val body = c.inputStream.bufferedReader(Charsets.UTF_8).use { r -> r.readText() }
                c.disconnect()
                return body
            }
        }
        throw IOException("Te veel doorverwijzingen")
    }
}

class Xtream(server: String, private val user: String, private val pass: String, val kind: String = "xtream") {

    /** true = Vu+ / Enigma2-ontvanger via OpenWebif in plaats van een IPTV-provider. */
    val isEnigma: Boolean get() = kind == "enigma2"

    val base: String = normalize(server)

    private val e2Auth: Map<String, String>
        get() = if (isEnigma && user.isNotEmpty()) mapOf(
            "Authorization" to "Basic " + Base64.encodeToString("$user:$pass".toByteArray(), Base64.NO_WRAP)
        ) else emptyMap()

    /** Extra headers voor de videostream (inloggen op de Vu+). */
    fun streamHeaders(): Map<String, String> = e2Auth

    private fun e2(path: String): JSONObject = JSONObject(Http.get(base + path, e2Auth))

    private fun e2enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun e2Host(): String = runCatching { URL(base).host }.getOrDefault(base.removePrefix("http://"))

    private fun picon(sref: String): String =
        "$base/picon/" + sref.trimEnd(':').replace(':', '_') + ".png"

    private fun e2Events(o: JSONObject): List<EpgEntry> =
        o.optJSONArray("events")?.objects()?.mapNotNull { e ->
            val begin = e.s("begin_timestamp").toLongOrNull() ?: return@mapNotNull null
            val dur = e.s("duration_sec").toLongOrNull() ?: 0L
            if (begin <= 0 || dur <= 0) return@mapNotNull null
            EpgEntry(e.s("title"), begin, begin + dur, e.s("longdesc").ifEmpty { e.s("shortdesc") })
        }.orEmpty()

    /** Nu/straks voor alle zenders van een bouquet in één keer: sref -> programma's. */
    fun bouquetNowNext(bouquetRef: String): Map<String, List<EpgEntry>> {
        val o = e2("/api/epgnownext?bRef=" + e2enc(bouquetRef))
        val map = HashMap<String, MutableList<EpgEntry>>()
        o.optJSONArray("events")?.objects()?.forEach { e ->
            val sref = e.s("sref").ifEmpty { e.s("ref") }
            val begin = e.s("begin_timestamp").toLongOrNull() ?: return@forEach
            val dur = e.s("duration_sec").toLongOrNull() ?: 0L
            if (sref.isEmpty() || begin <= 0 || dur <= 0) return@forEach
            map.getOrPut(sref) { ArrayList() }
                .add(EpgEntry(e.s("title"), begin, begin + dur, e.s("longdesc").ifEmpty { e.s("shortdesc") }))
        }
        return map
    }

    companion object {
        const val UA = "Mozilla/5.0 (Linux; Android 11) MijnTV/1.0"

        fun normalize(server: String): String {
            if (!server.contains("/") && !server.contains("player_api") && server.count { it == '.' } == 3 && !server.startsWith("http")) {
                return "http://" + server.trim().trimEnd('/')
            }
            var b = server.trim().trimEnd('/')
            if (b.endsWith("/player_api.php")) b = b.removeSuffix("/player_api.php")
            if (b.endsWith("/get.php")) b = b.removeSuffix("/get.php")
            if (!b.startsWith("http://") && !b.startsWith("https://")) b = "http://$b"
            return b
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun api(action: String?, extra: String = ""): String {
        val sb = StringBuilder()
        sb.append(base).append("/player_api.php?username=").append(enc(user))
            .append("&password=").append(enc(pass))
        if (action != null) sb.append("&action=").append(action)
        sb.append(extra)
        return Http.get(sb.toString())
    }

    /** Tijdzone van de server, nodig voor terugkijken. */
    var serverTz: String = ""

    fun login(): Boolean {
        if (isEnigma) {
            val o = e2("/api/statusinfo")
            return o.length() > 0
        }
        val o = JSONObject(api(null))
        o.optJSONObject("server_info")?.s("timezone")?.let { if (it.isNotEmpty()) serverTz = it }
        val info = o.optJSONObject("user_info") ?: return false
        return info.s("auth") == "1"
    }

    /** Volledige gids van één zender, inclusief uitzendingen uit het archief. */
    fun fullEpg(streamId: String): List<EpgEntry> {
        if (isEnigma) return shortEpg(streamId)
        val o = JSONObject(api("get_simple_data_table", "&stream_id=" + enc(streamId)))
        val arr = o.optJSONArray("epg_listings") ?: return emptyList()
        return arr.objects().map {
            EpgEntry(
                b64(it.s("title")),
                it.s("start_timestamp").toLongOrNull() ?: 0L,
                it.s("stop_timestamp").toLongOrNull() ?: 0L,
                b64(it.s("description"))
            )
        }
    }

    fun categories(action: String): List<Category> {
        if (isEnigma) {
            if (action != "get_live_categories") return emptyList()
            return e2("/api/getservices").optJSONArray("services")?.objects()?.map {
                Category(it.s("servicereference"), it.s("servicename"))
            }.orEmpty()
        }
        return parseArray(api(action)).objects().map { Category(it.s("category_id"), it.s("category_name")) }
    }

    fun liveStreams(): List<Item> {
        if (isEnigma) {
            val out = ArrayList<Item>()
            for (b in categories("get_live_categories")) {
                val services = runCatching { e2("/api/getservices?sRef=" + e2enc(b.id)) }.getOrNull()
                    ?.optJSONArray("services")?.objects().orEmpty()
                var n = 0
                for (sv in services) {
                    val ref = sv.s("servicereference")
                    // Scheidingsregels (markers) overslaan
                    if (ref.isEmpty() || ref.startsWith("1:64:") || ref.contains("FROM BOUQUET")) continue
                    n++
                    out.add(Item(ref, sv.s("servicename"), picon(ref), b.id, Type.LIVE, num = sv.s("pos").ifEmpty { n.toString() }))
                }
            }
            return out
        }
        return parseArray(api("get_live_streams")).objects().map {
            Item(
                it.s("stream_id"), it.s("name"), it.s("stream_icon"), it.s("category_id"), Type.LIVE,
                num = it.s("num"), epg = it.s("epg_channel_id"),
                archive = if (it.s("tv_archive") == "1") (it.s("tv_archive_duration").toIntOrNull() ?: 1).coerceAtLeast(1) else 0
            )
        }
    }

    fun vodStreams(): List<Item> = if (isEnigma) emptyList() else
        parseArray(api("get_vod_streams")).objects().map {
            Item(
                it.s("stream_id"), it.s("name"), it.s("stream_icon"), it.s("category_id"),
                Type.MOVIE, it.s("container_extension").ifEmpty { "mp4" },
                rating = it.s("rating"), year = yearOf(it),
                added = it.s("added").toLongOrNull() ?: 0L,
                tmdb = it.s("tmdb").ifEmpty { it.s("tmdb_id") }
            )
        }

    fun series(): List<Item> = if (isEnigma) emptyList() else
        parseArray(api("get_series")).objects().map {
            Item(
                it.s("series_id"), it.s("name"), it.s("cover"), it.s("category_id"), Type.SERIES,
                plot = it.s("plot"), rating = it.s("rating"), year = yearOf(it),
                backdrop = backdropOf(it), added = it.s("last_modified").toLongOrNull() ?: 0L,
                tmdb = it.s("tmdb").ifEmpty { it.s("tmdb_id") }
            )
        }

    fun vodInfo(vodId: String): Details {
        val o = JSONObject(api("get_vod_info", "&vod_id=" + enc(vodId)))
        val info = o.optJSONObject("info") ?: JSONObject()
        return Details(
            info.s("plot").ifEmpty { info.s("description") },
            yearOf(info), info.s("rating"), info.s("genre"), info.s("duration"), backdropOf(info),
            cast = info.s("cast").ifEmpty { info.s("actors") }, director = info.s("director")
        )
    }

    fun seriesInfo(seriesId: String): Details {
        val o = JSONObject(api("get_series_info", "&series_id=" + enc(seriesId)))
        val info = o.optJSONObject("info") ?: JSONObject()
        val seasons = ArrayList<Season>()
        val eps = o.optJSONObject("episodes")
        if (eps != null) {
            val keys = eps.keys().asSequence().toList().sortedBy { it.toIntOrNull() ?: 9999 }
            for (k in keys) {
                val arr = eps.optJSONArray(k) ?: continue
                val list = arr.objects().map { e ->
                    val num = e.s("episode_num")
                    val ei = e.optJSONObject("info") ?: JSONObject()
                    Item(
                        e.s("id"), e.s("title").ifEmpty { "Aflevering $num" }, ei.s("movie_image"), k,
                        Type.EPISODE, e.s("container_extension").ifEmpty { "mp4" },
                        plot = ei.s("plot"), rating = ei.s("rating"), num = num,
                        duration = fmtDuration(ei.s("duration").ifEmpty { ei.s("duration_secs") })
                    )
                }
                seasons.add(Season(k, list))
            }
        }
        return Details(
            info.s("plot"), yearOf(info), info.s("rating"), info.s("genre"),
            info.s("episode_run_time"), backdropOf(info), seasons,
            cast = info.s("cast"), director = info.s("director")
        )
    }

    fun shortEpg(streamId: String): List<EpgEntry> {
        if (isEnigma) return e2Events(e2("/api/epgservice?sRef=" + e2enc(streamId)))
        val o = JSONObject(api("get_short_epg", "&stream_id=" + enc(streamId) + "&limit=4"))
        val arr = o.optJSONArray("epg_listings") ?: return emptyList()
        return arr.objects().map {
            EpgEntry(
                b64(it.s("title")),
                it.s("start_timestamp").toLongOrNull() ?: 0L,
                it.s("stop_timestamp").toLongOrNull() ?: 0L,
                b64(it.s("description"))
            )
        }
    }

    fun xmltvUrl(): String = "$base/xmltv.php?username=" + enc(user) + "&password=" + enc(pass)

    fun streamUrl(item: Item, hls: Boolean): String {
        val u = Uri.encode(user)
        val p = Uri.encode(pass)
        if (isEnigma && item.type == Type.LIVE) return "http://${e2Host()}:8001/" + item.id.replace(" ", "%20")
        return when (item.type) {
            Type.LIVE -> "$base/live/$u/$p/${item.id}.${if (hls) "m3u8" else "ts"}"
            Type.MOVIE -> "$base/movie/$u/$p/${item.id}.${item.ext}"
            Type.EPISODE -> "$base/series/$u/$p/${item.id}.${item.ext}"
            Type.SERIES -> ""
            Type.CATCHUP -> {
                val fmt = java.text.SimpleDateFormat("yyyy-MM-dd:HH-mm", java.util.Locale.US)
                if (serverTz.isNotEmpty()) fmt.timeZone = java.util.TimeZone.getTimeZone(serverTz)
                val start = fmt.format(java.util.Date(item.start))
                // hls = true betekent hier: het alternatieve adresformaat proberen
                if (!hls) "$base/timeshift/$u/$p/${item.durationMin}/$start/${item.id}.ts"
                else "$base/streaming/timeshift.php?username=$u&password=$p&stream=${item.id}&start=$start&duration=${item.durationMin}"
            }
        }
    }
}
