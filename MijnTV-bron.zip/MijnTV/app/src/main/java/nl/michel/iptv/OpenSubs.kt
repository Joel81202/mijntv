package nl.michel.iptv

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Ondertitels zoeken en downloaden via OpenSubtitles.com (met je eigen account). */
object OpenSubs {

    data class Sub(
        val fileId: String,
        val lang: String,
        val release: String,
        val downloads: Int,
        val hearingImpaired: Boolean,
        val machine: Boolean
    )

    private const val UA = "MijnTV v1.4"
    private var token = ""
    private var base = "api.opensubtitles.com"

    fun configured(prefs: Prefs) = prefs.osKey.isNotBlank()

    fun reset() {
        token = ""
        base = "api.opensubtitles.com"
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun request(prefs: Prefs, method: String, path: String, body: String? = null, auth: Boolean = false): JSONObject {
        val c = URL("https://$base/api/v1$path").openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("Api-Key", prefs.osKey.trim())
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept", "application/json")
        if (auth && token.isNotEmpty()) c.setRequestProperty("Authorization", "Bearer $token")
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code == 401) throw IOException("Inloggen bij OpenSubtitles mislukt: controleer API-sleutel, gebruikersnaam en wachtwoord")
            if (code == 406) throw IOException("Downloadlimiet voor vandaag bereikt")
            if (code == 429) throw IOException("Te veel verzoeken, probeer het zo opnieuw")
            if (code !in 200..299) {
                val msg = runCatching { JSONObject(text).s("message") }.getOrDefault("")
                throw IOException("OpenSubtitles fout $code ${msg}".trim())
            }
            return if (text.isBlank()) JSONObject() else JSONObject(text)
        } finally {
            c.disconnect()
        }
    }

    private fun login(prefs: Prefs) {
        if (token.isNotEmpty() || prefs.osUser.isBlank()) return
        val body = JSONObject().put("username", prefs.osUser).put("password", prefs.osPass).toString()
        val r = request(prefs, "POST", "/login", body)
        token = r.s("token")
        val b = r.s("base_url")
        if (b.isNotEmpty()) base = b.removePrefix("https://").removePrefix("http://").trimEnd('/')
    }

    /**
     * Zoeken voor een film of aflevering.
     * Bij een aflevering is [series] de serie en zitten seizoen/aflevering in het item.
     */
    fun search(prefs: Prefs, item: Item, series: Item?): List<Sub> {
        login(prefs)
        val langs = "en,nl"
        val q = StringBuilder("languages=$langs&order_by=download_count&order_direction=desc")
        if (item.type == Type.EPISODE && series != null) {
            val tmdb = Tmdb.cached(series)?.tmdbId ?: series.tmdb.takeIf { it.isNotEmpty() && it != "0" }
            if (tmdb != null) q.append("&parent_tmdb_id=").append(tmdb)
            else q.append("&query=").append(enc(Tmdb.cleanTitle(series.name).first)).append("&type=episode")
            q.append("&season_number=").append(item.categoryId.toIntOrNull() ?: 1)
            q.append("&episode_number=").append(item.num.toIntOrNull() ?: 1)
        } else {
            val tmdb = Tmdb.cached(item)?.tmdbId ?: item.tmdb.takeIf { it.isNotEmpty() && it != "0" }
            if (tmdb != null) q.append("&tmdb_id=").append(tmdb)
            else {
                val (title, year) = Tmdb.cleanTitle(item.name)
                q.append("&query=").append(enc(title)).append("&type=movie")
                if (year.isNotEmpty()) q.append("&year=").append(year)
            }
        }
        val r = request(prefs, "GET", "/subtitles?$q", auth = true)
        val list = r.optJSONArray("data")?.objects()?.mapNotNull { d ->
            val a = d.optJSONObject("attributes") ?: return@mapNotNull null
            val file = a.optJSONArray("files")?.optJSONObject(0) ?: return@mapNotNull null
            Sub(
                file.s("file_id"),
                a.s("language"),
                a.s("release").ifEmpty { file.s("file_name") },
                a.optInt("download_count", 0),
                a.optBoolean("hearing_impaired", false),
                a.optBoolean("machine_translated", false) || a.optBoolean("ai_translated", false)
            )
        }.orEmpty()
        // Nederlands eerst, dan Engels; binnen een taal de meest gedownloade eerst
        return list.sortedWith(compareBy<Sub> { if (it.lang == "nl") 0 else 1 }.thenByDescending { it.downloads })
    }

    /** Downloadt de ondertitel naar de app-opslag en geeft het bestand terug. */
    fun download(ctx: Context, prefs: Prefs, sub: Sub, item: Item): Pair<File, Int> {
        login(prefs)
        val r = request(prefs, "POST", "/download", JSONObject().put("file_id", sub.fileId.toLongOrNull() ?: 0L).toString(), auth = true)
        val link = r.s("link")
        if (link.isEmpty()) throw IOException("Geen downloadlink ontvangen")
        val remaining = r.optInt("remaining", -1)
        val c = URL(link).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.setRequestProperty("User-Agent", UA)
        val bytes = try {
            if (c.responseCode !in 200..299) throw IOException("Download mislukt (${c.responseCode})")
            c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
        val dir = File(ctx.filesDir, "subs").apply { mkdirs() }
        val safe = item.favKey.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val file = File(dir, "$safe.${sub.lang}.srt")
        file.writeBytes(bytes)
        return Pair(file, remaining)
    }
}
