package nl.michel.iptv

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

/** Gedeelde toestand van het gids-raster: welk tijdvenster en welke tijd geselecteerd is. */
object GuideState {
    const val WINDOW_MIN = 120
    const val STEP_MS = 30 * 60_000L
    var windowStart = 0L
    var selectedTime = 0L

    val windowEnd: Long get() = windowStart + WINDOW_MIN * 60_000L

    fun reset() {
        val now = System.currentTimeMillis()
        windowStart = now - (now % STEP_MS)
        selectedTime = now
    }
}

/** Tijdbalk boven het raster. */
class TimeHeaderView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#B3B3B3")
        textSize = 14f * ctx.resources.displayMetrics.scaledDensity
    }
    private val line = Paint().apply { color = Color.parseColor("#E50914") }
    private val left = dp(ctx, 220f).toFloat()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width - left
        if (w <= 0) return
        val pxPerMs = w / (GuideState.WINDOW_MIN * 60_000f)
        var t = GuideState.windowStart
        while (t < GuideState.windowEnd) {
            val x = left + (t - GuideState.windowStart) * pxPerMs
            canvas.drawText(Epg.time(t), x + 8, height * 0.68f, paint)
            t += GuideState.STEP_MS
        }
        val now = System.currentTimeMillis()
        if (now in GuideState.windowStart until GuideState.windowEnd) {
            val x = left + (now - GuideState.windowStart) * pxPerMs
            canvas.drawRect(x - 2, height - 8f, x + 2, height.toFloat(), line)
        }
    }
}

/** Eén rij programma's in het raster, zelf getekend voor snelheid. */
class EpgRowView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    interface Listener {
        fun onProgramSelected(row: EpgRowView, program: Program?)
        fun onWindowChanged()
        fun onPlay(row: EpgRowView)
    }

    var programs: List<Program> = emptyList()
        set(v) { field = v; selected = -1; invalidate() }
    var listener: Listener? = null
    var selected = -1
        private set

    private val density = ctx.resources.displayMetrics.density
    private val blockPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 15f * ctx.resources.displayMetrics.scaledDensity
        isFakeBoldText = true
    }
    private val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 12f * ctx.resources.displayMetrics.scaledDensity
    }
    private val nowLine = Paint().apply { color = Color.parseColor("#E50914") }
    private val rect = RectF()

    init {
        isFocusable = true
        isClickable = true
    }

    private fun xOf(t: Long): Float {
        val pxPerMs = width / (GuideState.WINDOW_MIN * 60_000f)
        return ((t - GuideState.windowStart) * pxPerMs).coerceIn(0f, width.toFloat())
    }

    /** Selecteer het programma dat op de gedeelde tijd loopt. */
    fun selectAtSharedTime() {
        if (programs.isEmpty()) {
            selected = -1
        } else {
            val t = GuideState.selectedTime.coerceAtLeast(GuideState.windowStart)
            var i = programs.indexOfFirst { it.start <= t && it.end > t }
            if (i < 0) i = programs.indexOfFirst { it.start >= t }
            if (i < 0) i = programs.size - 1
            selected = i
        }
        invalidate()
        listener?.onProgramSelected(this, programs.getOrNull(selected))
    }

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: android.graphics.Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        if (gainFocus) selectAtSharedTime() else invalidate()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (programs.isEmpty()) return shiftWindow(1)
                if (selected < programs.size - 1) {
                    selected++
                    val p = programs[selected]
                    while (p.start >= GuideState.windowEnd - GuideState.STEP_MS) {
                        GuideState.windowStart += GuideState.STEP_MS
                    }
                    GuideState.selectedTime = p.start.coerceAtLeast(GuideState.windowStart)
                    afterMove()
                }
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (programs.isEmpty()) return shiftWindow(-1)
                if (selected > 0) {
                    val now = System.currentTimeMillis()
                    val minStart = now - (now % GuideState.STEP_MS) - 2 * GuideState.STEP_MS
                    selected--
                    val p = programs[selected]
                    while (p.end <= GuideState.windowStart + 10 * 60_000L && GuideState.windowStart > minStart) {
                        GuideState.windowStart -= GuideState.STEP_MS
                    }
                    GuideState.selectedTime = p.start.coerceAtLeast(GuideState.windowStart)
                    afterMove()
                    return true
                }
                return false
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                listener?.onPlay(this)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun shiftWindow(dir: Int): Boolean {
        val now = System.currentTimeMillis()
        val base = now - (now % GuideState.STEP_MS)
        val target = GuideState.windowStart + dir * GuideState.STEP_MS
        if (target < base - 2 * GuideState.STEP_MS || target > base + 24 * 3600_000L) return dir > 0
        GuideState.windowStart = target
        GuideState.selectedTime = target
        listener?.onWindowChanged()
        return true
    }

    private fun afterMove() {
        invalidate()
        listener?.onWindowChanged()
        listener?.onProgramSelected(this, programs.getOrNull(selected))
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            val pxPerMs = width / (GuideState.WINDOW_MIN * 60_000f)
            val t = GuideState.windowStart + (event.x / pxPerMs).toLong()
            val i = programs.indexOfFirst { it.start <= t && it.end > t }
            if (i >= 0 && i == selected && hasFocus()) {
                listener?.onPlay(this)
            } else {
                GuideState.selectedTime = t
                requestFocus()
                selectAtSharedTime()
            }
            return true
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val gap = 2 * density
        val pad = 10 * density
        val h = height.toFloat()
        val now = System.currentTimeMillis()
        val focusedRow = isFocused

        if (programs.isEmpty()) {
            rect.set(0f, 0f, width.toFloat(), h)
            blockPaint.color = if (focusedRow) Color.WHITE else Color.parseColor("#1A1F27")
            canvas.drawRoundRect(rect, 4 * density, 4 * density, blockPaint)
            titlePaint.color = if (focusedRow) Color.BLACK else Color.parseColor("#9AA0A6")
            canvas.drawText("Geen programma-informatie", pad, h / 2 + titlePaint.textSize / 3, titlePaint)
            return
        }

        programs.forEachIndexed { i, p ->
            if (p.end <= GuideState.windowStart || p.start >= GuideState.windowEnd) return@forEachIndexed
            val x1 = xOf(p.start)
            val x2 = xOf(p.end)
            if (x2 - x1 < 2) return@forEachIndexed
            rect.set(x1, 0f, x2 - gap, h)
            val isSel = focusedRow && i == selected
            val airing = p.start <= now && p.end > now
            blockPaint.color = when {
                isSel -> Color.WHITE
                airing -> Color.parseColor("#2A313C")
                else -> Color.parseColor("#1A1F27")
            }
            canvas.drawRoundRect(rect, 4 * density, 4 * density, blockPaint)

            canvas.save()
            canvas.clipRect(x1 + pad, 0f, x2 - gap - 4 * density, h)
            titlePaint.color = if (isSel) Color.BLACK else Color.WHITE
            timePaint.color = if (isSel) Color.DKGRAY else Color.parseColor("#9AA0A6")
            canvas.drawText(p.title, x1 + pad, h * 0.45f, titlePaint)
            canvas.drawText("${Epg.time(p.start)} – ${Epg.time(p.end)}", x1 + pad, h * 0.80f, timePaint)
            canvas.restore()
        }

        if (now in GuideState.windowStart until GuideState.windowEnd) {
            val x = xOf(now)
            canvas.drawRect(x - 1.5f * density / 2, 0f, x + 1.5f * density / 2, h, nowLine)
        }
    }
}

/** Tv-gids raster (TiviMate-stijl). */
class GuideActivity : AppCompatActivity(), EpgRowView.Listener {

    private lateinit var prefs: Prefs
    private lateinit var rows: RecyclerView
    private lateinit var header: TimeHeaderView
    private lateinit var gTitle: TextView
    private lateinit var gTime: TextView
    private lateinit var gDesc: TextView
    private lateinit var gClock: TextView
    private var channels: List<Item> = emptyList()
    private val handler = Handler(Looper.getMainLooper())

    private val epgListener: () -> Unit = { rows.adapter?.notifyDataSetChanged() }
    private val ticker = object : Runnable {
        override fun run() {
            gClock.text = Epg.time(System.currentTimeMillis())
            redrawAll()
            handler.postDelayed(this, 30_000)
        }
    }

    inner class RowVH(v: View) : RecyclerView.ViewHolder(v) {
        val num: TextView = v.findViewById(R.id.gNum)
        val logo: ImageView = v.findViewById(R.id.gLogo)
        val name: TextView = v.findViewById(R.id.gName)
        val programs: EpgRowView = v.findViewById(R.id.gPrograms)
    }

    private val adapter = object : RecyclerView.Adapter<RowVH>() {
        override fun getItemCount(): Int = channels.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowVH {
            val vh = RowVH(LayoutInflater.from(parent.context).inflate(R.layout.item_guide_row, parent, false))
            vh.programs.listener = this@GuideActivity
            return vh
        }

        override fun onBindViewHolder(h: RowVH, position: Int) {
            val item = channels[position]
            h.num.text = channelNumber(item, position)
            h.name.text = item.name
            if (item.icon.isNotEmpty()) Glide.with(h.logo).load(item.icon).into(h.logo)
            else {
                Glide.with(h.logo).clear(h.logo); h.logo.setImageDrawable(null)
            }
            h.programs.tag = item
            h.programs.programs = Epg.programs(item)
            if (h.programs.programs.isEmpty()) {
                Epg.fetchShort(item) {
                    if (h.programs.tag == item) {
                        h.programs.programs = Epg.programs(item)
                        if (h.programs.isFocused) h.programs.selectAtSharedTime()
                    }
                }
            }
            if (h.programs.isFocused) h.programs.selectAtSharedTime()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Repo.liveLoaded || Repo.api == null) {
            finish()
            return
        }
        prefs = Prefs(this)
        setContentView(R.layout.activity_guide)
        rows = findViewById(R.id.guideRows)
        header = findViewById(R.id.timeHeader)
        gTitle = findViewById(R.id.gTitle)
        gTime = findViewById(R.id.gTime)
        gDesc = findViewById(R.id.gDesc)
        gClock = findViewById(R.id.gClock)

        GuideState.reset()
        channels = liveChannels(prefs, intent.getStringExtra("group") ?: "*")
        rows.layoutManager = LinearLayoutManager(this)
        rows.itemAnimator = null
        rows.adapter = adapter

        val idx = channels.indexOfFirst { it.id == prefs.lastChannel }.coerceAtLeast(0)
        if (channels.isNotEmpty()) {
            (rows.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(idx, dp(this, 100f))
            rows.post { rows.findViewHolderForAdapterPosition(idx)?.itemView?.findViewById<View>(R.id.gPrograms)?.requestFocus() }
        } else {
            gTitle.text = "Geen zenders in deze groep"
        }
        if (!Epg.loaded) {
            gDesc.text = if (Epg.loading) "Tv-gids wordt geladen…" else ""
        }
        Epg.addListener(epgListener)
        Epg.load()
    }

    override fun onStart() {
        super.onStart()
        if (::gClock.isInitialized) handler.post(ticker)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacksAndMessages(null)
    }

    override fun onDestroy() {
        Epg.removeListener(epgListener)
        super.onDestroy()
    }

    private fun redrawAll() {
        header.invalidate()
        for (i in 0 until rows.childCount) {
            rows.getChildAt(i).findViewById<View>(R.id.gPrograms)?.invalidate()
        }
    }

    override fun onProgramSelected(row: EpgRowView, program: Program?) {
        val item = row.tag as? Item ?: return
        if (program == null) {
            gTitle.text = item.name
            gTime.text = ""
            gDesc.text = "Geen programma-informatie"
            return
        }
        gTitle.text = program.title
        val now = System.currentTimeMillis()
        val live = if (program.start <= now && program.end > now) "NU  ·  " else ""
        gTime.text = "$live${Epg.time(program.start)} – ${Epg.time(program.end)}   ·   ${item.name}"
        gDesc.text = program.desc
    }

    override fun onWindowChanged() = redrawAll()

    override fun onPlay(row: EpgRowView) {
        val item = row.tag as? Item ?: return
        prefs.lastChannel = item.id
        PlayQueue.set(channels, item)
        startActivity(Intent(this, PlayerActivity::class.java))
    }
}
