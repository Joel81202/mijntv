package nl.michel.iptv

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Start MijnTV als de tv/box opstart (als dat is aangezet in Instellingen). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!Prefs(context).autoStart) return
        val i = Intent(context, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(i) }
    }
}
