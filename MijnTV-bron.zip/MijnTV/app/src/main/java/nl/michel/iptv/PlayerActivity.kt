package nl.michel.iptv

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var overlay: TextView
    private lateinit var prefs: Prefs

    private var useHls = false
    private var triedAlt = false

    private val handler = Handler(Looper.getMainLooper())
    private val hideOverlay = Runnable { overlay.visibility = View.GONE }
    private val hideInfoBar = Runnable { infoBar.visibility = View.GONE }

    private lateinit var infoBar: View
    private lateinit var listPanel: View
    private lateinit var listChannels: RecyclerView
    private var listAdapter: ChannelAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (PlayQueue.current() == null || Repo.api == null) {
            finish()
            return
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)
        prefs = Prefs(this)
        useHls = prefs.hls
        playerView = findViewById(R.id.playerView)
        overlay = findViewById(R.id.overlay)
        infoBar = findViewById(R.id.infoBar)
        listPanel = findViewById(R.id.listPanel)
        listChannels = findViewById(R.id.listChannels)

        if (PlayQueue.current()?.type == Type.LIVE) {
            // TiviMate-stijl: geen tijdbalk bij live, OK opent de zenderlijst
            playerView.useController = false
            playerView.setOnClickListener { if (listPanel.visibility == View.VISIBLE) hideList() else showList() }
            val adapter = ChannelAdapter(
                prefs,
                onClick = { pos, _ -> hideList(); zapTo(pos) },
                onLongClick = { _, item -> prefs.toggleFav(item.favKey) },
                onFocus = { _, _ -> }
            )
            listChannels.layoutManager = LinearLayoutManager(this)
            listChannels.itemAnimator = null
            listChannels.adapter = adapter
            listAdapter = adapter
        }
    }

    private fun showList() {
        val adapter = listAdapter ?: return
        val cur = PlayQueue.current() ?: return
        infoBar.visibility = View.GONE
        adapter.playingId = cur.id
        adapter.submit(PlayQueue.items)
        findViewById<TextView>(R.id.listTitle).text = "Zenders  ·  ${PlayQueue.items.size}"
        listPanel.visibility = View.VISIBLE
        val i = PlayQueue.index
        (listChannels.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(i, dp(this, 160f))
        listChannels.post { listChannels.findViewHolderForAdapterPosition(i)?.itemView?.requestFocus() }
    }

    private fun hideList() {
        listPanel.visibility = View.GONE
        playerView.requestFocus()
    }

    private fun showInfoBar() {
        val item = PlayQueue.current() ?: return
        if (item.type != Type.LIVE) return
        val (now, _, next) = programInfo(item)
        val logo = findViewById<ImageView>(R.id.barLogo)
        if (item.icon.isNotEmpty()) Glide.with(logo).load(item.icon).into(logo) else logo.setImageDrawable(null)
        findViewById<TextView>(R.id.barChannel).text = "${channelNumber(item, PlayQueue.index)}   ${item.name}"
        findViewById<TextView>(R.id.barNow).text = now
        findViewById<TextView>(R.id.barNext).text = next
        findViewById<TextView>(R.id.barClock).text = Epg.time(System.currentTimeMillis())
        val bar = findViewById<ProgressBar>(R.id.barProgress)
        val p = Epg.now(item)
        bar.visibility = if (p != null) View.VISIBLE else View.INVISIBLE
        if (p != null) bar.progress = Epg.progress(p)
        infoBar.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfoBar)
        handler.postDelayed(hideInfoBar, 5000)
        if (p == null) Epg.fetchShort(item) { if (PlayQueue.current() == item && infoBar.visibility == View.VISIBLE) showInfoBar() }
    }

    private fun zapTo(index: Int) {
        if (index !in PlayQueue.items.indices) return
        PlayQueue.index = index
        triedAlt = false
        useHls = prefs.hls
        PlayQueue.current()?.let { prefs.lastChannel = it.id }
        playCurrent()
    }

    override fun onStart() {
        super.onStart()
        if (::playerView.isInitialized) initPlayer()
    }

    override fun onResume() {
        super.onResume()
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onStop() {
        super.onStop()
        saveProgress()
        releasePlayer()
    }

    /** Kijkvoortgang bewaren voor "Verder kijken". */
    private fun saveProgress() {
        val p = player ?: return
        val item = PlayQueue.current() ?: return
        if (item.type != Type.MOVIE && item.type != Type.EPISODE) return
        val pos = p.currentPosition
        val dur = p.duration
        if (dur <= 0) return
        val parent = PlayQueue.parent
        if (pos > 30_000 && pos < dur * 0.95) {
            prefs.savePos(item.favKey, pos, (pos * 100 / dur).toInt())
            if (item.type == Type.MOVIE) prefs.addRecent(item)
            else if (parent != null) {
                prefs.addRecent(parent)
                prefs.setLastEpisode(parent.id, item.id)
            }
        } else if (pos >= dur * 0.95) {
            prefs.clearPos(item.favKey)
            if (item.type == Type.MOVIE) prefs.removeRecent(item.favKey)
        }
        Repo.historyChanged = true
    }

    private fun initPlayer() {
        if (player != null) return
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(Xtream.UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(30000)
        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) = handleError(error)

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY && triedAlt) {
                    // Het andere formaat werkt: onthouden voor de volgende keer.
                    prefs.hls = useHls
                }
                if (playbackState == Player.STATE_ENDED) handleEnded()
            }
        })
        playerView.player = p
        player = p
        playCurrent()
    }

    private fun releasePlayer() {
        player?.let {
            playerView.player = null
            it.release()
        }
        player = null
    }

    private fun playCurrent() {
        val p = player ?: return
        val item = PlayQueue.current() ?: return
        val api = Repo.api ?: return
        val url = api.streamUrl(item, useHls)
        val builder = MediaItem.Builder().setUri(url)
        if (item.type == Type.LIVE) {
            builder.setMimeType(if (useHls) MimeTypes.APPLICATION_M3U8 else MimeTypes.VIDEO_MP2T)
        }
        val start = if (item.type == Type.MOVIE || item.type == Type.EPISODE) prefs.getPos(item.favKey) else 0L
        if (start > 0) {
            p.setMediaItem(builder.build(), start)
            Toast.makeText(this, "Hervat vanaf ${formatTime(start)}", Toast.LENGTH_SHORT).show()
        } else {
            p.setMediaItem(builder.build())
        }
        p.prepare()
        p.playWhenReady = true
        showOverlay(item.name)
    }

    private fun handleError(error: PlaybackException) {
        val item = PlayQueue.current()
        if (item?.type == Type.LIVE && !triedAlt) {
            triedAlt = true
            useHls = !useHls
            playCurrent()
            return
        }
        Toast.makeText(this, "Kan niet afspelen (${error.errorCodeName})", Toast.LENGTH_LONG).show()
    }

    private fun formatTime(ms: Long): String {
        val t = ms / 1000
        val h = t / 3600
        val m = (t % 3600) / 60
        val sec = t % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%d:%02d", m, sec)
    }

    private fun handleEnded() {
        val item = PlayQueue.current() ?: return
        if (item.type == Type.MOVIE || item.type == Type.EPISODE) {
            prefs.clearPos(item.favKey)
            Repo.historyChanged = true
        }
        when (item.type) {
            Type.MOVIE -> {
                prefs.removeRecent(item.favKey)
                finish()
            }
            Type.EPISODE -> {
                if (PlayQueue.index < PlayQueue.items.size - 1) {
                    PlayQueue.index++
                    PlayQueue.parent?.let { prefs.setLastEpisode(it.id, PlayQueue.current()?.id ?: "") }
                    playCurrent()
                } else {
                    finish()
                }
            }
            Type.LIVE -> playCurrent() // live stream onderbroken: opnieuw verbinden
            else -> finish()
        }
    }

    private fun zap(delta: Int) {
        val n = PlayQueue.items.size
        if (n < 2) return
        zapTo(((PlayQueue.index + delta) % n + n) % n)
    }

    private fun showOverlay(text: String) {
        if (PlayQueue.current()?.type == Type.LIVE) {
            showInfoBar()
            return
        }
        val pos = if (PlayQueue.items.size > 1) "${PlayQueue.index + 1}/${PlayQueue.items.size}  " else ""
        overlay.text = pos + text
        overlay.visibility = View.VISIBLE
        handler.removeCallbacks(hideOverlay)
        handler.postDelayed(hideOverlay, 3500)
    }

    private var swallowBackUp = false

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP && swallowBackUp) {
            swallowBackUp = false
            return true
        }
        val isLive = PlayQueue.current()?.type == Type.LIVE
        if (isLive && ::listPanel.isInitialized && event.action == KeyEvent.ACTION_DOWN) {
            if (listPanel.visibility == View.VISIBLE) {
                if (event.keyCode == KeyEvent.KEYCODE_BACK) {
                    hideList(); swallowBackUp = true; return true
                }
                return super.dispatchKeyEvent(event)
            }
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { zap(-1); return true }
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { zap(1); return true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { showList(); return true }
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_INFO -> { showInfoBar(); return true }
                KeyEvent.KEYCODE_BACK -> if (infoBar.visibility == View.VISIBLE) {
                    infoBar.visibility = View.GONE; swallowBackUp = true; return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
