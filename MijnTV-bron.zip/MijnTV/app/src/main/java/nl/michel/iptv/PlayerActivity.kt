package nl.michel.iptv

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import android.graphics.Color
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.common.text.Cue
import androidx.media3.common.text.CueGroup
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.SubtitleView
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import android.net.Uri
import android.widget.Button
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import java.io.File
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var overlay: TextView
    private lateinit var prefs: Prefs

    private var useHls = false
    private var triedAlt = false

    private val handler = Handler(Looper.getMainLooper())
    private val hideOverlay = Runnable { overlay.visibility = View.GONE }
    private val hideInfoBar = Runnable { infoBar.visibility = View.GONE }

    private lateinit var subs: SubtitleView
    private lateinit var infoBar: View
    private lateinit var listPanel: View
    private lateinit var listChannels: RecyclerView
    private var listAdapter: ChannelAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (PlayQueue.current() == null || Repo.api == null) {
            finish()
            return
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)
        prefs = Prefs(this)
        useHls = if (PlayQueue.current()?.type == Type.CATCHUP) false else prefs.hls
        playerView = findViewById(R.id.playerView)
        overlay = findViewById(R.id.overlay)
        infoBar = findViewById(R.id.infoBar)
        subs = findViewById(R.id.subs)
        setupSubtitleView()

        val btnSubs = findViewById<Button>(R.id.btnSubs)
        btnSubs.setOnClickListener { searchSubtitles() }
        val curType = PlayQueue.current()?.type
        if (curType == Type.MOVIE || curType == Type.EPISODE) {
            // Knop verschijnt samen met de bedieningsbalk
            playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { visibility ->
                btnSubs.visibility = visibility
            })
        }
        listPanel = findViewById(R.id.listPanel)
        listChannels = findViewById(R.id.listChannels)

        if (PlayQueue.current()?.type == Type.LIVE) {
            // TiviMate-stijl: geen tijdbalk bij live, OK opent de zenderlijst
            playerView.useController = false
            playerView.setOnClickListener { if (listPanel.visibility == View.VISIBLE) hideList() else showList() }
            val adapter = ChannelAdapter(
                prefs,
                onClick = { pos, _ -> hideList(); zapTo(pos) },
                onLongClick = { _, item -> prefs.toggleFav(item.favKey) },
                onFocus = { _, _ -> }
            )
            listChannels.layoutManager = LinearLayoutManager(this)
            listChannels.itemAnimator = null
            listChannels.adapter = adapter
            listAdapter = adapter
        }
    }

    private fun showList() {
        val adapter = listAdapter ?: return
        val cur = PlayQueue.current() ?: return
        infoBar.visibility = View.GONE
        adapter.playingId = cur.id
        adapter.submit(PlayQueue.items)
        findViewById<TextView>(R.id.listTitle).text = "Zenders  ·  ${PlayQueue.items.size}"
        listPanel.visibility = View.VISIBLE
        val i = PlayQueue.index
        (listChannels.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(i, dp(this, 160f))
        listChannels.post { listChannels.findViewHolderForAdapterPosition(i)?.itemView?.requestFocus() }
    }

    private fun hideList() {
        listPanel.visibility = View.GONE
        playerView.requestFocus()
    }

    private fun showInfoBar() {
        val item = PlayQueue.current() ?: return
        if (item.type != Type.LIVE) return
        val (now, _, next) = programInfo(item)
        val logo = findViewById<ImageView>(R.id.barLogo)
        if (item.icon.isNotEmpty()) Glide.with(logo).load(item.icon).into(logo) else logo.setImageDrawable(null)
        findViewById<TextView>(R.id.barChannel).text = "${channelNumber(item, PlayQueue.index)}   ${item.name}"
        findViewById<TextView>(R.id.barNow).text = now
        findViewById<TextView>(R.id.barNext).text = next
        findViewById<TextView>(R.id.barClock).text = Epg.time(System.currentTimeMillis())
        val bar = findViewById<ProgressBar>(R.id.barProgress)
        val p = Epg.now(item)
        bar.visibility = if (p != null) View.VISIBLE else View.INVISIBLE
        if (p != null) bar.progress = Epg.progress(p)
        infoBar.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfoBar)
        handler.postDelayed(hideInfoBar, 5000)
        if (p == null) Epg.fetchShort(item) { if (PlayQueue.current() == item && infoBar.visibility == View.VISIBLE) showInfoBar() }
    }

    private fun zapTo(index: Int) {
        if (index !in PlayQueue.items.indices) return
        PlayQueue.index = index
        triedAlt = false
        useHls = prefs.hls
        PlayQueue.current()?.let { prefs.lastChannel = it.id }
        playCurrent()
    }

    override fun onStart() {
        super.onStart()
        if (::playerView.isInitialized) initPlayer()
    }

    override fun onResume() {
        super.onResume()
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onStop() {
        super.onStop()
        saveProgress()
        releasePlayer()
    }

    /** Kijkvoortgang bewaren voor "Verder kijken". */
    private fun saveProgress() {
        val p = player ?: return
        val item = PlayQueue.current() ?: return
        if (item.type != Type.MOVIE && item.type != Type.EPISODE) return
        val pos = p.currentPosition
        val dur = p.duration
        if (dur <= 0) return
        val parent = PlayQueue.parent
        if (pos > 30_000 && pos < dur * 0.95) {
            prefs.savePos(item.favKey, pos, (pos * 100 / dur).toInt())
            if (item.type == Type.MOVIE) prefs.addRecent(item)
            else if (parent != null) {
                prefs.addRecent(parent)
                prefs.setLastEpisode(parent.id, item.id)
            }
        } else if (pos >= dur * 0.95) {
            prefs.clearPos(item.favKey)
            if (item.type == Type.MOVIE) prefs.removeRecent(item.favKey)
        }
        Repo.historyChanged = true
    }

    private fun initPlayer() {
        if (player != null) return
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(Xtream.UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(30000)
            .setDefaultRequestProperties(Repo.api?.streamHeaders() ?: emptyMap())
        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
            .build()
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setPreferredTextLanguages("nl", "dut", "nld", "en")
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !prefs.subsOn)
            .build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) = handleError(error)

            override fun onCues(cueGroup: CueGroup) {
                // Positie uit het bestand negeren: altijd netjes onderin
                subs.setCues(cueGroup.cues.map { cue ->
                    if (cue.bitmap != null) cue
                    else cue.buildUpon()
                        .setLine(Cue.DIMEN_UNSET, Cue.TYPE_UNSET)
                        .setLineAnchor(Cue.TYPE_UNSET)
                        .setPosition(Cue.DIMEN_UNSET)
                        .setPositionAnchor(Cue.TYPE_UNSET)
                        .setSize(Cue.DIMEN_UNSET)
                        .setTextSize(Cue.DIMEN_UNSET, Cue.TYPE_UNSET)
                        .build()
                })
            }

            override fun onTrackSelectionParametersChanged(parameters: TrackSelectionParameters) {
                // Keuze via de ondertitelknop onthouden
                prefs.subsOn = !parameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY && triedAlt && PlayQueue.current()?.type == Type.LIVE) {
                    // Het andere formaat werkt: onthouden voor de volgende keer.
                    prefs.hls = useHls
                }
                if (playbackState == Player.STATE_ENDED) handleEnded()
            }
        })
        playerView.player = p
        playerView.subtitleView?.visibility = View.GONE
        playerView.setShowSubtitleButton(true)
        player = p
        playCurrent()
    }

    private fun setupSubtitleView() {
        subs.setApplyEmbeddedStyles(false)
        subs.setApplyEmbeddedFontSizes(false)
        subs.setBottomPaddingFraction(0.025f)
        val factor = when (prefs.subsSize) {
            0 -> 0.6f
            2 -> 0.95f
            else -> 0.75f
        }
        subs.setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * factor)
        subs.setStyle(
            CaptionStyleCompat(
                Color.WHITE, Color.TRANSPARENT, Color.TRANSPARENT,
                CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, null
            )
        )
    }

    /** Eerder gedownloade ondertitel voor dit item, als die er nog is. */
    private fun externalSubtitle(item: Item): MediaItem.SubtitleConfiguration? {
        val saved = prefs.subFile(item.favKey)
        if (saved.isEmpty()) return null
        val path = saved.substringBefore("|")
        val lang = saved.substringAfter("|", "nl")
        val f = File(path)
        if (!f.exists()) return null
        return MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(f))
            .setMimeType(MimeTypes.APPLICATION_SUBRIP)
            .setLanguage(lang)
            .setLabel("Gedownload ($lang)")
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
    }

    /** Ondertitels zoeken bij OpenSubtitles en kiezen uit een lijst. */
    private fun searchSubtitles() {
        val item = PlayQueue.current() ?: return
        if (item.type == Type.LIVE) return
        if (!OpenSubs.configured(prefs)) {
            Toast.makeText(this, "Vul eerst je OpenSubtitles-gegevens in bij ⚙ Instellingen", Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, "Ondertitels zoeken…", Toast.LENGTH_SHORT).show()
        val parent = PlayQueue.parent
        Bg.go({ OpenSubs.search(prefs, item, parent) }) { r ->
            if (isFinishing) return@go
            val list = r.getOrElse { e ->
                Toast.makeText(this, e.message ?: "Zoeken mislukt", Toast.LENGTH_LONG).show()
                return@go
            }
            if (list.isEmpty()) {
                Toast.makeText(this, "Geen ondertitels gevonden", Toast.LENGTH_LONG).show()
                return@go
            }
            val labels = ArrayList<CharSequence>()
            labels.add("✕  Geen externe ondertitel")
            for (sub in list.take(40)) {
                val flag = if (sub.lang == "nl") "NL" else sub.lang.uppercase()
                val extra = buildString {
                    if (sub.hearingImpaired) append("  · SDH")
                    if (sub.machine) append("  · automatisch vertaald")
                }
                labels.add("$flag  ·  ${sub.release}  ·  ⬇ ${sub.downloads}$extra")
            }
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Kies ondertitel")
                .setItems(labels.toTypedArray()) { _, which ->
                    if (which == 0) {
                        prefs.setSubFile(item.favKey, "")
                        reloadKeepingPosition()
                    } else {
                        downloadSubtitle(list[which - 1], item)
                    }
                }
                .show()
        }
    }

    private fun downloadSubtitle(sub: OpenSubs.Sub, item: Item) {
        Toast.makeText(this, "Downloaden…", Toast.LENGTH_SHORT).show()
        Bg.go({ OpenSubs.download(this, prefs, sub, item) }) { r ->
            if (isFinishing) return@go
            r.onSuccess { (file, _) ->
                prefs.setSubFile(item.favKey, file.absolutePath + "|" + sub.lang)
                prefs.subsOn = true
                reloadKeepingPosition()
                Toast.makeText(this, "Ondertitel geladen", Toast.LENGTH_SHORT).show()
            }.onFailure { e ->
                Toast.makeText(this, e.message ?: "Download mislukt", Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Opnieuw laden met de nieuwe ondertitel, op dezelfde plek in de video. */
    private fun reloadKeepingPosition() {
        val p = player ?: return
        val item = PlayQueue.current() ?: return
        val api = Repo.api ?: return
        val pos = p.currentPosition
        val builder = MediaItem.Builder().setUri(api.streamUrl(item, useHls))
        externalSubtitle(item)?.let { builder.setSubtitleConfigurations(listOf(it)) }
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !prefs.subsOn)
            .build()
        p.setMediaItem(builder.build(), pos)
        p.prepare()
        p.playWhenReady = true
    }

    /** Ondertitels aan/uit (CC-knop op de afstandsbediening). */
    private fun toggleSubtitles() {
        val p = player ?: return
        val on = !prefs.subsOn
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !on)
            .build()
        prefs.subsOn = on
        if (!on) subs.setCues(emptyList())
        Toast.makeText(this, if (on) "Ondertitels aan" else "Ondertitels uit", Toast.LENGTH_SHORT).show()
    }

    private fun releasePlayer() {
        player?.let {
            playerView.player = null
            it.release()
        }
        player = null
    }

    private fun playCurrent() {
        val p = player ?: return
        val item = PlayQueue.current() ?: return
        val api = Repo.api ?: return
        if (api.isEnigma && item.type == Type.LIVE) useHls = false
        val url = api.streamUrl(item, useHls)
        val builder = MediaItem.Builder().setUri(url)
        externalSubtitle(item)?.let { builder.setSubtitleConfigurations(listOf(it)) }
        if (item.type == Type.LIVE) {
            builder.setMimeType(if (useHls) MimeTypes.APPLICATION_M3U8 else MimeTypes.VIDEO_MP2T)
        } else if (item.type == Type.CATCHUP) {
            builder.setMimeType(MimeTypes.VIDEO_MP2T)
        }
        val start = if (item.type == Type.MOVIE || item.type == Type.EPISODE) prefs.getPos(item.favKey) else 0L
        if (start > 0) {
            p.setMediaItem(builder.build(), start)
            Toast.makeText(this, "Hervat vanaf ${formatTime(start)}", Toast.LENGTH_SHORT).show()
        } else {
            p.setMediaItem(builder.build())
        }
        p.prepare()
        p.playWhenReady = true
        showOverlay(item.name)
    }

    private fun handleError(error: PlaybackException) {
        val item = PlayQueue.current()
        if ((item?.type == Type.LIVE || item?.type == Type.CATCHUP) && !triedAlt) {
            triedAlt = true
            useHls = !useHls
            playCurrent()
            return
        }
        Toast.makeText(this, "Kan niet afspelen (${error.errorCodeName})", Toast.LENGTH_LONG).show()
    }

    private fun formatTime(ms: Long): String {
        val t = ms / 1000
        val h = t / 3600
        val m = (t % 3600) / 60
        val sec = t % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%d:%02d", m, sec)
    }

    private fun handleEnded() {
        val item = PlayQueue.current() ?: return
        if (item.type == Type.MOVIE || item.type == Type.EPISODE) {
            prefs.clearPos(item.favKey)
            Repo.historyChanged = true
        }
        when (item.type) {
            Type.MOVIE -> {
                prefs.removeRecent(item.favKey)
                finish()
            }
            Type.EPISODE -> {
                if (PlayQueue.index < PlayQueue.items.size - 1) {
                    PlayQueue.index++
                    PlayQueue.parent?.let { prefs.setLastEpisode(it.id, PlayQueue.current()?.id ?: "") }
                    playCurrent()
                } else {
                    finish()
                }
            }
            Type.LIVE -> playCurrent() // live stream onderbroken: opnieuw verbinden
            else -> finish()
        }
    }

    private fun zap(delta: Int) {
        val n = PlayQueue.items.size
        if (n < 2) return
        zapTo(((PlayQueue.index + delta) % n + n) % n)
    }

    private fun showOverlay(text: String) {
        if (PlayQueue.current()?.type == Type.LIVE) {
            showInfoBar()
            return
        }
        val pos = if (PlayQueue.items.size > 1) "${PlayQueue.index + 1}/${PlayQueue.items.size}  " else ""
        overlay.text = pos + text
        overlay.visibility = View.VISIBLE
        handler.removeCallbacks(hideOverlay)
        handler.postDelayed(hideOverlay, 3500)
    }

    private var swallowBackUp = false

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_CAPTIONS) {
            if (event.action == KeyEvent.ACTION_DOWN) toggleSubtitles()
            return true
        }
        if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP && swallowBackUp) {
            swallowBackUp = false
            return true
        }
        val isLive = PlayQueue.current()?.type == Type.LIVE
        if (isLive && ::listPanel.isInitialized && event.action == KeyEvent.ACTION_DOWN) {
            if (listPanel.visibility == View.VISIBLE) {
                if (event.keyCode == KeyEvent.KEYCODE_BACK) {
                    hideList(); swallowBackUp = true; return true
                }
                return super.dispatchKeyEvent(event)
            }
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { zap(1); return true }
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { zap(-1); return true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { showList(); return true }
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_INFO -> { showInfoBar(); return true }
                KeyEvent.KEYCODE_BACK -> if (infoBar.visibility == View.VISIBLE) {
                    infoBar.visibility = View.GONE; swallowBackUp = true; return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
