package nl.michel.iptv

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Xml
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class Program(val start: Long, val end: Long, val title: String, val desc: String)

/** Tv-gids: volledige XMLTV van de provider, met short_epg als reserve. */
object Epg {
    private val byChannel = HashMap<String, List<Program>>()
    @Volatile var loaded = false
    @Volatile var loading = false
    private val listeners = ArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())
    private val cal: Calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    fun time(ms: Long): String = timeFmt.format(Date(ms))

    private val dayFmt = SimpleDateFormat("EEE d MMM", Locale("nl", "NL"))

    /** "vandaag", "gisteren" of "ma 24 nov" */
    fun day(ms: Long): String {
        val c1 = Calendar.getInstance().apply { timeInMillis = ms }
        val c2 = Calendar.getInstance()
        if (c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR)) {
            val d = c2.get(Calendar.DAY_OF_YEAR) - c1.get(Calendar.DAY_OF_YEAR)
            if (d == 0) return "Vandaag"
            if (d == 1) return "Gisteren"
            if (d == -1) return "Morgen"
        }
        return dayFmt.format(Date(ms))
    }

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }

    private fun idKey(item: Item): String = "id:" + item.favKey

    private fun key(item: Item): String =
        if (item.epg.isNotEmpty()) item.epg.lowercase(Locale.ROOT) else idKey(item)

    @Synchronized
    fun programs(item: Item): List<Program> =
        byChannel[key(item)] ?: byChannel[idKey(item)] ?: emptyList()

    fun now(item: Item, t: Long = System.currentTimeMillis()): Program? =
        programs(item).firstOrNull { it.start <= t && it.end > t }

    fun next(item: Item, t: Long = System.currentTimeMillis()): Program? =
        programs(item).firstOrNull { it.start > t }

    fun progress(p: Program, t: Long = System.currentTimeMillis()): Int {
        val len = p.end - p.start
        if (len <= 0) return 0
        return (((t - p.start) * 100) / len).toInt().coerceIn(0, 100)
    }

    fun clear() {
        synchronized(this) { byChannel.clear() }
        shortFetched.clear()
        archiveFetched.clear()
        loaded = false
    }

    /** Volledige gids van alle providers op de achtergrond laden. */
    fun load() {
        if (loaded || loading) return
        val apis = Repo.apis.values.toList()
        if (apis.isEmpty()) return
        val live = Repo.live
        val cats = Repo.liveCats
        val byCat = Repo.liveByCat
        loading = true
        Bg.go({
            val all = HashMap<String, List<Program>>()
            for (api in apis) runCatching {
                if (api.isEnigma) {
                    // Vu+: nu/straks per bouquet ophalen
                    for (c in cats) {
                        if (byCat[c.id]?.firstOrNull()?.src != api.src) continue
                        runCatching {
                            for ((sref, list) in api.bouquetNowNext(c.id)) {
                                val probe = Item(sref, "", "", "", Type.LIVE, src = api.src)
                                all[idKey(probe)] = list.map { Program(it.start * 1000, it.end * 1000, it.title, it.desc) }
                            }
                        }
                    }
                } else {
                    val mine = live.filter { it.src == api.src }
                    val wanted = mine.mapNotNull { if (it.epg.isEmpty()) null else it.epg.lowercase(Locale.ROOT) }.toHashSet()
                    if (wanted.isNotEmpty()) {
                        // Zenders met archief: ook uitzendingen van de afgelopen dagen bewaren
                        val archive = HashMap<String, Int>()
                        for (it in mine) if (it.archive > 0 && it.epg.isNotEmpty()) {
                            val k = it.epg.lowercase(Locale.ROOT)
                            archive[k] = maxOf(archive[k] ?: 0, minOf(it.archive, 7))
                        }
                        for ((k, v) in parse(api.xmltvUrl(), wanted, archive)) {
                            val old = all[k]
                            all[k] = if (old == null) v else (old + v).associateBy { it.start }.values.sortedBy { it.start }
                        }
                    }
                }
            }
            all
        }) { r ->
            loading = false
            r.onSuccess { map ->
                synchronized(this) { for ((k, v) in map) if (!byChannel.containsKey(k) || (byChannel[k]?.size ?: 0) < v.size) byChannel[k] = v }
                loaded = true
                for (l in ArrayList(listeners)) l()
            }
        }
    }

    /** Reserve als een zender niet in de XMLTV staat. */
    private val shortFetched = HashSet<String>()

    fun fetchShort(item: Item, done: () -> Unit) {
        if (programs(item).size > 3 || !shortFetched.add(item.favKey)) return
        val api = Repo.apiFor(item) ?: return
        Bg.go({ api.shortEpg(item.id) }) { r ->
            val list = r.getOrNull().orEmpty()
                .filter { it.end > 0 }
                .map { Program(it.start * 1000, it.end * 1000, it.title, it.desc) }
            if (list.isNotEmpty()) {
                synchronized(this) {
                    val k = key(item)
                    val merged = ((byChannel[k] ?: emptyList()) + list).associateBy { it.start }.values.sortedBy { it.start }
                    byChannel[k] = merged
                }
                done()
            } else {
                shortFetched.remove(item.favKey)
            }
        }
    }

    private val archiveFetched = HashSet<String>()

    /** Uitzendingen uit het archief van één zender ophalen (voor terugkijken). */
    fun fetchArchive(item: Item, done: () -> Unit) {
        if (item.archive <= 0 || !archiveFetched.add(item.favKey)) return
        val api = Repo.apiFor(item) ?: return
        Bg.go({ api.fullEpg(item.id) }) { r ->
            val list = r.getOrNull().orEmpty()
                .filter { it.end > 0 }
                .map { Program(it.start * 1000, it.end * 1000, it.title, it.desc) }
            if (list.isEmpty()) {
                archiveFetched.remove(item.favKey); return@go
            }
            synchronized(this) {
                val merged = (programs(item) + list).associateBy { it.start }.values.sortedBy { it.start }
                byChannel[key(item)] = merged
            }
            done()
        }
    }

    /** Item om een uitzending terug te kijken. */
    fun catchupItem(channel: Item, p: Program): Item = Item(
        channel.id, "${channel.name}  ·  ${p.title}", channel.icon, channel.categoryId, Type.CATCHUP,
        plot = p.desc, start = p.start,
        durationMin = (((p.end - p.start) / 60_000L).toInt() + 2).coerceAtLeast(1),
        src = channel.src
    )

    fun canCatchup(channel: Item, p: Program, now: Long = System.currentTimeMillis()): Boolean =
        channel.archive > 0 && p.start < now && p.start > now - channel.archive * 86_400_000L

    /** Hele week (7 dagen terug en vooruit) van één zender uit de XMLTV-gids (traag, alleen als reserve). */
    fun weekFromXmltv(item: Item): List<Program> {
        val api = Repo.apiFor(item) ?: return emptyList()
        if (api.isEnigma || item.epg.isEmpty()) return emptyList()
        val k = item.epg.lowercase(Locale.ROOT)
        return parse(api.xmltvUrl(), setOf(k), mapOf(k to 7), 7 * 24)[k].orEmpty()
    }

    private fun parse(url: String, wanted: Set<String>, archive: Map<String, Int>, aheadHours: Int = 30): Map<String, List<Program>> {
        val from = System.currentTimeMillis() - 3 * 3600_000L
        val now = System.currentTimeMillis()
        val until = System.currentTimeMillis() + aheadHours * 3600_000L
        val map = HashMap<String, MutableList<Program>>()
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 120000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", Xtream.UA)
        try {
            c.inputStream.buffered().use { input ->
                val x = Xml.newPullParser()
                x.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
                x.setInput(input, null)
                var ch: String? = null
                var start = 0L
                var end = 0L
                var title = ""
                var desc = ""
                var tag = ""
                var ev = x.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    when (ev) {
                        XmlPullParser.START_TAG -> {
                            tag = x.name
                            if (tag == "programme") {
                                val id = x.getAttributeValue(null, "channel")?.lowercase(Locale.ROOT)
                                start = parseTime(x.getAttributeValue(null, "start") ?: "")
                                end = parseTime(x.getAttributeValue(null, "stop") ?: "")
                                val min = if (id != null && archive.containsKey(id)) now - (archive[id] ?: 0) * 86_400_000L else from
                                ch = if (id != null && wanted.contains(id) && end > min && start < until) id else null
                                title = ""; desc = ""
                            }
                        }
                        XmlPullParser.TEXT -> if (ch != null) {
                            if (tag == "title" && title.isEmpty()) title = x.text.trim()
                            else if (tag == "desc" && desc.isEmpty()) desc = x.text.trim()
                        }
                        XmlPullParser.END_TAG -> {
                            if (x.name == "programme") {
                                val id = ch
                                if (id != null) map.getOrPut(id) { ArrayList() }.add(Program(start, end, title, desc))
                                ch = null
                            }
                            tag = ""
                        }
                    }
                    ev = x.next()
                }
            }
        } finally {
            c.disconnect()
        }
        return map.mapValues { e -> e.value.sortedBy { it.start } }
    }

    /** "20251126060000 +0100" -> millis */
    private fun parseTime(s: String): Long {
        if (s.length < 14) return 0L
        return try {
            cal.clear()
            cal.set(
                s.substring(0, 4).toInt(), s.substring(4, 6).toInt() - 1, s.substring(6, 8).toInt(),
                s.substring(8, 10).toInt(), s.substring(10, 12).toInt(), s.substring(12, 14).toInt()
            )
            var t = cal.timeInMillis
            val tz = s.substring(14).trim()
            if (tz.length >= 5 && (tz[0] == '+' || tz[0] == '-')) {
                val sign = if (tz[0] == '-') -1 else 1
                val mins = tz.substring(1, 3).toInt() * 60 + tz.substring(3, 5).toInt()
                t -= sign * mins * 60_000L
            }
            t
        } catch (e: Exception) {
            0L
        }
    }
}

/** Zendernummer binnen de groep: elke groep (boeket) begint bij 1. */
fun channelNumber(item: Item, position: Int): String = (position + 1).toString()

/** Zenderlijst zoals in TiviMate: nummer, logo, naam, huidig programma + voortgang. */
class ChannelAdapter(
    private val prefs: Prefs,
    private val onClick: (Int, Item) -> Unit,
    private val onLongClick: (Int, Item) -> Unit,
    private val onFocus: (Int, Item) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val num: TextView = v.findViewById(R.id.chNum)
        val logo: ImageView = v.findViewById(R.id.chLogo)
        val name: TextView = v.findViewById(R.id.chName)
        val prog: TextView = v.findViewById(R.id.chProgram)
        val bar: ProgressBar = v.findViewById(R.id.chProgress)
    }

    var items: List<Item> = emptyList()
        private set
    var playingId: String = ""

    fun submit(list: List<Item>) {
        items = list
        notifyDataSetChanged()
    }

    fun refresh() {
        if (items.isNotEmpty()) notifyItemRangeChanged(0, items.size)
    }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        h.num.text = channelNumber(item, position)
        h.name.text = (if (prefs.isFav(item.favKey)) "★ " else "") + item.name
        if (item.icon.isNotEmpty()) Glide.with(h.logo).load(item.icon).into(h.logo)
        else {
            Glide.with(h.logo).clear(h.logo); h.logo.setImageDrawable(null)
        }
        val now = Epg.now(item)
        if (now != null) {
            h.prog.text = now.title
            h.bar.visibility = View.VISIBLE
            h.bar.progress = Epg.progress(now)
        } else {
            h.prog.text = if (Epg.loading) "Tv-gids laden…" else "Geen informatie"
            h.bar.visibility = View.INVISIBLE
        }
        h.itemView.isActivated = item.id == playingId
        h.itemView.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(p, items[p])
        }
        h.itemView.setOnLongClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) {
                onLongClick(p, items[p]); notifyItemChanged(p)
            }
            true
        }
        h.itemView.setOnFocusChangeListener { _, f ->
            val p = h.bindingAdapterPosition
            if (f && p != RecyclerView.NO_POSITION) onFocus(p, items[p])
        }
    }
}

/** Programmalijst van één zender: archief, nu en straks. */
class ProgramAdapter(
    private val onClick: (Program) -> Unit
) : RecyclerView.Adapter<ProgramAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val time: TextView = v.findViewById(R.id.prTime)
        val title: TextView = v.findViewById(R.id.prTitle)
        val badge: TextView = v.findViewById(R.id.prBadge)
    }

    var items: List<Program> = emptyList()
        private set
    var channel: Item? = null

    fun submit(ch: Item, list: List<Program>) {
        channel = ch
        items = list
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_program, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val p = items[position]
        val now = System.currentTimeMillis()
        val prev = items.getOrNull(position - 1)
        val showDay = prev == null || Epg.day(prev.start) != Epg.day(p.start)
        h.time.text = if (showDay && Epg.day(p.start) != "Vandaag") Epg.day(p.start) + "\n" + Epg.time(p.start) else Epg.time(p.start)
        h.title.text = p.title
        val ch = channel
        h.badge.text = when {
            p.start <= now && p.end > now -> "NU"
            ch != null && p.end <= now && Epg.canCatchup(ch, p) -> "⏪"
            else -> ""
        }
        h.itemView.alpha = if (p.end <= now && (ch == null || !Epg.canCatchup(ch, p))) 0.5f else 1f
        h.itemView.setOnClickListener {
            val i = h.bindingAdapterPosition
            if (i != RecyclerView.NO_POSITION) onClick(items[i])
        }
    }
}

/** Groepenlijst (links). */
class GroupAdapter(
    private val onClick: (Int, Category) -> Unit,
    private val onFocus: (Int, Category) -> Unit
) : RecyclerView.Adapter<GroupAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.grName)
        val count: TextView = v.findViewById(R.id.grCount)
    }

    var items: List<Pair<Category, Int>> = emptyList()
        private set
    private var sel = -1

    fun submit(list: List<Pair<Category, Int>>, selected: Int) {
        items = list; sel = selected
        notifyDataSetChanged()
    }

    fun select(i: Int) {
        val old = sel; sel = i
        if (old in items.indices) notifyItemChanged(old)
        if (i in items.indices) notifyItemChanged(i)
    }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_group, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val (cat, count) = items[position]
        val header = isGroupHeader(cat.id)
        h.name.text = cat.name
        h.count.text = if (count >= 0) count.toString() else ""
        h.itemView.isFocusable = !header
        h.itemView.isClickable = !header
        h.name.alpha = if (header) 0.6f else 1f
        h.name.textSize = if (header) 13f else 15f
        h.name.setTypeface(null, if (header) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        h.itemView.isActivated = position == sel
        h.itemView.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(p, items[p].first)
        }
        h.itemView.setOnFocusChangeListener { _, f ->
            val p = h.bindingAdapterPosition
            if (f && p != RecyclerView.NO_POSITION) onFocus(p, items[p].first)
        }
    }
}

/** Kop boven de groepen van een provider (niet te selecteren). */
fun isGroupHeader(id: String) = id.startsWith("HDR:")

/** Bij welke provider hoort deze groep? ("*@x", "FAV@x", of een gewone groep) */
fun groupSrc(id: String): String = when {
    id.contains("@") -> id.substringAfter("@")
    id == "*" || id == "FAV" -> Repo.current
    else -> Repo.catSrc[id] ?: Repo.current
}

/**
 * Groepen van alle providers onder elkaar (zoals MYTVOnline 3), elke provider met een kopje:
 * Favorieten, Alle zenders, favoriete groepen, dan de rest. Eén provider: zonder kopjes.
 */
fun liveGroups(prefs: Prefs): List<Pair<Category, Int>> {
    val hidden = prefs.hiddenGroups()
    val pins = prefs.pinnedGroups()
    val srcs = prefs.profiles().map { it.id }.filter { Repo.apis.containsKey(it) }.ifEmpty { listOf(Repo.current) }
    val multi = srcs.size > 1
    val out = ArrayList<Pair<Category, Int>>()
    for (src in srcs) {
        val section = ArrayList<Pair<Category, Int>>()
        val favCount = liveChannels(prefs, "FAV@$src").size
        if (favCount > 0 && !hidden.contains("live:FAV")) section.add(Pair(Category("FAV@$src", "★ Favorieten"), favCount))
        val allCount = liveChannels(prefs, "*@$src").size
        if (allCount > 0) section.add(Pair(Category("*@$src", "Alle zenders"), allCount))
        for (c in arrangeCats(prefs, "live", Repo.liveCats.filter { (Repo.catSrc[it.id] ?: "") == src })) {
            if (hidden.contains("live:" + c.id)) continue
            val n = Repo.liveByCat[c.id]?.size ?: 0
            if (n > 0) section.add(Pair(if (pins.contains("live:" + c.id)) Category(c.id, "★ " + c.name) else c, n))
        }
        if (section.isEmpty()) continue
        if (multi) {
            val icon = if (Repo.apis[src]?.isEnigma == true) "📡 " else "📺 "
            out.add(Pair(Category("HDR:$src", icon + (Repo.names[src] ?: "Provider")), -1))
        }
        out.addAll(section)
    }
    return out
}

fun liveChannels(prefs: Prefs, groupId: String): List<Item> = when {
    groupId.startsWith("*@") -> {
        val src = groupId.substringAfter("@")
        val hidden = prefs.hiddenGroups()
        Repo.live.filter { it.src == src && !hidden.contains("live:" + it.categoryId) }.distinctBy { it.id }
    }
    groupId.startsWith("FAV@") -> {
        val src = groupId.substringAfter("@")
        val favs = prefs.favorites()
        Repo.live.filter { it.src == src && favs.contains(it.favKey) }.distinctBy { it.id }
    }
    else -> liveChannelsCurrent(prefs, groupId)
}

private fun liveChannelsCurrent(prefs: Prefs, groupId: String): List<Item> = when (groupId) {
    "*" -> {
        val hidden = prefs.hiddenGroups()
        Repo.live.filter { Repo.isCurrent(it) && !hidden.contains("live:" + it.categoryId) }.distinctBy { it.id }
    }
    "FAV" -> {
        val favs = prefs.favorites()
        Repo.live.filter { Repo.isCurrent(it) && favs.contains(it.favKey) }.distinctBy { it.id }
    }
    else -> Repo.liveByCat[groupId] ?: emptyList()
}

/** Provider kiezen; alles blijft geladen, dus wisselen gaat direct. */
fun chooseProvider(act: android.app.Activity, prefs: Prefs, done: () -> Unit) {
    val list = prefs.profiles().filter { Repo.apis.containsKey(it.id) }
    if (list.size < 2) {
        android.widget.Toast.makeText(act, "Voeg eerst een tweede provider toe via 👤 in het hoofdmenu", android.widget.Toast.LENGTH_LONG).show()
        return
    }
    val labels = list.map {
        (if (it.id == Repo.current) "✓  " else "     ") + (if (it.kind == "enigma2") "📡 " else "📺 ") + it.name as CharSequence
    }.toTypedArray()
    androidx.appcompat.app.AlertDialog.Builder(act)
        .setTitle("Provider kiezen")
        .setItems(labels) { _, which ->
            val id = list[which].id
            if (id != Repo.current) {
                Repo.current = id
                prefs.currentSrc = id
                done()
            }
        }
        .show()
}

/** Kies welke groepen zichtbaar zijn (vinkje = tonen). */
fun chooseHiddenGroups(
    act: android.app.Activity,
    prefs: Prefs,
    title: String,
    entries: List<Pair<String, String>>,
    done: () -> Unit
) {
    if (entries.isEmpty()) {
        android.widget.Toast.makeText(act, "Geen groepen gevonden", android.widget.Toast.LENGTH_SHORT).show()
        return
    }
    val hidden = prefs.hiddenGroups().toMutableSet()
    val labels = entries.map { it.second as CharSequence }.toTypedArray()
    val checked = BooleanArray(entries.size) { !hidden.contains(entries[it].first) }
    androidx.appcompat.app.AlertDialog.Builder(act)
        .setTitle(title)
        .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
        .setPositiveButton("Opslaan") { _, _ ->
            entries.forEachIndexed { i, (key, _) -> if (checked[i]) hidden.remove(key) else hidden.add(key) }
            prefs.setHiddenGroups(hidden)
            done()
        }
        .setNeutralButton("Alles tonen") { _, _ ->
            hidden.removeAll(entries.map { it.first }.toSet())
            prefs.setHiddenGroups(hidden)
            done()
        }
        .setNegativeButton("Annuleren", null)
        .show()
}

/** Programma-info als tekst, voor info-panelen. */
fun programInfo(item: Item): Triple<String, String, String> {
    val now = Epg.now(item)
    val next = Epg.next(item)
    val nowLine = if (now != null) "${Epg.time(now.start)} – ${Epg.time(now.end)}   ${now.title}" else "Geen programma-informatie"
    val nextLine = if (next != null) "Straks  ${Epg.time(next.start)}   ${next.title}" else ""
    return Triple(nowLine, now?.desc ?: "", nextLine)
}

fun dp(ctx: Context, v: Float): Int = (ctx.resources.displayMetrics.density * v).toInt()
