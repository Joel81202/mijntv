package nl.michel.iptv

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Xml
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class Program(val start: Long, val end: Long, val title: String, val desc: String)

/** Tv-gids: volledige XMLTV van de provider, met short_epg als reserve. */
object Epg {
    private val byChannel = HashMap<String, List<Program>>()
    @Volatile var loaded = false
    @Volatile var loading = false
    private val listeners = ArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())
    private val cal: Calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    fun time(ms: Long): String = timeFmt.format(Date(ms))

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }

    private fun key(item: Item): String =
        if (item.epg.isNotEmpty()) item.epg.lowercase(Locale.ROOT) else "id:" + item.id

    @Synchronized
    fun programs(item: Item): List<Program> =
        byChannel[key(item)] ?: byChannel["id:" + item.id] ?: emptyList()

    fun now(item: Item, t: Long = System.currentTimeMillis()): Program? =
        programs(item).firstOrNull { it.start <= t && it.end > t }

    fun next(item: Item, t: Long = System.currentTimeMillis()): Program? =
        programs(item).firstOrNull { it.start > t }

    fun progress(p: Program, t: Long = System.currentTimeMillis()): Int {
        val len = p.end - p.start
        if (len <= 0) return 0
        return (((t - p.start) * 100) / len).toInt().coerceIn(0, 100)
    }

    fun clear() {
        synchronized(this) { byChannel.clear() }
        loaded = false
    }

    /** Volledige gids op de achtergrond laden. */
    fun load() {
        if (loaded || loading) return
        val api = Repo.api ?: return
        val wanted = Repo.live.mapNotNull { if (it.epg.isEmpty()) null else it.epg.lowercase(Locale.ROOT) }.toHashSet()
        if (wanted.isEmpty()) return
        loading = true
        Bg.go({ parse(api.xmltvUrl(), wanted) }) { r ->
            loading = false
            r.onSuccess { map ->
                synchronized(this) { byChannel.putAll(map) }
                loaded = true
                for (l in ArrayList(listeners)) l()
            }
        }
    }

    /** Reserve als een zender niet in de XMLTV staat. */
    fun fetchShort(item: Item, done: () -> Unit) {
        if (programs(item).isNotEmpty()) return
        val api = Repo.api ?: return
        Bg.go({ api.shortEpg(item.id) }) { r ->
            val list = r.getOrNull().orEmpty()
                .filter { it.end > 0 }
                .map { Program(it.start * 1000, it.end * 1000, it.title, it.desc) }
            if (list.isNotEmpty()) {
                synchronized(this) { byChannel["id:" + item.id] = list }
                done()
            }
        }
    }

    private fun parse(url: String, wanted: Set<String>): Map<String, List<Program>> {
        val from = System.currentTimeMillis() - 3 * 3600_000L
        val until = System.currentTimeMillis() + 30 * 3600_000L
        val map = HashMap<String, MutableList<Program>>()
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 120000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", Xtream.UA)
        try {
            c.inputStream.buffered().use { input ->
                val x = Xml.newPullParser()
                x.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
                x.setInput(input, null)
                var ch: String? = null
                var start = 0L
                var end = 0L
                var title = ""
                var desc = ""
                var tag = ""
                var ev = x.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    when (ev) {
                        XmlPullParser.START_TAG -> {
                            tag = x.name
                            if (tag == "programme") {
                                val id = x.getAttributeValue(null, "channel")?.lowercase(Locale.ROOT)
                                start = parseTime(x.getAttributeValue(null, "start") ?: "")
                                end = parseTime(x.getAttributeValue(null, "stop") ?: "")
                                ch = if (id != null && wanted.contains(id) && end > from && start < until) id else null
                                title = ""; desc = ""
                            }
                        }
                        XmlPullParser.TEXT -> if (ch != null) {
                            if (tag == "title" && title.isEmpty()) title = x.text.trim()
                            else if (tag == "desc" && desc.isEmpty()) desc = x.text.trim()
                        }
                        XmlPullParser.END_TAG -> {
                            if (x.name == "programme") {
                                val id = ch
                                if (id != null) map.getOrPut(id) { ArrayList() }.add(Program(start, end, title, desc))
                                ch = null
                            }
                            tag = ""
                        }
                    }
                    ev = x.next()
                }
            }
        } finally {
            c.disconnect()
        }
        return map.mapValues { e -> e.value.sortedBy { it.start } }
    }

    /** "20251126060000 +0100" -> millis */
    private fun parseTime(s: String): Long {
        if (s.length < 14) return 0L
        return try {
            cal.clear()
            cal.set(
                s.substring(0, 4).toInt(), s.substring(4, 6).toInt() - 1, s.substring(6, 8).toInt(),
                s.substring(8, 10).toInt(), s.substring(10, 12).toInt(), s.substring(12, 14).toInt()
            )
            var t = cal.timeInMillis
            val tz = s.substring(14).trim()
            if (tz.length >= 5 && (tz[0] == '+' || tz[0] == '-')) {
                val sign = if (tz[0] == '-') -1 else 1
                val mins = tz.substring(1, 3).toInt() * 60 + tz.substring(3, 5).toInt()
                t -= sign * mins * 60_000L
            }
            t
        } catch (e: Exception) {
            0L
        }
    }
}

/** Zendernummer: van de provider, anders de positie in de lijst. */
fun channelNumber(item: Item, position: Int): String = item.num.ifEmpty { (position + 1).toString() }

/** Zenderlijst zoals in TiviMate: nummer, logo, naam, huidig programma + voortgang. */
class ChannelAdapter(
    private val prefs: Prefs,
    private val onClick: (Int, Item) -> Unit,
    private val onLongClick: (Int, Item) -> Unit,
    private val onFocus: (Int, Item) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val num: TextView = v.findViewById(R.id.chNum)
        val logo: ImageView = v.findViewById(R.id.chLogo)
        val name: TextView = v.findViewById(R.id.chName)
        val prog: TextView = v.findViewById(R.id.chProgram)
        val bar: ProgressBar = v.findViewById(R.id.chProgress)
    }

    var items: List<Item> = emptyList()
        private set
    var playingId: String = ""

    fun submit(list: List<Item>) {
        items = list
        notifyDataSetChanged()
    }

    fun refresh() {
        if (items.isNotEmpty()) notifyItemRangeChanged(0, items.size)
    }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        h.num.text = channelNumber(item, position)
        h.name.text = (if (prefs.isFav(item.favKey)) "★ " else "") + item.name
        if (item.icon.isNotEmpty()) Glide.with(h.logo).load(item.icon).into(h.logo)
        else {
            Glide.with(h.logo).clear(h.logo); h.logo.setImageDrawable(null)
        }
        val now = Epg.now(item)
        if (now != null) {
            h.prog.text = now.title
            h.bar.visibility = View.VISIBLE
            h.bar.progress = Epg.progress(now)
        } else {
            h.prog.text = if (Epg.loading) "Tv-gids laden…" else "Geen informatie"
            h.bar.visibility = View.INVISIBLE
        }
        h.itemView.isActivated = item.id == playingId
        h.itemView.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(p, items[p])
        }
        h.itemView.setOnLongClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) {
                onLongClick(p, items[p]); notifyItemChanged(p)
            }
            true
        }
        h.itemView.setOnFocusChangeListener { _, f ->
            val p = h.bindingAdapterPosition
            if (f && p != RecyclerView.NO_POSITION) onFocus(p, items[p])
        }
    }
}

/** Groepenlijst (links). */
class GroupAdapter(
    private val onClick: (Int, Category) -> Unit,
    private val onFocus: (Int, Category) -> Unit
) : RecyclerView.Adapter<GroupAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.grName)
        val count: TextView = v.findViewById(R.id.grCount)
    }

    var items: List<Pair<Category, Int>> = emptyList()
        private set
    private var sel = -1

    fun submit(list: List<Pair<Category, Int>>, selected: Int) {
        items = list; sel = selected
        notifyDataSetChanged()
    }

    fun select(i: Int) {
        val old = sel; sel = i
        if (old in items.indices) notifyItemChanged(old)
        if (i in items.indices) notifyItemChanged(i)
    }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_group, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val (cat, count) = items[position]
        h.name.text = cat.name
        h.count.text = count.toString()
        h.itemView.isActivated = position == sel
        h.itemView.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(p, items[p].first)
        }
        h.itemView.setOnFocusChangeListener { _, f ->
            val p = h.bindingAdapterPosition
            if (f && p != RecyclerView.NO_POSITION) onFocus(p, items[p].first)
        }
    }
}

/** Groepen met aantallen, inclusief Favorieten en Alle zenders. */
fun liveGroups(prefs: Prefs): List<Pair<Category, Int>> {
    val out = ArrayList<Pair<Category, Int>>()
    val favs = prefs.favorites()
    val favCount = Repo.live.count { favs.contains(it.favKey) }
    if (favCount > 0) out.add(Pair(Category("FAV", "★ Favorieten"), favCount))
    out.add(Pair(Category("*", "Alle zenders"), Repo.live.size))
    for (c in Repo.liveCats) {
        val n = Repo.liveByCat[c.id]?.size ?: 0
        if (n > 0) out.add(Pair(c, n))
    }
    return out
}

fun liveChannels(prefs: Prefs, groupId: String): List<Item> = when (groupId) {
    "*" -> Repo.live
    "FAV" -> {
        val favs = prefs.favorites()
        Repo.live.filter { favs.contains(it.favKey) }
    }
    else -> Repo.liveByCat[groupId] ?: emptyList()
}

/** Programma-info als tekst, voor info-panelen. */
fun programInfo(item: Item): Triple<String, String, String> {
    val now = Epg.now(item)
    val next = Epg.next(item)
    val nowLine = if (now != null) "${Epg.time(now.start)} – ${Epg.time(now.end)}   ${now.title}" else "Geen programma-informatie"
    val nextLine = if (next != null) "Straks  ${Epg.time(next.start)}   ${next.title}" else ""
    return Triple(nowLine, now?.desc ?: "", nextLine)
}

fun dp(ctx: Context, v: Float): Int = (ctx.resources.displayMetrics.density * v).toInt()
