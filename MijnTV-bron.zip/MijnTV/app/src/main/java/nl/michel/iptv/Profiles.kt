package nl.michel.iptv

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

/** Een kijker in het huishouden. Het hoofdprofiel heeft id "". */
data class User(val id: String, val name: String, val color: Int)

/** Gebruikersprofielen. Elk profiel heeft zijn eigen opslag; deze lijst zelf is gedeeld. */
object UserProfiles {
    private val COLORS = intArrayOf(
        Color.parseColor("#E50914"), Color.parseColor("#2E7DFF"), Color.parseColor("#F5A623"),
        Color.parseColor("#2BB673"), Color.parseColor("#9B51E0"), Color.parseColor("#EB5757")
    )

    /** Keuze is in deze app-sessie al gemaakt (niet opnieuw vragen). */
    @Volatile var chosen = false

    private fun g(ctx: Context) = ctx.applicationContext.getSharedPreferences("mijntv_global", Context.MODE_PRIVATE)

    /** Opslagbestand van het actieve profiel. */
    fun file(ctx: Context): String {
        val id = active(ctx)
        return if (id.isEmpty()) "mijntv" else "mijntv_u_$id"
    }

    fun users(ctx: Context): List<User> {
        val raw = g(ctx).getString("users", null)
        val list = if (raw == null) emptyList() else runCatching {
            JSONArray(raw).objects().map { User(it.s("id"), it.s("name"), it.optInt("color", COLORS[0])) }
        }.getOrDefault(emptyList())
        return if (list.none { it.id.isEmpty() }) listOf(User("", "Hoofdprofiel", COLORS[0])) + list else list
    }

    private fun save(ctx: Context, list: List<User>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("color", it.color)) }
        g(ctx).edit().putString("users", a.toString()).apply()
    }

    fun active(ctx: Context): String = g(ctx).getString("active", "") ?: ""

    fun activeUser(ctx: Context): User = users(ctx).firstOrNull { it.id == active(ctx) } ?: users(ctx).first()

    fun setActive(ctx: Context, id: String) {
        g(ctx).edit().putString("active", id).apply()
    }

    /** null = altijd vragen */
    fun defaultUser(ctx: Context): String? = g(ctx).getString("default", null)

    fun setDefault(ctx: Context, id: String?) {
        if (id == null) g(ctx).edit().remove("default").apply() else g(ctx).edit().putString("default", id).apply()
    }

    fun rename(ctx: Context, id: String, name: String) {
        if (name.isBlank()) return
        save(ctx, users(ctx).map { if (it.id == id) it.copy(name = name.trim()) else it })
    }

    fun delete(ctx: Context, id: String) {
        if (id.isEmpty()) return
        save(ctx, users(ctx).filter { it.id != id })
        ctx.applicationContext.getSharedPreferences("mijntv_u_$id", Context.MODE_PRIVATE).edit().clear().apply()
        if (active(ctx) == id) setActive(ctx, "")
        if (defaultUser(ctx) == id) setDefault(ctx, null)
    }

    /**
     * Nieuw profiel. Met [copyFromMain] worden instellingen, providers en favorieten van het
     * hoofdprofiel overgenomen, maar niet de Trakt-koppeling en niet de kijkgeschiedenis.
     */
    fun create(ctx: Context, name: String, copyFromMain: Boolean): User {
        val list = users(ctx)
        val id = System.currentTimeMillis().toString()
        val user = User(id, name.ifBlank { "Profiel ${list.size + 1}" }, COLORS[list.size % COLORS.size])
        save(ctx, list + user)
        if (copyFromMain) {
            val from = ctx.applicationContext.getSharedPreferences("mijntv", Context.MODE_PRIVATE)
            val to = ctx.applicationContext.getSharedPreferences("mijntv_u_$id", Context.MODE_PRIVATE).edit()
            for ((k, v) in from.all) {
                if (skipOnCopy(k)) continue
                when (v) {
                    is String -> to.putString(k, v)
                    is Boolean -> to.putBoolean(k, v)
                    is Int -> to.putInt(k, v)
                    is Long -> to.putLong(k, v)
                    is Float -> to.putFloat(k, v)
                    is Set<*> -> to.putStringSet(k, v.filterIsInstance<String>().toSet())
                }
            }
            to.apply()
        }
        return user
    }

    /** Wat een nieuw profiel niet overneemt: Trakt-koppeling en kijkgeschiedenis. */
    private fun skipOnCopy(k: String): Boolean =
        k == "trakttoken" || k == "traktrefresh" || k == "recents" || k == "lastch" || k == "lastchsrc" ||
            k.startsWith("pos:") || k.startsWith("pct:") || k.startsWith("lastep:")

    // ---------- Dialogen ----------

    fun createDialog(act: Activity, done: (User) -> Unit) {
        val pad = dp(act, 20f)
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        val name = EditText(act).apply { hint = "Naam (bijv. Kinderen)"; setSingleLine(true) }
        val copy = CheckBox(act).apply {
            text = "Instellingen, providers en favorieten overnemen van het hoofdprofiel (zonder kijkgeschiedenis en Trakt)"
            isChecked = true
        }
        box.addView(name)
        box.addView(copy)
        androidx.appcompat.app.AlertDialog.Builder(act)
            .setTitle("Nieuw profiel")
            .setView(box)
            .setPositiveButton("Aanmaken") { _, _ -> done(create(act, name.text.toString(), copy.isChecked)) }
            .setNegativeButton("Annuleren", null)
            .show()
    }

    /** Naar een ander profiel: alles opnieuw laden met de gegevens van dat profiel. */
    fun switchTo(act: Activity, id: String) {
        setActive(act, id)
        chosen = true
        Repo.reset()
        Epg.clear()
        TraktSync.reset()
        act.startActivity(
            Intent(act, LoginActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        )
        act.finish()
    }

    /** Menu in de app: wisselen, toevoegen, standaard, hernoemen, verwijderen. */
    fun menu(act: Activity) {
        val users = users(act)
        val cur = active(act)
        val labels = ArrayList<CharSequence>()
        for (u in users) labels.add((if (u.id == cur) "✓  " else "     ") + u.name)
        labels.add("+  Profiel toevoegen")
        val def = defaultUser(act)
        labels.add("⭐  Standaardprofiel: " + (users.firstOrNull { it.id == def }?.name ?: "altijd vragen"))
        labels.add("✏  Naam van dit profiel wijzigen")
        if (cur.isNotEmpty()) labels.add("🗑  Dit profiel verwijderen")
        androidx.appcompat.app.AlertDialog.Builder(act)
            .setTitle("Profielen")
            .setItems(labels.toTypedArray()) { _, which ->
                when {
                    which < users.size -> if (users[which].id != cur) switchTo(act, users[which].id)
                    which == users.size -> createDialog(act) { u -> switchTo(act, u.id) }
                    which == users.size + 1 -> chooseDefault(act)
                    which == users.size + 2 -> renameDialog(act, activeUser(act))
                    else -> confirmDelete(act, activeUser(act))
                }
            }
            .show()
    }

    private fun chooseDefault(act: Activity) {
        val users = users(act)
        val labels = (users.map { it.name } + "Altijd vragen bij opstarten").map { it as CharSequence }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(act)
            .setTitle("Standaardprofiel")
            .setItems(labels) { _, which -> setDefault(act, if (which < users.size) users[which].id else null) }
            .show()
    }

    private fun renameDialog(act: Activity, u: User) {
        val field = EditText(act).apply { setSingleLine(true); setText(u.name); selectAll() }
        val pad = dp(act, 20f)
        val box = FrameLayout(act).apply { setPadding(pad, pad / 2, pad, 0); addView(field) }
        androidx.appcompat.app.AlertDialog.Builder(act)
            .setTitle("Naam wijzigen")
            .setView(box)
            .setPositiveButton("Opslaan") { _, _ ->
                rename(act, u.id, field.text.toString())
                if (act is MainActivity) act.refreshProfileButton()
            }
            .setNegativeButton("Annuleren", null)
            .show()
    }

    private fun confirmDelete(act: Activity, u: User) {
        androidx.appcompat.app.AlertDialog.Builder(act)
            .setTitle("Verwijderen?")
            .setMessage("Wil je het profiel ${u.name} verwijderen? Alle instellingen en geschiedenis van dit profiel gaan verloren.")
            .setPositiveButton("Verwijderen") { _, _ ->
                delete(act, u.id)
                switchTo(act, "")
            }
            .setNegativeButton("Annuleren", null)
            .show()
    }
}

/** "Wie kijkt er?" */
class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#141414"))
        }
        root.addView(TextView(this).apply {
            text = "Wie kijkt er?"
            setTextColor(Color.WHITE)
            textSize = 38f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(this@ProfileActivity, 36f))
        })
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(this@ProfileActivity, 40f), dp(this@ProfileActivity, 20f), dp(this@ProfileActivity, 40f), dp(this@ProfileActivity, 20f))
            clipChildren = false
            clipToPadding = false
        }
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            addView(row)
        }
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        var firstTile: View? = null
        val current = UserProfiles.active(this)
        for (u in UserProfiles.users(this)) {
            val tile = tile(u.name.take(1).uppercase(), u.name, u.color)
            tile.setOnClickListener { pick(u.id) }
            row.addView(tile)
            if (firstTile == null || u.id == current) firstTile = tile
        }
        val add = tile("+", "Profiel toevoegen", Color.parseColor("#333333"))
        add.setOnClickListener { UserProfiles.createDialog(this) { u -> pick(u.id) } }
        row.addView(add)

        setContentView(root)
        firstTile?.post { firstTile?.requestFocus() }
    }

    private fun tile(letter: String, name: String, color: Int): View {
        val size = dp(this, 140f)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            isFocusable = true
            isClickable = true
            setPadding(dp(this@ProfileActivity, 14f), 0, dp(this@ProfileActivity, 14f), 0)
        }
        val face = TextView(this).apply {
            text = letter
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 56f
            background = GradientDrawable().apply { setColor(color); cornerRadius = dp(this@ProfileActivity, 14f).toFloat() }
            if (android.os.Build.VERSION.SDK_INT >= 23) foreground = resources.getDrawable(R.drawable.card_border, theme)
            isDuplicateParentStateEnabled = true
        }
        box.addView(face, LinearLayout.LayoutParams(size, size))
        val label = TextView(this).apply {
            text = name
            setTextColor(Color.parseColor("#B3B3B3"))
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, dp(this@ProfileActivity, 12f), 0, 0)
        }
        box.addView(label, LinearLayout.LayoutParams(size, LinearLayout.LayoutParams.WRAP_CONTENT))
        box.setOnFocusChangeListener { v, f ->
            v.focusZoom(f, 1.1f)
            label.setTextColor(if (f) Color.WHITE else Color.parseColor("#B3B3B3"))
        }
        return box
    }

    private fun pick(id: String) {
        UserProfiles.setActive(this, id)
        UserProfiles.chosen = true
        Repo.reset()
        Epg.clear()
        TraktSync.reset()
        startActivity(
            Intent(this, LoginActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        )
        finish()
    }
}
