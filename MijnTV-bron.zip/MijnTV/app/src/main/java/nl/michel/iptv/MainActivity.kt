package nl.michel.iptv

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    enum class Tab { HOME, LIVE, MOVIES, SERIES, FAVS, SEARCH }

    private lateinit var prefs: Prefs
    private lateinit var rowsAdapter: RowsAdapter
    private lateinit var rowsList: RecyclerView
    private lateinit var heroImage: ImageView
    private lateinit var heroTitle: TextView
    private lateinit var heroMeta: TextView
    private lateinit var heroDesc: TextView
    private lateinit var progress: ProgressBar
    private lateinit var searchBox: EditText

    private val tabButtons = LinkedHashMap<Tab, Button>()
    private var tab = Tab.HOME
    private var heroKey = ""
    private var heroImageUrl = ""

    private val handler = Handler(Looper.getMainLooper())
    private var heroTask: Runnable? = null
    private var searchTask: Runnable? = null
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        if (!Repo.ensureApi(this)) {
            goToLogin()
            return
        }
        setContentView(R.layout.activity_main)

        heroImage = findViewById(R.id.heroImage)
        heroTitle = findViewById(R.id.heroTitle)
        heroMeta = findViewById(R.id.heroMeta)
        heroDesc = findViewById(R.id.heroDesc)
        progress = findViewById(R.id.progress)
        searchBox = findViewById(R.id.searchBox)
        rowsList = findViewById(R.id.rows)

        // Banner ongeveer 60% van de schermhoogte
        val heroBox = findViewById<View>(R.id.heroBox)
        heroBox.layoutParams.height = (resources.displayMetrics.heightPixels * 0.62f).toInt()

        rowsAdapter = RowsAdapter(
            prefs,
            onClick = { item, rowItems -> open(item, rowItems) },
            onLongClick = { item -> toggleFavorite(item) },
            onFocus = { item -> scheduleHero(item) }
        )
        rowsList.layoutManager = LinearLayoutManager(this)
        rowsList.adapter = rowsAdapter

        tabButtons[Tab.HOME] = findViewById<Button>(R.id.tabHome)
        tabButtons[Tab.LIVE] = findViewById<Button>(R.id.tabLive)
        tabButtons[Tab.MOVIES] = findViewById<Button>(R.id.tabMovies)
        tabButtons[Tab.SERIES] = findViewById<Button>(R.id.tabSeries)
        tabButtons[Tab.FAVS] = findViewById<Button>(R.id.tabFavs)
        tabButtons[Tab.SEARCH] = findViewById<Button>(R.id.tabSearch)
        for ((t, b) in tabButtons) b.setOnClickListener { setTab(t) }
        tabButtons[Tab.LIVE]?.setOnClickListener { openLive() }

        findViewById<Button>(R.id.btnLogout).setOnClickListener {
            prefs.logout()
            Repo.clear()
            Epg.clear()
            Repo.api = null
            goToLogin()
        }

        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                searchTask?.let { handler.removeCallbacks(it) }
                val r = Runnable { if (tab == Tab.SEARCH) showRows() }
                searchTask = r
                handler.postDelayed(r, 400)
            }
        })

        loadData()
    }

    override fun onResume() {
        super.onResume()
        if (!::rowsAdapter.isInitialized) return
        if (Repo.historyChanged && Repo.liveLoaded) {
            Repo.historyChanged = false
            if (tab == Tab.HOME || tab == Tab.MOVIES || tab == Tab.SERIES) showRows()
        }
    }

    private fun goToLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    // ---------- Laden ----------

    private fun loadData() {
        if (Repo.liveLoaded) {
            setTab(Tab.HOME)
            if (!Repo.restLoaded) loadRest()
            return
        }
        val api = Repo.api ?: return
        progress.visibility = View.VISIBLE
        heroTitle.text = "Even geduld…"
        heroMeta.text = ""
        heroDesc.text = "Zenders worden geladen"
        Bg.go({
            Repo.liveCats = api.categories("get_live_categories")
            Repo.live = api.liveStreams()
            Repo.liveByCat = Repo.live.groupBy { it.categoryId }
            Repo.liveLoaded = true
        }) { result ->
            if (isFinishing) return@go
            result.onSuccess {
                setTab(Tab.HOME)
                loadRest()
                Epg.load()
            }.onFailure { e ->
                progress.visibility = View.GONE
                heroTitle.text = "Laden mislukt"
                heroDesc.text = "${e.message}\nKies Home om het opnieuw te proberen."
                tabButtons[Tab.HOME]?.setOnClickListener { loadData() }
            }
        }
    }

    /** Films en series op de achtergrond laden. */
    private fun loadRest() {
        val api = Repo.api ?: return
        progress.visibility = View.VISIBLE
        Bg.go({
            runCatching { Repo.vodCats = api.categories("get_vod_categories") }
            runCatching { Repo.vod = api.vodStreams() }
            runCatching { Repo.seriesCats = api.categories("get_series_categories") }
            runCatching { Repo.series = api.series() }
            Repo.vodByCat = Repo.vod.groupBy { it.categoryId }
            Repo.seriesByCat = Repo.series.groupBy { it.categoryId }
            Repo.restLoaded = true
        }) {
            if (isFinishing) return@go
            progress.visibility = View.GONE
            tabButtons[Tab.HOME]?.setOnClickListener { setTab(Tab.HOME) }
            if (tab != Tab.SEARCH || searchBox.text.length >= 2) showRows()
        }
    }

    // ---------- Tabs & rijen ----------

    private fun setTab(t: Tab) {
        tab = t
        for ((k, b) in tabButtons) {
            b.isSelected = k == t
            b.setTypeface(null, if (k == t) Typeface.BOLD else Typeface.NORMAL)
        }
        searchBox.visibility = if (t == Tab.SEARCH) View.VISIBLE else View.GONE
        showRows()
        if (t == Tab.SEARCH) searchBox.requestFocus()
    }

    private fun favRow(title: String, type: Type?): Row? {
        val favs = prefs.favorites()
        val items = (Repo.live + Repo.vod + Repo.series).filter {
            favs.contains(it.favKey) && (type == null || it.type == type)
        }
        return if (items.isEmpty()) null else Row(title, items)
    }

    private fun recentRow(type: Type?): Row? {
        val items = prefs.recents().filter { type == null || it.type == type }
        return if (items.isEmpty()) null else Row("Verder kijken", items)
    }

    private fun catRows(cats: List<Category>, byCat: Map<String, List<Item>>): List<Row> =
        cats.mapNotNull { c ->
            val items = byCat[c.id]
            if (items.isNullOrEmpty()) null else Row(c.name, items)
        }

    private fun buildRows(): List<Row> {
        val rows = ArrayList<Row>()
        when (tab) {
            Tab.HOME -> {
                recentRow(null)?.let { rows.add(it) }
                val myList = favRow("", Type.MOVIE)?.items.orEmpty() + favRow("", Type.SERIES)?.items.orEmpty()
                if (myList.isNotEmpty()) rows.add(Row("Mijn lijst", myList))
                val newMovies = Repo.vod.filter { it.added > 0 }.sortedByDescending { it.added }.take(40)
                if (newMovies.isNotEmpty()) rows.add(Row("Nieuw toegevoegd: films", newMovies))
                val newSeries = Repo.series.filter { it.added > 0 }.sortedByDescending { it.added }.take(40)
                if (newSeries.isNotEmpty()) rows.add(Row("Nieuwe afleveringen", newSeries))
                val topMovies = Repo.vod.filter { (it.rating.toDoubleOrNull() ?: 0.0) >= 7.5 }
                    .sortedByDescending { it.added }.take(40)
                if (topMovies.isNotEmpty()) rows.add(Row("Hoog gewaardeerd", topMovies))
                rows.addAll(catRows(Repo.vodCats, Repo.vodByCat).take(6))
                rows.addAll(catRows(Repo.seriesCats, Repo.seriesByCat).take(4))
            }
            Tab.LIVE -> {}
            Tab.MOVIES -> {
                recentRow(Type.MOVIE)?.let { rows.add(it) }
                favRow("Mijn lijst", Type.MOVIE)?.let { rows.add(it) }
                val newMovies = Repo.vod.filter { it.added > 0 }.sortedByDescending { it.added }.take(40)
                if (newMovies.isNotEmpty()) rows.add(Row("Nieuw toegevoegd", newMovies))
                rows.addAll(catRows(Repo.vodCats, Repo.vodByCat))
            }
            Tab.SERIES -> {
                recentRow(Type.SERIES)?.let { rows.add(it) }
                favRow("Mijn lijst", Type.SERIES)?.let { rows.add(it) }
                val newSeries = Repo.series.filter { it.added > 0 }.sortedByDescending { it.added }.take(40)
                if (newSeries.isNotEmpty()) rows.add(Row("Nieuwe afleveringen", newSeries))
                rows.addAll(catRows(Repo.seriesCats, Repo.seriesByCat))
            }
            Tab.FAVS -> {
                favRow("Films", Type.MOVIE)?.let { rows.add(it) }
                favRow("Series", Type.SERIES)?.let { rows.add(it) }
            }
            Tab.SEARCH -> {
                val q = searchBox.text.toString().trim()
                if (q.length >= 2) {
                    fun find(list: List<Item>) = list.filter { it.name.contains(q, ignoreCase = true) }.take(100)
                    find(Repo.live).let { if (it.isNotEmpty()) rows.add(Row("Zenders", it)) }
                    find(Repo.vod).let { if (it.isNotEmpty()) rows.add(Row("Films", it)) }
                    find(Repo.series).let { if (it.isNotEmpty()) rows.add(Row("Series", it)) }
                }
            }
        }
        return rows
    }

    private fun showRows() {
        val rows = buildRows()
        rowsAdapter.submit(rows)
        rowsList.scrollToPosition(0)
        val first = rows.firstOrNull()?.items?.firstOrNull()
        if (first != null) {
            updateHero(first)
        } else {
            heroKey = ""
            setHeroImage("", false)
            heroMeta.text = ""
            when {
                tab != Tab.LIVE && !Repo.restLoaded -> {
                    heroTitle.text = "Even geduld…"; heroDesc.text = "Films en series worden nog geladen"
                }
                tab == Tab.SEARCH -> {
                    heroTitle.text = "Zoeken"; heroDesc.text = "Typ minstens 2 letters"
                }
                tab == Tab.FAVS -> {
                    heroTitle.text = "Mijn lijst is leeg"
                    heroDesc.text = "Houd OK ingedrukt op een film of serie om hem toe te voegen. Favoriete zenders staan bij Live TV."
                }
                else -> {
                    heroTitle.text = "Niets gevonden"; heroDesc.text = ""
                }
            }
        }
    }

    // ---------- Banner ----------

    private fun scheduleHero(item: Item) {
        heroTask?.let { handler.removeCallbacks(it) }
        val r = Runnable { updateHero(item) }
        heroTask = r
        handler.postDelayed(r, 250)
    }

    private fun setHeroImage(url: String, live: Boolean) {
        if (url == heroImageUrl) return
        heroImageUrl = url
        if (url.isEmpty()) {
            Glide.with(heroImage).clear(heroImage)
            heroImage.setImageDrawable(null)
            return
        }
        if (live) {
            heroImage.scaleType = ImageView.ScaleType.FIT_CENTER
            val pad = (resources.displayMetrics.density * 70).toInt()
            heroImage.setPadding(pad, pad, pad, pad)
        } else {
            heroImage.scaleType = ImageView.ScaleType.CENTER_CROP
            heroImage.setPadding(0, 0, 0, 0)
        }
        Glide.with(heroImage).load(url).into(heroImage)
    }

    private fun updateHero(item: Item) {
        heroKey = item.favKey
        heroTitle.text = item.name
        val cached = Repo.details[item.favKey]
        heroMeta.text = metaLine(item, cached)
        setHeroImage(
            (cached?.backdrop?.ifEmpty { null } ?: item.backdrop).ifEmpty { item.icon },
            item.type == Type.LIVE
        )
        val api = Repo.api ?: return
        when (item.type) {
            Type.LIVE -> {
                heroDesc.text = "Tv-gids laden…"
                Bg.go({ api.shortEpg(item.id) }) { r ->
                    if (isFinishing || heroKey != item.favKey) return@go
                    heroDesc.text = formatEpg(r.getOrNull().orEmpty())
                }
            }
            Type.MOVIE -> {
                heroDesc.text = cached?.plot ?: ""
                if (cached == null) {
                    Bg.go({ api.vodInfo(item.id) }) { r ->
                        val d = r.getOrNull() ?: return@go
                        Repo.details[item.favKey] = d
                        if (isFinishing || heroKey != item.favKey) return@go
                        heroMeta.text = metaLine(item, d)
                        heroDesc.text = d.plot
                        if (d.backdrop.isNotEmpty()) setHeroImage(d.backdrop, false)
                    }
                }
            }
            else -> heroDesc.text = item.plot
        }
    }

    private fun formatEpg(entries: List<EpgEntry>): String {
        val now = System.currentTimeMillis() / 1000
        val upcoming = entries.filter { it.end == 0L || it.end > now }
        if (upcoming.isEmpty()) return "Geen tv-gids beschikbaar"
        val sb = StringBuilder()
        upcoming.take(3).forEachIndexed { i, e ->
            if (i > 0) sb.append("\n")
            val label = if (i == 0 && e.start <= now) "NU" else "STRAKS"
            sb.append(label).append("  ")
                .append(timeFmt.format(Date(e.start * 1000))).append("–")
                .append(timeFmt.format(Date(e.end * 1000))).append("   ").append(e.title)
        }
        return sb.toString()
    }

    // ---------- Acties ----------

    private fun openLive() {
        if (!Repo.liveLoaded) {
            Toast.makeText(this, "Zenders worden nog geladen…", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, LiveActivity::class.java))
    }

    private fun open(item: Item, rowItems: List<Item>) {
        if (item.type == Type.SERIES) {
            startActivity(
                Intent(this, SeriesActivity::class.java)
                    .putExtra("item", item.toJson().toString())
            )
            return
        }
        PlayQueue.set(rowItems.filter { it.type == item.type }, item)
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun toggleFavorite(item: Item) {
        val added = prefs.toggleFav(item.favKey)
        Toast.makeText(
            this,
            if (added) "Toegevoegd aan Mijn lijst" else "Verwijderd uit Mijn lijst",
            Toast.LENGTH_SHORT
        ).show()
        if (tab == Tab.FAVS) showRows()
    }
}
