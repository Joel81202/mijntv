package nl.michel.iptv

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private var lastBack = 0L
    private var exitToast: android.widget.Toast? = null

    enum class Tab { HOME, LIVE, MOVIES, SERIES, FAVS, SEARCH }

    private lateinit var prefs: Prefs
    private lateinit var rowsAdapter: RowsAdapter
    private lateinit var rowsList: RecyclerView
    private lateinit var heroImage: ImageView
    private lateinit var heroTitle: TextView
    private lateinit var heroMeta: TextView
    private lateinit var heroDesc: TextView
    private lateinit var progress: ProgressBar
    private lateinit var searchBox: EditText

    private val tabButtons = LinkedHashMap<Tab, Button>()
    private var tab = Tab.HOME
    private var heroKey = ""
    private var heroImageUrl = ""

    private val handler = Handler(Looper.getMainLooper())
    private var heroTask: Runnable? = null
    private var searchTask: Runnable? = null
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        CrashLog.install(this)
        window.decorView.postDelayed({ if (!isFinishing) CrashLog.showIfAny(this) }, 1500)
        Cloud.init(this)
        // Beveiliging: twee keer terug om de app te sluiten
        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Diep in de rijen? Eerst terug naar boven, naar het menu (zoals Netflix)
                val cur = currentFocus
                val inMenu = cur != null && tabButtons.values.any { it == cur || it.findFocus() == cur }
                if (!inMenu && ::rowsList.isInitialized) {
                    rowsList.scrollToPosition(0)
                    (tabButtons[tab] ?: tabButtons[Tab.HOME])?.requestFocus()
                    return
                }
                val now = System.currentTimeMillis()
                if (now - lastBack < 2500) {
                    exitToast?.cancel()
                    finish()
                } else {
                    lastBack = now
                    exitToast = android.widget.Toast.makeText(
                        this@MainActivity, "Druk nogmaals op terug om MijnTV te sluiten", android.widget.Toast.LENGTH_SHORT
                    ).also { it.show() }
                }
            }
        })
        if (!Repo.ensureApi(this)) {
            goToLogin()
            return
        }
        setContentView(R.layout.activity_main)

        heroImage = findViewById(R.id.heroImage)
        heroTitle = findViewById(R.id.heroTitle)
        heroMeta = findViewById(R.id.heroMeta)
        heroDesc = findViewById(R.id.heroDesc)
        progress = findViewById(R.id.progress)
        searchBox = findViewById(R.id.searchBox)
        rowsList = findViewById(R.id.rows)

        // Banner ongeveer 60% van de schermhoogte
        val heroBox = findViewById<View>(R.id.heroBox)
        heroBox.layoutParams.height = (resources.displayMetrics.heightPixels * 0.62f).toInt()

        rowsAdapter = RowsAdapter(
            prefs,
            onClick = { item, rowItems -> open(item, rowItems) },
            onLongClick = { item -> longPress(item) },
            onFocus = { item -> scheduleHero(item) }
        )
        rowsList.layoutManager = LinearLayoutManager(this)
        rowsList.adapter = rowsAdapter

        tabButtons[Tab.HOME] = findViewById<Button>(R.id.tabHome)
        tabButtons[Tab.LIVE] = findViewById<Button>(R.id.tabLive)
        tabButtons[Tab.MOVIES] = findViewById<Button>(R.id.tabMovies)
        tabButtons[Tab.SERIES] = findViewById<Button>(R.id.tabSeries)
        tabButtons[Tab.FAVS] = findViewById<Button>(R.id.tabFavs)
        tabButtons[Tab.SEARCH] = findViewById<Button>(R.id.tabSearch)
        for ((t, b) in tabButtons) b.setOnClickListener { setTab(t) }
        tabButtons[Tab.LIVE]?.setOnClickListener { openLive() }
        findViewById<Button>(R.id.tabMatch).setOnClickListener {
            startActivity(android.content.Intent(this, MatchActivity::class.java))
        }

        findViewById<Button>(R.id.btnSettings).setOnClickListener { showSettings() }
        findViewById<Button>(R.id.btnProfile).setOnClickListener { UserProfiles.menu(this) }
        refreshProfileButton()
        Tmdb.init(this)

        findViewById<Button>(R.id.btnLogout).apply {
            text = "👤 " + Repo.currentName()
            setOnClickListener { providerMenu() }
        }

        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                searchTask?.let { handler.removeCallbacks(it) }
                val r = Runnable { if (tab == Tab.SEARCH) showRows() }
                searchTask = r
                handler.postDelayed(r, 400)
            }
        })

        loadData()
    }

    override fun onResume() {
        super.onResume()
        if (!::rowsAdapter.isInitialized) return
        // Provider gewisseld in Live TV? Dan Home bijwerken
        if (Repo.liveLoaded && shownSrc != null && shownSrc != Repo.current) {
            findViewById<Button>(R.id.btnLogout).text = "👤 " + Repo.currentName()
            setTab(tab)
            return
        }
        if (Repo.historyChanged && Repo.liveLoaded) {
            Repo.historyChanged = false
            if (tab == Tab.HOME || tab == Tab.MOVIES || tab == Tab.SERIES) showRows()
        }
        Updater.check(this)
        // Voortgang van andere apparaten ophalen
        Cloud.syncAsync(this) { changed ->
            if (changed && !isFinishing && Repo.liveLoaded && (tab == Tab.HOME || tab == Tab.MOVIES || tab == Tab.SERIES)) showRows()
        }
    }

    private fun goToLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    // ---------- Laden ----------

    /** Label "Provider · Groep" als er meer dan één provider is. */
    private fun label(src: String, name: String): String = name

    private fun loadData() {
        if (Repo.liveLoaded) {
            setTab(Tab.HOME)
            if (!Repo.restLoaded) loadRest()
            runStartup()
            return
        }
        if (Repo.apis.isEmpty()) return
        progress.visibility = View.VISIBLE
        heroTitle.text = "Even geduld…"
        heroMeta.text = ""
        heroDesc.text = "Zenders worden geladen"
        val apis = Repo.apis.toMap()
        Bg.go({
            // Alle providers tegelijk laden; een provider die niet reageert slaan we over
            val cats = ArrayList<Category>()
            val live = ArrayList<Item>()
            val errors = ArrayList<String>()
            for ((src, api) in apis) {
                try {
                    if (api.serverTz.isEmpty() && !api.isEnigma) runCatching { api.login() }
                    val c = api.categories("get_live_categories")
                    val l = api.liveStreams()
                    if (l.isEmpty() && api.isEnigma) throw java.io.IOException("geen zenders ontvangen")
                    synchronized(Repo.catSrc) { for (x in c) Repo.catSrc[x.id] = src }
                    cats.addAll(c)
                    live.addAll(l)
                    LiveCache.save(applicationContext, src, c, l)
                } catch (e: Exception) {
                    // Laatst bekende lijst gebruiken
                    val cached = LiveCache.load(applicationContext, src)
                    if (cached != null) {
                        synchronized(Repo.catSrc) { for (x in cached.first) Repo.catSrc[x.id] = src }
                        cats.addAll(cached.first)
                        live.addAll(cached.second)
                        errors.add("${Repo.names[src] ?: "Provider"} reageert niet, laatst bekende zenderlijst gebruikt")
                    } else {
                        errors.add("${Repo.names[src] ?: "Provider"}: ${e.message}")
                    }
                }
            }
            if (live.isEmpty() && errors.isNotEmpty()) throw java.io.IOException(errors.joinToString("\n"))
            Repo.liveCats = cats
            Repo.live = live
            Repo.liveByCat = live.groupBy { it.categoryId }
            Repo.liveLoaded = true
            errors
        }) { result ->
            if (isFinishing) return@go
            result.onSuccess { errors ->
                for ((src, api) in apis) if (api.serverTz.isNotEmpty()) prefs.setServerTzFor(src, api.serverTz)
                if (errors.isNotEmpty()) Toast.makeText(this, errors.joinToString("\n"), Toast.LENGTH_LONG).show()
                setTab(Tab.HOME)
                runStartup()
                loadRest()
                Epg.load()
            }.onFailure { e ->
                progress.visibility = View.GONE
                heroTitle.text = "Laden mislukt"
                heroDesc.text = "${e.message}\nKies Home om het opnieuw te proberen."
                tabButtons[Tab.HOME]?.setOnClickListener { loadData() }
            }
        }
    }

    /** Films en series van alle providers op de achtergrond laden. */
    @Volatile private var loadFailed: List<String> = emptyList()

    private fun loadRest() {
        val apis = Repo.apis.toMap()
        if (apis.isEmpty()) return
        progress.visibility = View.VISIBLE
        Bg.go({
            val vodCats = ArrayList<Category>(); val vod = ArrayList<Item>()
            val serCats = ArrayList<Category>(); val ser = ArrayList<Item>()
            val failed = ArrayList<String>()
            for ((src, api) in apis) {
                if (api.isEnigma) continue
                val before = vod.size + ser.size
                runCatching {
                    val c = api.categories("get_vod_categories")
                    synchronized(Repo.catSrc) { for (x in c) Repo.catSrc[x.id] = src }
                    vodCats.addAll(c)
                }
                runCatching { vod.addAll(api.vodStreams()) }
                runCatching {
                    val c = api.categories("get_series_categories")
                    synchronized(Repo.catSrc) { for (x in c) Repo.catSrc[x.id] = src }
                    serCats.addAll(c)
                }
                runCatching { ser.addAll(api.series()) }.onFailure { failed.add(Repo.names[src] ?: "Provider") }
                if (vod.size + ser.size == before && !failed.contains(Repo.names[src] ?: "Provider")) failed.add(Repo.names[src] ?: "Provider")
            }
            loadFailed = failed.distinct()
            Repo.vodCats = vodCats; Repo.vod = vod
            Repo.seriesCats = serCats; Repo.series = ser
            Repo.vodByCat = vod.groupBy { it.categoryId }
            Repo.seriesByCat = ser.groupBy { it.categoryId }
            Repo.restLoaded = true
        }) {
            if (isFinishing) return@go
            progress.visibility = View.GONE
            if (loadFailed.isNotEmpty()) Toast.makeText(
                this, "Films/series niet geladen van: ${loadFailed.joinToString(", ")}", Toast.LENGTH_LONG
            ).show()
            tabButtons[Tab.HOME]?.setOnClickListener { setTab(Tab.HOME) }
            if (tab != Tab.SEARCH || searchBox.text.length >= 2) showRows()
            loadTrakt()
        }
    }

    // ---------- Tabs & rijen ----------

    private fun setTab(t: Tab) {
        tab = t
        for ((k, b) in tabButtons) {
            b.isSelected = k == t
            b.setTypeface(null, if (k == t) Typeface.BOLD else Typeface.NORMAL)
        }
        searchBox.visibility = if (t == Tab.SEARCH) View.VISIBLE else View.GONE
        showRows()
        if (t == Tab.SEARCH) searchBox.requestFocus()
    }

    private fun favRow(title: String, type: Type?): Row? {
        val favs = prefs.favorites()
        val items = (Repo.live + Repo.vod + Repo.series).filter {
            Repo.isCurrent(it) && favs.contains(it.favKey) && (type == null || it.type == type)
        }
        return if (items.isEmpty()) null else Row(title, items)
    }

    private fun recentRow(type: Type?): Row? = try {
        recentRowInner(type)
    } catch (e: Throwable) {
        val where = e.stackTrace.firstOrNull { it.className.startsWith("nl.michel") }?.let { "${it.fileName}:${it.lineNumber}" } ?: ""
        Toast.makeText(this, "Fout in Verder kijken: ${e.javaClass.simpleName} ${e.message ?: ""} $where", Toast.LENGTH_LONG).show()
        null
    }

    private fun recentRowInner(type: Type?): Row? {
        val local = prefs.recents().filter { Repo.isCurrent(it) && (type == null || it.type == type) }
        // Wat je elders (bijv. in Nuvio) half gekeken hebt, via Trakt
        val fromTrakt = TraktSync.playback.mapNotNull { pb ->
            if (type != null && type != pb.type) return@mapNotNull null
            Repo.libraryMatch(pb.type, pb.tmdb, listOf(pb.title), pb.year)?.takeIf { Repo.isCurrent(it) }
        }
        val hidden = prefs.hiddenContinue()
        val items = (local + fromTrakt).distinctBy { it.favKey }.filter { !hidden.contains(it.favKey) }
        return if (items.isEmpty()) null else Row("Verder kijken", items, wide = true)
    }

    private var hiddenCache: Set<String> = emptySet()

    private fun visible(item: Item): Boolean = when (item.type) {
        Type.MOVIE -> !hiddenCache.contains("vod:" + item.categoryId)
        Type.SERIES -> !hiddenCache.contains("series:" + item.categoryId)
        Type.LIVE -> !hiddenCache.contains("live:" + item.categoryId)
        else -> true
    }

    private fun catRows(cats: List<Category>, byCat: Map<String, List<Item>>): List<Row> {
        val kind = if (byCat === Repo.vodByCat) "vod" else if (byCat === Repo.seriesByCat) "series" else "live"
        val sort = if (kind == "live") 0 else prefs.itemSort
        return arrangeCats(prefs, kind, cats).filter { c ->
            !hiddenCache.contains("$kind:" + c.id)
        }.mapNotNull { c ->
            val items = byCat[c.id]
            if (items.isNullOrEmpty()) null else Row(c.name, sortItems(items, sort))
        }
    }

    // Alleen de huidige provider
    private val curVod get() = Repo.vod.filter { Repo.isCurrent(it) }
    private val curSeries get() = Repo.series.filter { Repo.isCurrent(it) }
    private val curLive get() = Repo.live.filter { Repo.isCurrent(it) }
    private val curVodCats get() = Repo.vodCats.filter { Repo.isCurrentCat(it) }
    private val curSeriesCats get() = Repo.seriesCats.filter { Repo.isCurrentCat(it) }

    private fun buildRows(): List<Row> {
        hiddenCache = prefs.hiddenGroups()
        val rows = ArrayList<Row>()
        when (tab) {
            Tab.HOME -> {
                recentRow(null)?.let { rows.add(it) }
                val myList = favRow("", Type.MOVIE)?.items.orEmpty() + favRow("", Type.SERIES)?.items.orEmpty()
                if (myList.isNotEmpty()) rows.add(Row("Mijn lijst", myList))
                rows.addAll(Repo.traktRows)
                val newMovies = curVod.filter { it.added > 0 && visible(it) }.sortedByDescending { it.added }.take(40)
                if (newMovies.isNotEmpty()) rows.add(Row("Nieuw toegevoegd: films", newMovies))
                val newSeries = curSeries.filter { it.added > 0 && visible(it) }.sortedByDescending { it.added }.take(40)
                if (newSeries.isNotEmpty()) rows.add(Row("Nieuwe afleveringen", newSeries))
                val topMovies = curVod.filter { (it.rating.toDoubleOrNull() ?: 0.0) >= 7.5 && visible(it) }
                    .sortedByDescending { it.added }.take(40)
                if (topMovies.isNotEmpty()) rows.add(Row("Hoog gewaardeerd", topMovies))
                rows.addAll(catRows(curVodCats, Repo.vodByCat).take(6))
                rows.addAll(catRows(curSeriesCats, Repo.seriesByCat).take(4))
            }
            Tab.LIVE -> {}
            Tab.MOVIES -> {
                favRow("Mijn lijst", Type.MOVIE)?.let { rows.add(it) }
                val newMovies = curVod.filter { it.added > 0 && visible(it) }.sortedByDescending { it.added }.take(40)
                if (newMovies.isNotEmpty()) rows.add(Row("Nieuw toegevoegd", newMovies))
                rows.addAll(catRows(curVodCats, Repo.vodByCat))
            }
            Tab.SERIES -> {
                favRow("Mijn lijst", Type.SERIES)?.let { rows.add(it) }
                val newSeries = curSeries.filter { it.added > 0 && visible(it) }.sortedByDescending { it.added }.take(40)
                if (newSeries.isNotEmpty()) rows.add(Row("Nieuwe afleveringen", newSeries))
                rows.addAll(catRows(curSeriesCats, Repo.seriesByCat))
            }
            Tab.FAVS -> {
                favRow("Films", Type.MOVIE)?.let { rows.add(it) }
                favRow("Series", Type.SERIES)?.let { rows.add(it) }
            }
            Tab.SEARCH -> {
                val q = searchBox.text.toString().trim()
                if (q.length >= 2) {
                    // Zoeken in alle providers; huidige provider eerst
                    val srcs = (listOf(Repo.current) + prefs.profiles().map { it.id }).distinct().filter { Repo.apis.containsKey(it) }
                    val multi = srcs.size > 1
                    fun find(list: List<Item>, src: String) =
                        list.filter { it.src == src && visible(it) && it.name.contains(q, ignoreCase = true) }.distinctBy { it.id }.take(100)
                    for (src in srcs.ifEmpty { listOf(Repo.current) }) {
                        val tag = if (multi) "  ·  " + (Repo.names[src] ?: "Provider") else ""
                        find(Repo.live, src).let { if (it.isNotEmpty()) rows.add(Row("Zenders$tag", it)) }
                        find(Repo.vod, src).let { if (it.isNotEmpty()) rows.add(Row("Films$tag", it)) }
                        find(Repo.series, src).let { if (it.isNotEmpty()) rows.add(Row("Series$tag", it)) }
                    }
                }
            }
        }
        return dedupeRows(rows)
    }

    /** Rijen met (vrijwel) dezelfde titels maar één keer tonen; de bovenste blijft staan. */
    private fun dedupeRows(rows: List<Row>): List<Row> {
        val seen = ArrayList<Set<String>>()
        return rows.filter { row ->
            val head = row.items.take(12).map { it.favKey }.toSet()
            if (head.size < 4) return@filter true
            val dup = seen.any { prev -> head.count { prev.contains(it) } >= (head.size * 3) / 4 }
            if (!dup) seen.add(head)
            !dup
        }
    }

    private var shownSrc: String? = null

    private fun showRows() {
        shownSrc = Repo.current
        val rows = try {
            buildRows()
        } catch (e: Throwable) {
            // Niet crashen: melding tonen zodat de fout opgelost kan worden
            val where = e.stackTrace.firstOrNull { it.className.startsWith("nl.michel") }?.let { "${it.fileName}:${it.lineNumber}" } ?: ""
            Toast.makeText(this, "Fout: ${e.javaClass.simpleName} ${e.message ?: ""} $where", Toast.LENGTH_LONG).show()
            emptyList()
        }
        rowsAdapter.submit(rows)
        rowsList.scrollToPosition(0)
        val first = rows.firstOrNull()?.items?.firstOrNull()
        if (first != null) {
            updateHero(first)
        } else {
            heroKey = ""
            setHeroImage("", false)
            heroMeta.text = ""
            when {
                tab != Tab.LIVE && !Repo.restLoaded -> {
                    heroTitle.text = "Even geduld…"; heroDesc.text = "Films en series worden nog geladen"
                }
                tab == Tab.SEARCH -> {
                    heroTitle.text = "Zoeken"; heroDesc.text = "Typ minstens 2 letters"
                }
                tab == Tab.FAVS -> {
                    heroTitle.text = "Mijn lijst is leeg"
                    heroDesc.text = "Houd OK ingedrukt op een film of serie om hem toe te voegen. Favoriete zenders staan bij Live TV."
                }
                else -> {
                    heroTitle.text = "Niets gevonden"; heroDesc.text = ""
                }
            }
        }
    }

    // ---------- Banner ----------

    private fun scheduleHero(item: Item) {
        heroTask?.let { handler.removeCallbacks(it) }
        val r = Runnable { updateHero(item) }
        heroTask = r
        handler.postDelayed(r, 250)
    }

    private fun setHeroImage(url: String, live: Boolean) {
        if (url == heroImageUrl) return
        heroImageUrl = url
        if (url.isEmpty()) {
            Glide.with(heroImage).clear(heroImage)
            heroImage.setImageDrawable(null)
            return
        }
        if (live) {
            heroImage.scaleType = ImageView.ScaleType.FIT_CENTER
            val pad = (resources.displayMetrics.density * 70).toInt()
            heroImage.setPadding(pad, pad, pad, pad)
        } else {
            heroImage.scaleType = ImageView.ScaleType.CENTER_CROP
            heroImage.setPadding(0, 0, 0, 0)
        }
        Glide.with(heroImage).load(url).into(heroImage)
    }

    private fun updateHero(item: Item) {
        heroKey = item.favKey
        heroTitle.text = item.name
        val cached = Repo.details[item.favKey]
        heroMeta.text = metaLine(item, cached)
        setHeroImage(
            (cached?.backdrop?.ifEmpty { null } ?: item.backdrop).ifEmpty { item.icon },
            item.type == Type.LIVE
        )
        val api = Repo.apiFor(item) ?: return
        when (item.type) {
            Type.LIVE -> {
                heroDesc.text = "Tv-gids laden…"
                Bg.go({ api.shortEpg(item.id) }) { r ->
                    if (isFinishing || heroKey != item.favKey) return@go
                    heroDesc.text = formatEpg(r.getOrNull().orEmpty())
                }
            }
            Type.MOVIE, Type.SERIES -> {
                heroDesc.text = cached?.plot ?: item.plot
                val fromProvider = {
                    if (item.type == Type.MOVIE && cached == null) {
                        Bg.go({ api.vodInfo(item.id) }) { r ->
                            val d = r.getOrNull() ?: return@go
                            Repo.details[item.favKey] = d
                            if (isFinishing || heroKey != item.favKey) return@go
                            heroMeta.text = metaLine(item, d)
                            heroDesc.text = d.plot
                            if (d.backdrop.isNotEmpty()) setHeroImage(d.backdrop, false)
                        }
                    }
                }
                if (Tmdb.enabled) {
                    Tmdb.lookup(item) { m ->
                        if (isFinishing || heroKey != item.favKey) return@lookup
                        if (m == null) {
                            fromProvider(); return@lookup
                        }
                        heroTitle.text = m.title.ifEmpty { item.name }
                        heroMeta.text = metaLine(item, m)
                        if (m.overview.isNotEmpty()) heroDesc.text = m.overview
                        val img = m.backdrop.ifEmpty { m.poster }
                        if (img.isNotEmpty()) setHeroImage(img, false)
                    }
                } else {
                    fromProvider()
                }
            }
            else -> heroDesc.text = item.plot
        }
    }

    private fun formatEpg(entries: List<EpgEntry>): String {
        val now = System.currentTimeMillis() / 1000
        val upcoming = entries.filter { it.end == 0L || it.end > now }
        if (upcoming.isEmpty()) return "Geen tv-gids beschikbaar"
        val sb = StringBuilder()
        upcoming.take(3).forEachIndexed { i, e ->
            if (i > 0) sb.append("\n")
            val label = if (i == 0 && e.start <= now) "NU" else "STRAKS"
            sb.append(label).append("  ")
                .append(timeFmt.format(Date(e.start * 1000))).append("–")
                .append(timeFmt.format(Date(e.end * 1000))).append("   ").append(e.title)
        }
        return sb.toString()
    }

    // ---------- Acties ----------

    private fun loadTrakt() {
        if (!Trakt.linked(prefs)) return
        Bg.go({
            TraktSync.load(prefs)
            Trakt.rows(prefs)
        }) { r ->
            if (isFinishing) return@go
            r.onSuccess { rows ->
                Repo.traktRows = rows
                if (tab == Tab.HOME) showRows()
            }.onFailure { e ->
                Toast.makeText(this, e.message ?: "Trakt laden mislukt", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ---------- Providers ----------

    private fun restartFresh(target: Class<*>) {
        Repo.reset()
        Epg.clear()
        startActivity(Intent(this, target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        finish()
    }

    /** Wisselen (direct, alles blijft geladen) of beheren. */
    private fun providerMenu() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Provider: " + Repo.currentName())
            .setItems(arrayOf<CharSequence>("⇄  Wisselen van provider", "⚙  Providers beheren")) { _, which ->
                if (which == 0) chooseProvider(this, prefs) { onProviderChanged() } else showProviders()
            }
            .show()
    }

    private fun onProviderChanged() {
        findViewById<Button>(R.id.btnLogout).text = "👤 " + Repo.currentName()
        Repo.traktRows = emptyList()
        setTab(Tab.HOME)
        loadTrakt()
        if (Repo.currentApi()?.isEnigma == true) openLive()
    }

    /** Alle providers zijn tegelijk actief; hier beheer je ze. */
    private fun showProviders() {
        val list = prefs.profiles()
        val labels = ArrayList<CharSequence>()
        for (pr in list) labels.add((if (pr.kind == "enigma2") "📡  " else "📺  ") + pr.name)
        labels.add("+  Provider toevoegen")
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Providers (allemaal actief)")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which < list.size) providerOptions(list[which])
                else startActivity(Intent(this, LoginActivity::class.java).putExtra("add", true))
            }
            .show()
    }

    private fun providerOptions(pr: Profile) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(pr.name)
            .setItems(arrayOf<CharSequence>("✏  Naam wijzigen", "🗑  Verwijderen")) { _, which ->
                if (which == 0) renameProvider(pr) else confirmRemove(pr)
            }
            .show()
    }

    private fun renameProvider(pr: Profile) {
        val field = EditText(this).apply {
            setSingleLine(true)
            setText(pr.name)
            selectAll()
        }
        val pad = dp(this, 20f)
        val box = android.widget.FrameLayout(this).apply { setPadding(pad, pad / 2, pad, 0); addView(field) }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Naam wijzigen")
            .setView(box)
            .setPositiveButton("Opslaan") { _, _ ->
                prefs.renameProfile(pr.id, field.text.toString())
                restartFresh(MainActivity::class.java)
            }
            .setNegativeButton("Annuleren", null)
            .show()
    }

    private fun confirmRemove(pr: Profile) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Verwijderen?")
            .setMessage("Wil je ${pr.name} verwijderen uit MijnTV?")
            .setPositiveButton("Verwijderen") { _, _ ->
                prefs.removeProfile(pr.id)
                restartFresh(if (prefs.profiles().isNotEmpty()) MainActivity::class.java else LoginActivity::class.java)
            }
            .setNegativeButton("Annuleren", null)
            .show()
    }

    private fun showSettings() {
        val pad = dp(this, 20f)
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        val info = TextView(this).apply {
            text = "TMDB-sleutel voor Nederlandse beschrijvingen, posters, cast en achtergronden. " +
                "Gratis aan te vragen op themoviedb.org (Instellingen → API). " +
                "Zowel de 'API-sleutel' als het lange 'Read Access Token' werkt."
            textSize = 14f
        }
        val keyField = EditText(this).apply {
            hint = if (BuildConfig.TMDB_KEY.isNotEmpty()) "TMDB API-sleutel (leeg = ingebouwde sleutel)" else "TMDB API-sleutel"
            setSingleLine(true)
            setText(prefs.tmdbKey)
        }
        val hls = android.widget.CheckBox(this).apply {
            text = "Live tv als HLS (m3u8) afspelen"
            isChecked = prefs.hls
        }
        val subsOn = android.widget.CheckBox(this).apply {
            text = "Ondertitels standaard aan (Nederlands, anders Engels)"
            isChecked = prefs.subsOn
        }
        val subsLive = android.widget.CheckBox(this).apply {
            text = "Ondertitels bij live tv standaard aan"
            isChecked = prefs.subsLive
        }
        val tunneling = android.widget.CheckBox(this).apply {
            text = "Beter beeld bij live tv (tunneling). Zet uit als beeld en geluid niet gelijk lopen."
            isChecked = prefs.tunneling
        }
        val engineLabel = TextView(this).apply {
            text = "Speler voor live tv"
            textSize = 14f
            setPadding(0, pad / 2, 0, 0)
        }
        val engineGroup = android.widget.RadioGroup(this).apply { orientation = android.widget.LinearLayout.HORIZONTAL }
        val engineLabels = if (BuildConfig.HAS_ENIGMA) listOf("Automatisch (VLC voor Vu+)", "ExoPlayer", "VLC")
            else listOf("Standaard (ExoPlayer)", "ExoPlayer", "VLC")
        engineLabels.forEachIndexed { i, label ->
            if (!BuildConfig.HAS_ENIGMA && i == 1) return@forEachIndexed
            engineGroup.addView(android.widget.RadioButton(this).apply {
                text = label
                id = 6000 + i
                isChecked = prefs.liveEngine == i || (!BuildConfig.HAS_ENIGMA && i == 0 && prefs.liveEngine == 1)
            })
        }
        val delayField = EditText(this).apply {
            hint = "Geluidsvertraging VLC in ms (bijv. -125)"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
            setText(prefs.vlcAudioDelay.toString())
        }
        val delayInfo = TextView(this).apply {
            text = "Geluidsvertraging bij VLC (ms). Negatief = geluid eerder. Tijdens kijken: OK lang indrukken."
            textSize = 14f
            setPadding(0, pad / 2, 0, 0)
        }
        val sizeLabel = TextView(this).apply {
            text = "Grootte ondertitels"
            textSize = 14f
            setPadding(0, pad / 2, 0, 0)
        }
        val sizes = android.widget.RadioGroup(this).apply { orientation = android.widget.LinearLayout.HORIZONTAL }
        listOf("Klein", "Normaal", "Groot").forEachIndexed { i, label ->
            sizes.addView(android.widget.RadioButton(this).apply {
                text = label
                id = 1000 + i
                isChecked = prefs.subsSize == i
            })
        }
        val osInfo = TextView(this).apply {
            text = "OpenSubtitles.com (ondertitels downloaden). API-sleutel aanmaken via opensubtitles.com → profiel → API consumers."
            textSize = 14f
            setPadding(0, pad, 0, 0)
        }
        val osKey = EditText(this).apply { hint = "OpenSubtitles API-sleutel"; setSingleLine(true); setText(prefs.osKey) }
        val osUser = EditText(this).apply { hint = "OpenSubtitles gebruikersnaam"; setSingleLine(true); setText(prefs.osUser) }
        val osPass = EditText(this).apply {
            hint = "OpenSubtitles wachtwoord"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.osPass)
        }
        val hideCats = Button(this).apply { text = "Categorieën films/series verbergen" }
        hideCats.setOnClickListener {
            val entries = ArrayList<Pair<String, String>>()
            for (c in curVodCats) if ((Repo.vodByCat[c.id]?.size ?: 0) > 0) entries.add(Pair("vod:" + c.id, "Film · " + c.name))
            for (c in curSeriesCats) if ((Repo.seriesByCat[c.id]?.size ?: 0) > 0) entries.add(Pair("series:" + c.id, "Serie · " + c.name))
            chooseHiddenGroups(this, prefs, "Welke categorieën wil je zien?", entries) { if (Repo.liveLoaded) showRows() }
        }
        val orderCatsBtn = Button(this).apply { text = "Volgorde categorieën films/series" }
        orderCatsBtn.setOnClickListener {
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Welke volgorde?")
                .setItems(arrayOf<CharSequence>("Films", "Series")) { _, which ->
                    val (kind, cats, byCat) = if (which == 0) Triple("vod", curVodCats, Repo.vodByCat)
                    else Triple("series", curSeriesCats, Repo.seriesByCat)
                    val hidden = prefs.hiddenGroups()
                    val visibleCats = cats.filter { (byCat[it.id]?.size ?: 0) > 0 && !hidden.contains("$kind:" + it.id) }
                    reorderGroups(this, prefs, kind, visibleCats) { if (Repo.liveLoaded) showRows() }
                }
                .show()
        }
        val sortLabel = TextView(this).apply {
            text = "Sortering binnen categorieën (films/series)"
            textSize = 14f
            setPadding(0, pad / 2, 0, 0)
        }
        val sortGroup = android.widget.RadioGroup(this).apply { orientation = android.widget.LinearLayout.HORIZONTAL }
        listOf("Standaard", "Nieuwst eerst", "A–Z").forEachIndexed { i, label ->
            sortGroup.addView(android.widget.RadioButton(this).apply {
                text = label
                id = 2000 + i
                isChecked = prefs.itemSort == i
            })
        }
        val pinCats = Button(this).apply { text = "Favoriete categorieën films/series (bovenaan)" }
        pinCats.setOnClickListener {
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Welke?")
                .setItems(arrayOf<CharSequence>("Films", "Series")) { _, which ->
                    val (kind, cats, byCat) = if (which == 0) Triple("vod", curVodCats, Repo.vodByCat)
                    else Triple("series", curSeriesCats, Repo.seriesByCat)
                    choosePinned(this, prefs, kind, cats.filter { (byCat[it.id]?.size ?: 0) > 0 }) { if (Repo.liveLoaded) showRows() }
                }
                .show()
        }
        val startLabel = TextView(this).apply {
            text = "Bij openen van MijnTV"
            textSize = 14f
            setPadding(0, pad / 2, 0, 0)
        }
        val startGroup = android.widget.RadioGroup(this).apply { orientation = android.widget.LinearLayout.HORIZONTAL }
        listOf("Home", "Live TV", "Laatste zender").forEachIndexed { i, label ->
            startGroup.addView(android.widget.RadioButton(this).apply {
                text = label
                id = 3000 + i
                isChecked = prefs.startMode == i
            })
        }
        val autoStart = android.widget.CheckBox(this).apply {
            text = "Automatisch starten als de tv opstart"
            isChecked = prefs.autoStart
        }
        box.addView(startLabel)
        box.addView(startGroup)
        box.addView(autoStart)
        box.addView(pinCats)
        box.addView(hideCats)
        box.addView(orderCatsBtn)
        box.addView(sortLabel)
        box.addView(sortGroup)
        box.addView(info)
        box.addView(keyField)
        box.addView(hls)
        box.addView(subsOn)
        box.addView(subsLive)
        box.addView(tunneling)
        box.addView(engineLabel)
        box.addView(engineGroup)
        box.addView(delayInfo)
        box.addView(delayField)
        box.addView(sizeLabel)
        box.addView(sizes)
        val traktInfo = TextView(this).apply {
            text = "Trakt (je lijsten op het startscherm). Maak een app aan op app.trakt.tv/settings/apps " +
                "en vul hier de Client ID in.\n" +
                if (Trakt.linked(prefs)) "Status: gekoppeld ✓" else "Status: niet gekoppeld"
            textSize = 14f
            setPadding(0, pad, 0, 0)
        }
        val traktId = EditText(this).apply { hint = "Trakt Client ID"; setSingleLine(true); setText(prefs.traktId) }
        val traktSecret = EditText(this).apply { hint = "Trakt Client Secret (optioneel, mag leeg)"; setSingleLine(true); setText(prefs.traktSecret) }
        val traktLink = Button(this).apply { text = if (Trakt.linked(prefs)) "Trakt opnieuw koppelen" else "Trakt koppelen" }
        traktLink.setOnClickListener {
            prefs.traktId = traktId.text.toString()
            prefs.traktSecret = traktSecret.text.toString()
            Trakt.link(this, prefs) { loadTrakt() }
        }
        if (BuildConfig.HAS_TRAKT) {
            box.addView(traktInfo)
            box.addView(traktId)
            box.addView(traktSecret)
            box.addView(traktLink)
        }
        if (Cloud.configured()) {
            val last = Cloud.lastSync(this)
            box.addView(TextView(this).apply {
                text = "Cloud-back-up (Google Drive): providers, instellingen, profielen en kijkvoortgang, " +
                    "versleuteld met je pincode en gedeeld tussen al je apparaten.\n" +
                    if (Cloud.linked(this@MainActivity)) "Status: gekoppeld ✓" +
                        (if (last > 0) "  ·  laatst bijgewerkt ${Epg.day(last).lowercase()} ${Epg.time(last)}" else "")
                    else "Status: niet gekoppeld"
                textSize = 14f
                setPadding(0, pad, 0, 0)
            })
            box.addView(Button(this).apply {
                text = if (Cloud.linked(this@MainActivity)) "Opnieuw koppelen / terugzetten" else "Koppelen met Google Drive"
                setOnClickListener { Cloud.link(this@MainActivity, restoreOnly = false) { restored -> if (restored) Cloud.restart(this@MainActivity) } }
            })
            if (Cloud.linked(this)) {
                box.addView(Button(this).apply {
                    text = "Nu synchroniseren"
                    setOnClickListener {
                        Toast.makeText(this@MainActivity, "Bezig met synchroniseren…", Toast.LENGTH_SHORT).show()
                        Bg.go({ Cloud.sync(this@MainActivity) }) { r ->
                            r.onSuccess { changed ->
                                Toast.makeText(this@MainActivity, "Gesynchroniseerd", Toast.LENGTH_SHORT).show()
                                if (changed && Repo.liveLoaded) showRows()
                            }.onFailure { e -> Toast.makeText(this@MainActivity, e.message ?: "Mislukt", Toast.LENGTH_LONG).show() }
                        }
                    }
                })
                box.addView(Button(this).apply {
                    text = "Ontkoppelen (back-up blijft in Drive staan)"
                    setOnClickListener {
                        Cloud.unlink(this@MainActivity)
                        Toast.makeText(this@MainActivity, "Ontkoppeld van Google Drive", Toast.LENGTH_SHORT).show()
                    }
                })
            }
        }
        box.addView(Button(this).apply {
            text = "Controleren op updates  (nu ${BuildConfig.VERSION_NAME})"
            setOnClickListener { Updater.check(this@MainActivity, manual = true) }
        })
        box.addView(osInfo)
        box.addView(osKey)
        box.addView(osUser)
        box.addView(osPass)
        box.addView(TextView(this).apply {
            text = "Deze app gebruikt de TMDB API, maar is niet goedgekeurd of gecertificeerd door TMDB. Film- en seriegegevens: themoviedb.org"
            textSize = 12f
            alpha = 0.7f
            setPadding(0, pad, 0, pad / 2)
        })
        val scroll = android.widget.ScrollView(this).apply { addView(box) }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Instellingen")
            .setView(scroll)
            .setPositiveButton("Opslaan") { _, _ ->
                val newKey = keyField.text.toString().trim()
                if (newKey != prefs.tmdbKey) {
                    prefs.tmdbKey = newKey
                    Tmdb.key = newKey
                    Tmdb.reset()
                }
                prefs.hls = hls.isChecked
                prefs.subsOn = subsOn.isChecked
                prefs.subsLive = subsLive.isChecked
                prefs.tunneling = tunneling.isChecked
                val eng = engineGroup.checkedRadioButtonId
                if (eng >= 6000) prefs.liveEngine = eng - 6000
                delayField.text.toString().trim().toIntOrNull()?.let { prefs.vlcAudioDelay = it.coerceIn(-2000, 2000) }
                prefs.traktId = traktId.text.toString()
                prefs.traktSecret = traktSecret.text.toString()
                if (osKey.text.toString().trim() != prefs.osKey || osUser.text.toString().trim() != prefs.osUser ||
                    osPass.text.toString() != prefs.osPass
                ) {
                    prefs.osKey = osKey.text.toString()
                    prefs.osUser = osUser.text.toString()
                    prefs.osPass = osPass.text.toString()
                    OpenSubs.reset()
                }
                val startChecked = startGroup.checkedRadioButtonId
                if (startChecked >= 3000) prefs.startMode = startChecked - 3000
                val wantAuto = autoStart.isChecked
                prefs.autoStart = wantAuto
                if (wantAuto) askOverlayPermission()
                val sortChecked = sortGroup.checkedRadioButtonId
                if (sortChecked >= 2000) prefs.itemSort = sortChecked - 2000
                val checked = sizes.checkedRadioButtonId
                if (checked >= 1000) prefs.subsSize = checked - 1000
                if (Repo.liveLoaded) showRows()
            }
            .setNegativeButton("Annuleren", null)
            .show()
    }

    /** Startscherm: Home, Live TV of meteen de laatste zender (één keer per keer openen). */
    fun refreshProfileButton() {
        findViewById<Button>(R.id.btnProfile).text = "🙂 " + UserProfiles.activeUser(this).name
    }

    private fun runStartup() {
        if (Repo.autoLiveDone) return
        Repo.autoLiveDone = true
        when {
            prefs.startMode == 2 -> playLastChannel()
            prefs.startMode == 1 || Repo.currentApi()?.isEnigma == true -> openLive()
        }
    }

    /** Android 10+ laat een app bij het opstarten alleen openen met "Weergeven boven andere apps". */
    private fun askOverlayPermission() {
        if (android.os.Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(this)) return
        val i = Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName"))
        try {
            startActivity(i)
            Toast.makeText(this, "Zet 'Weergeven boven andere apps' aan voor MijnTV", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Ga naar Instellingen → Apps → Speciale app-toegang → Weergeven boven andere apps en zet MijnTV aan",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    /** Laatst bekeken zender direct op volledig scherm; terug = zenderlijst. */
    private fun playLastChannel() {
        val id = prefs.lastChannel
        val src = prefs.lastChannelSrc
        val item = Repo.live.firstOrNull { it.id == id && it.src == src } ?: Repo.live.firstOrNull { it.id == id }
        if (item == null) {
            openLive(); return
        }
        if (item.src != Repo.current) {
            Repo.current = item.src
            prefs.currentSrc = item.src
            findViewById<Button>(R.id.btnLogout).text = "👤 " + Repo.currentName()
            setTab(Tab.HOME)
        }
        var queue = liveChannels(prefs, prefs.lastGroup)
        if (!queue.contains(item)) queue = liveChannels(prefs, "*")
        PlayQueue.set(queue, item)
        startActivities(arrayOf(Intent(this, LiveActivity::class.java), Intent(this, PlayerActivity::class.java)))
    }

    private fun openLive() {
        if (!Repo.liveLoaded) {
            Toast.makeText(this, "Zenders worden nog geladen…", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, LiveActivity::class.java))
    }

    private fun open(item: Item, rowItems: List<Item>) = openItem(this, item, rowItems)

    /** OK lang indrukken: bij "Verder kijken" kun je hem ook weghalen. */
    private fun longPress(item: Item) {
        // Even wachten tot OK is losgelaten, anders "drukt" die loslaat-actie meteen in het menu
        rowsList.postDelayed({
            if (isFinishing) return@postDelayed
            runCatching { showLongPressMenu(item) }.onFailure {
                Toast.makeText(this, "Fout: ${it.javaClass.simpleName}: ${it.message}", Toast.LENGTH_LONG).show()
            }
        }, 350)
    }

    private fun showLongPressMenu(item: Item) {
        val inContinue = tab == Tab.HOME && recentRow(null)?.items?.any { it.favKey == item.favKey } == true
        if (!inContinue) { toggleFavorite(item); return }
        val fav = prefs.favorites().contains(item.favKey)
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(item.name)
            .setItems(arrayOf<CharSequence>("✕  Verwijderen uit Verder kijken", if (fav) "−  Verwijderen uit Mijn lijst" else "+  Toevoegen aan Mijn lijst")) { _, which ->
                if (which == 0) removeFromContinue(item) else toggleFavorite(item)
            }
            .show()
    }

    private fun removeFromContinue(item: Item) {
        runCatching {
            prefs.removeRecent(item.favKey)
            prefs.hideContinue(item.favKey, true)
            TraktSync.removePlayback(prefs, item)
        }.onFailure { Toast.makeText(this, "Fout: ${it.message}", Toast.LENGTH_LONG).show() }
        Toast.makeText(this, "Verwijderd uit Verder kijken", Toast.LENGTH_SHORT).show()
        rowsList.post { if (!isFinishing) showRows() }
    }

    private fun toggleFavorite(item: Item) {
        val added = prefs.toggleFav(item.favKey)
        Toast.makeText(
            this,
            if (added) "Toegevoegd aan Mijn lijst" else "Verwijderd uit Mijn lijst",
            Toast.LENGTH_SHORT
        ).show()
        if (tab == Tab.FAVS) showRows()
    }
}
