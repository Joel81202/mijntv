package nl.michel.iptv

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Profielkeuze: standaardprofiel, of "Wie kijkt er?" als er meerdere zijn
        val adding0 = intent.getBooleanExtra("add", false)
        if (!adding0 && !UserProfiles.chosen) {
            val users = UserProfiles.users(this)
            val def = UserProfiles.defaultUser(this)
            if (def != null && users.any { it.id == def }) {
                UserProfiles.setActive(this, def)
                UserProfiles.chosen = true
            } else if (users.size > 1) {
                startActivity(Intent(this, ProfileActivity::class.java))
                finish()
                return
            } else {
                UserProfiles.chosen = true
            }
        }
        val prefs = Prefs(this)
        CrashLog.install(this)
        Cloud.init(this)

        val adding = intent.getBooleanExtra("add", false)
        if (prefs.hasLogin() && !adding) {
            Repo.ensureApi(this)
            Repo.autoLiveDone = false
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_login)
        val box = findViewById<android.view.View>(R.id.loginBox)
        val dm = resources.displayMetrics
        if (dm.widthPixels / dm.density < 540) {
            box.layoutParams.width = android.view.ViewGroup.LayoutParams.MATCH_PARENT
        }
        val provName = findViewById<EditText>(R.id.provName)
        val kindE2 = findViewById<android.widget.RadioButton>(R.id.kindE2)
        val server = findViewById<EditText>(R.id.server)
        val user = findViewById<EditText>(R.id.user)
        val pass = findViewById<EditText>(R.id.pass)
        val hls = findViewById<CheckBox>(R.id.hls)
        val login = findViewById<Button>(R.id.login)
        val status = findViewById<TextView>(R.id.status)

        hls.isChecked = prefs.hls

        // Nieuw apparaat: alles terugzetten vanuit de cloud-back-up
        val restore = findViewById<Button>(R.id.btnRestore)
        if (Cloud.configured() && !adding) {
            restore.visibility = android.view.View.VISIBLE
            restore.setOnClickListener { Cloud.link(this, restoreOnly = true) { Cloud.restart(this) } }
        }

        fun applyKind() {
            val e2 = kindE2.isChecked
            server.hint = if (e2) "IP-adres van je Vu+ (bijv. 192.168.1.130)" else "Server (bijv. http://provider.com:8080)"
            user.hint = if (e2) "Gebruikersnaam (alleen als je login gebruikt)" else "Gebruikersnaam"
            pass.hint = if (e2) "Wachtwoord (alleen als je login gebruikt)" else "Wachtwoord"
            hls.visibility = if (e2) android.view.View.GONE else android.view.View.VISIBLE
        }
        val kindGroup = findViewById<android.widget.RadioGroup>(R.id.kindGroup)
        kindGroup.setOnCheckedChangeListener { _, _ -> applyKind() }
        if (!BuildConfig.HAS_ENIGMA) kindGroup.visibility = android.view.View.GONE
        applyKind()

        login.setOnClickListener {
            val s = server.text.toString().trim()
            val u = user.text.toString().trim()
            val p = pass.text.toString()
            val kind = if (kindE2.isChecked) "enigma2" else "xtream"
            if (s.isEmpty() || (u.isEmpty() && kind == "xtream")) {
                status.text = if (kind == "xtream") "Vul server en gebruikersnaam in" else "Vul het IP-adres van je Vu+ in"
                return@setOnClickListener
            }
            val api = Xtream(s, u, p, kind)
            status.text = "Bezig met inloggen…"
            login.isEnabled = false

            Bg.go({ api.login() }) { result ->
                if (isFinishing) return@go
                login.isEnabled = true
                result.onSuccess { ok ->
                    if (ok) {
                        prefs.addProfile(provName.text.toString().trim(), api.base, u, p, kind)
                        prefs.hls = hls.isChecked
                        prefs.profiles().lastOrNull()?.let { prefs.setServerTzFor(it.id, api.serverTz) }
                        Repo.reset()
                        Epg.clear()
                        Repo.ensureApi(this)
                        startActivity(
                            Intent(this, MainActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                        )
                        finish()
                    } else {
                        status.text = if (kind == "enigma2") "Vu+ niet bereikbaar. Controleer het IP-adres." else "Inloggen mislukt. Controleer je gegevens."
                    }
                }.onFailure { e ->
                    status.text = "Geen verbinding: ${e.message}"
                }
            }
        }
    }
}
