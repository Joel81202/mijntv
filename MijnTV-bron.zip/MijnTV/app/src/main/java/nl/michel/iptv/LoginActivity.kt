package nl.michel.iptv

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(this)

        val adding = intent.getBooleanExtra("add", false)
        if (prefs.hasLogin() && !adding) {
            Repo.api = Xtream(prefs.server, prefs.user, prefs.pass).also { it.serverTz = prefs.serverTz }
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_login)
        val box = findViewById<android.view.View>(R.id.loginBox)
        val dm = resources.displayMetrics
        if (dm.widthPixels / dm.density < 540) {
            box.layoutParams.width = android.view.ViewGroup.LayoutParams.MATCH_PARENT
        }
        val provName = findViewById<EditText>(R.id.provName)
        val server = findViewById<EditText>(R.id.server)
        val user = findViewById<EditText>(R.id.user)
        val pass = findViewById<EditText>(R.id.pass)
        val hls = findViewById<CheckBox>(R.id.hls)
        val login = findViewById<Button>(R.id.login)
        val status = findViewById<TextView>(R.id.status)

        hls.isChecked = prefs.hls

        login.setOnClickListener {
            val s = server.text.toString().trim()
            val u = user.text.toString().trim()
            val p = pass.text.toString()
            if (s.isEmpty() || u.isEmpty()) {
                status.text = "Vul server en gebruikersnaam in"
                return@setOnClickListener
            }
            val api = Xtream(s, u, p)
            status.text = "Bezig met inloggen…"
            login.isEnabled = false

            Bg.go({ api.login() }) { result ->
                if (isFinishing) return@go
                login.isEnabled = true
                result.onSuccess { ok ->
                    if (ok) {
                        prefs.addProfile(provName.text.toString().trim(), api.base, u, p)
                        prefs.hls = hls.isChecked
                        prefs.serverTz = api.serverTz
                        Repo.clear()
                        Epg.clear()
                        Repo.api = api
                        startActivity(
                            Intent(this, MainActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                        )
                        finish()
                    } else {
                        status.text = "Inloggen mislukt. Controleer je gegevens."
                    }
                }.onFailure { e ->
                    status.text = "Geen verbinding: ${e.message}"
                }
            }
        }
    }
}
