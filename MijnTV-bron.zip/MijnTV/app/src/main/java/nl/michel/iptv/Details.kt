package nl.michel.iptv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import org.json.JSONObject

/** Open een item op de juiste manier: detailpagina, seriepagina of speler. */
fun openItem(act: Activity, item: Item, list: List<Item>) {
    when {
        item.type == Type.SERIES && item.id.isNotEmpty() ->
            act.startActivity(Intent(act, SeriesActivity::class.java).putExtra("item", item.toJson().toString()))
        item.type == Type.MOVIE || item.type == Type.SERIES ->
            act.startActivity(Intent(act, MovieActivity::class.java).putExtra("item", item.toJson().toString()))
        else -> {
            PlayQueue.set(list.filter { it.type == item.type }, item)
            act.startActivity(Intent(act, PlayerActivity::class.java))
        }
    }
}

fun openPerson(act: Activity, p: Person) {
    act.startActivity(
        Intent(act, PersonActivity::class.java)
            .putExtra("id", p.id).putExtra("name", p.name).putExtra("photo", p.photo)
    )
}

fun RecyclerView.horizontal() {
    layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
}

fun Button.zoomOnFocus() {
    stateListAnimator = null
    setOnFocusChangeListener { v, f -> v.focusZoom(f, 1.05f) }
}

fun initials(name: String): String =
    name.split(" ").filter { it.isNotEmpty() }.take(2).joinToString("") { it.take(1).uppercase() }

/** Acteurs-kaartjes. */
class PersonAdapter(private val onClick: (Person) -> Unit) : RecyclerView.Adapter<PersonAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val photo: ImageView = v.findViewById(R.id.pPhoto)
        val fallback: TextView = v.findViewById(R.id.pFallback)
        val name: TextView = v.findViewById(R.id.pName)
        val role: TextView = v.findViewById(R.id.pRole)

        init {
            (v.findViewById<View>(R.id.pPhoto).parent as View).roundClip()
        }
    }

    private var items: List<Person> = emptyList()

    fun submit(list: List<Person>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.card_person, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val p = items[position]
        h.name.text = p.name
        h.role.text = p.role
        h.fallback.text = initials(p.name)
        if (p.photo.isNotEmpty()) Glide.with(h.photo).load(p.photo).into(h.photo)
        else {
            Glide.with(h.photo).clear(h.photo); h.photo.setImageDrawable(null)
        }
        h.itemView.setOnClickListener {
            val i = h.bindingAdapterPosition
            if (i != RecyclerView.NO_POSITION) onClick(items[i])
        }
        h.itemView.setOnFocusChangeListener { v, f -> v.focusZoom(f, 1.08f) }
    }
}

/** Afleveringen onder elkaar, zoals Netflix. */
class EpisodeAdapter(
    private val prefs: Prefs,
    private val onClick: (Item, List<Item>) -> Unit
) : RecyclerView.Adapter<EpisodeAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val num: TextView = v.findViewById(R.id.eNum)
        val thumb: ImageView = v.findViewById(R.id.eThumb)
        val title: TextView = v.findViewById(R.id.eTitle)
        val duration: TextView = v.findViewById(R.id.eDuration)
        val plot: TextView = v.findViewById(R.id.ePlot)
        val progress: ProgressBar = v.findViewById(R.id.eProgress)
        val play: View = v.findViewById(R.id.ePlay)

        init {
            v.findViewById<View>(R.id.eFrame).roundClip()
        }
    }

    var items: List<Item> = emptyList()
        private set
    var lastWatchedId = ""
    var fallbackImage = ""
    /** Afleveringnummers die op Trakt als gezien staan (huidig seizoen). */
    var watchedNums: Set<String> = emptySet()

    fun submit(list: List<Item>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_episode, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val ep = items[position]
        h.num.text = ep.num.ifEmpty { (position + 1).toString() }
        h.title.text = ep.name
        val seen = watchedNums.contains(ep.num.toIntOrNull()?.toString() ?: ep.num)
        h.duration.text = if (seen) "✓ Gezien" + (if (ep.duration.isNotEmpty()) "  ·  " + ep.duration else "") else ep.duration
        h.plot.text = ep.plot
        h.plot.visibility = if (ep.plot.isEmpty()) View.GONE else View.VISIBLE
        val img = ep.icon.ifEmpty { fallbackImage }
        if (img.isNotEmpty()) Glide.with(h.thumb).load(img).into(h.thumb)
        else {
            Glide.with(h.thumb).clear(h.thumb); h.thumb.setImageDrawable(null)
        }
        val pct = if (seen && prefs.getProgress(ep.favKey) == 0) 100 else prefs.getProgress(ep.favKey)
        h.progress.visibility = if (pct > 0) View.VISIBLE else View.GONE
        h.progress.progress = pct
        h.itemView.isActivated = ep.id == lastWatchedId
        h.play.visibility = if (h.itemView.hasFocus()) View.VISIBLE else View.INVISIBLE
        h.itemView.setOnFocusChangeListener { _, f ->
            h.play.visibility = if (f) View.VISIBLE else View.INVISIBLE
            h.play.alpha = 0f
            if (f) h.play.animate().alpha(1f).setDuration(180).start()
        }
        h.itemView.setOnClickListener {
            val i = h.bindingAdapterPosition
            if (i != RecyclerView.NO_POSITION) onClick(items[i], items)
        }
    }
}

/** Detailpagina voor films (en voor series die je provider niet heeft). */
class MovieActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var item: Item
    private lateinit var btnPlay: Button
    private lateinit var btnRestart: Button
    private lateinit var btnFav: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val parsed = intent.getStringExtra("item")?.let { runCatching { itemFromJson(JSONObject(it)) }.getOrNull() }
        if (parsed == null || !Repo.ensureApi(this)) {
            finish(); return
        }
        item = parsed
        prefs = Prefs(this)
        Tmdb.init(this)
        setContentView(R.layout.activity_movie)

        val backdrop = findViewById<ImageView>(R.id.backdrop)
        val title = findViewById<TextView>(R.id.title)
        val meta = findViewById<TextView>(R.id.meta)
        val plot = findViewById<TextView>(R.id.plot)
        val extra = findViewById<TextView>(R.id.extra)
        btnPlay = findViewById(R.id.btnPlay)
        btnRestart = findViewById(R.id.btnRestart)
        btnFav = findViewById(R.id.btnFav)
        val castTitle = findViewById<TextView>(R.id.castTitle)
        val castList = findViewById<RecyclerView>(R.id.castList)
        val recsTitle = findViewById<TextView>(R.id.recsTitle)
        val recsList = findViewById<RecyclerView>(R.id.recsList)

        title.text = item.name
        meta.text = metaLine(item)
        plot.text = item.plot
        val firstImage = item.backdrop.ifEmpty { item.icon }
        if (firstImage.isNotEmpty()) Glide.with(backdrop).load(firstImage).into(backdrop)

        val available = item.id.isNotEmpty()
        for (b in listOf(btnPlay, btnRestart, btnFav)) b.zoomOnFocus()
        if (!available) {
            if (BuildConfig.HAS_NUVIO) {
                btnPlay.text = "▶  Afspelen via Nuvio"
                btnPlay.setOnClickListener { Nuvio.open(this, item) }
            } else {
                btnPlay.text = "Niet beschikbaar bij je provider"
                btnPlay.isEnabled = false
                btnPlay.isFocusable = false
            }
            btnFav.visibility = View.GONE
        } else {
            btnPlay.setOnClickListener { play(false) }
            btnRestart.setOnClickListener { play(true) }
            btnFav.setOnClickListener {
                prefs.toggleFav(item.favKey)
                updateFav()
            }
            updateFav()
        }

        val castAdapter = PersonAdapter { p -> openPerson(this, p) }
        castList.horizontal()
        castList.adapter = castAdapter
        val recsAdapter = CardAdapter(
            prefs,
            onClick = { it, list -> openItem(this, it, list) },
            onLongClick = { },
            onFocus = { }
        )
        recsList.horizontal()
        recsList.adapter = recsAdapter

        // Eerst info van de provider (werkt ook zonder TMDB)
        val api = Repo.apiFor(item)
        if (available && item.type == Type.MOVIE && api != null) {
            Bg.go({ api.vodInfo(item.id) }) { r ->
                val d = r.getOrNull() ?: return@go
                if (isFinishing) return@go
                Repo.details[item.favKey] = d
                if (plot.text.isNullOrEmpty()) plot.text = d.plot
                if (!Tmdb.enabled) {
                    meta.text = metaLine(item, d)
                    if (d.backdrop.isNotEmpty()) Glide.with(backdrop).load(d.backdrop).into(backdrop)
                }
                if (extra.text.isNullOrEmpty()) {
                    extra.text = listOfNotNull(
                        d.director.takeIf { it.isNotEmpty() }?.let { "Regie: $it" },
                        d.cast.takeIf { it.isNotEmpty() }?.let { "Met: $it" }
                    ).joinToString("\n")
                }
            }
        }

        // Daarna de Nederlandse info, cast en aanbevelingen van TMDB
        Tmdb.lookup(item) { m ->
            if (m == null || isFinishing) return@lookup
            title.text = m.title.ifEmpty { item.name }
            meta.text = (if (TraktSync.isMovieWatched(item)) "✓ Gezien   •   " else "") + metaLine(item, m)
            if (m.overview.isNotEmpty()) plot.text = m.overview
            val img = m.backdrop.ifEmpty { m.poster }
            if (img.isNotEmpty()) Glide.with(backdrop).load(img).into(backdrop)
            Tmdb.trailer(item.type, m.tmdbId) { key ->
                if (key == null || isFinishing) return@trailer
                findViewById<Button>(R.id.btnTrailer).apply {
                    visibility = View.VISIBLE
                    zoomOnFocus()
                    setOnClickListener { Tmdb.playTrailer(this@MovieActivity, key) }
                }
            }
            Tmdb.credits(item.type, m.tmdbId) { c ->
                if (c == null || isFinishing) return@credits
                if (c.director.isNotEmpty()) {
                    extra.text = (if (item.type == Type.MOVIE) "Regie: " else "Bedacht door: ") + c.director
                }
                if (c.cast.isNotEmpty()) {
                    castTitle.visibility = View.VISIBLE
                    castAdapter.submit(c.cast)
                }
                if (c.recs.isNotEmpty()) {
                    recsTitle.visibility = View.VISIBLE
                    recsAdapter.submit(c.recs)
                }
            }
        }

        if (btnPlay.isFocusable) btnPlay.requestFocus() else castList.requestFocus()
    }

    override fun onResume() {
        super.onResume()
        if (::item.isInitialized && item.id.isNotEmpty()) updatePlay()
    }

    private fun updateFav() {
        btnFav.text = if (prefs.isFav(item.favKey)) "✓  Mijn lijst" else "+  Mijn lijst"
    }

    private fun updatePlay() {
        val pos = prefs.getPos(item.favKey)
        if (pos > 0) {
            val t = pos / 1000
            val txt = if (t >= 3600) String.format("%d:%02d:%02d", t / 3600, (t % 3600) / 60, t % 60)
            else String.format("%d:%02d", t / 60, t % 60)
            btnPlay.text = "▶  Verder kijken ($txt)"
            btnRestart.visibility = View.VISIBLE
        } else {
            btnPlay.text = "▶  Afspelen"
            btnRestart.visibility = View.GONE
        }
    }

    private fun play(fromStart: Boolean) {
        if (fromStart) prefs.clearPos(item.favKey)
        PlayQueue.set(listOf(item), item)
        startActivity(Intent(this, PlayerActivity::class.java))
    }
}

/** Acteurspagina met biografie en filmografie. */
class PersonActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("id")
        if (id.isNullOrEmpty() || !Repo.ensureApi(this)) {
            finish(); return
        }
        val prefs = Prefs(this)
        Tmdb.init(this)
        setContentView(R.layout.activity_person)

        val name = intent.getStringExtra("name") ?: ""
        val photo = findViewById<ImageView>(R.id.personPhoto)
        val backdrop = findViewById<ImageView>(R.id.backdrop)
        val title = findViewById<TextView>(R.id.title)
        val meta = findViewById<TextView>(R.id.meta)
        val bio = findViewById<TextView>(R.id.plot)
        findViewById<TextView>(R.id.personInitials).text = initials(name)
        title.text = name
        bio.text = "Laden…"
        intent.getStringExtra("photo")?.takeIf { it.isNotEmpty() }?.let { Glide.with(photo).load(it).into(photo) }

        fun section(titleId: Int, listId: Int): Pair<TextView, CardAdapter> {
            val adapter = CardAdapter(
                prefs,
                onClick = { it, list -> openItem(this, it, list) },
                onLongClick = { },
                onFocus = { it ->
                    val img = it.backdrop
                    if (img.isNotEmpty()) Glide.with(backdrop).load(img).into(backdrop)
                }
            )
            val rv = findViewById<RecyclerView>(listId)
            rv.horizontal()
            rv.adapter = adapter
            return Pair(findViewById(titleId), adapter)
        }
        val (moviesTitle, moviesAdapter) = section(R.id.moviesTitle, R.id.moviesList)
        val (showsTitle, showsAdapter) = section(R.id.showsTitle, R.id.showsList)

        Tmdb.person(id) { p ->
            if (isFinishing) return@person
            if (p == null) {
                bio.text = "Geen informatie gevonden."
                return@person
            }
            title.text = p.name.ifEmpty { name }
            meta.text = p.born
            bio.text = p.bio.ifEmpty { "Geen biografie beschikbaar." }
            if (p.photo.isNotEmpty()) Glide.with(photo).load(p.photo).into(photo)
            val availM = p.movies.count { it.id.isNotEmpty() }
            val availS = p.shows.count { it.id.isNotEmpty() }
            if (p.movies.isNotEmpty()) {
                moviesTitle.visibility = View.VISIBLE
                moviesTitle.text = if (availM > 0) "Films  ·  $availM beschikbaar" else "Films"
                moviesAdapter.submit(p.movies.sortedByDescending { it.id.isNotEmpty() })
            }
            if (p.shows.isNotEmpty()) {
                showsTitle.visibility = View.VISIBLE
                showsTitle.text = if (availS > 0) "Series  ·  $availS beschikbaar" else "Series"
                showsAdapter.submit(p.shows.sortedByDescending { it.id.isNotEmpty() })
            }
            findViewById<RecyclerView>(if (p.movies.isNotEmpty()) R.id.moviesList else R.id.showsList)
                .post { findViewById<RecyclerView>(if (p.movies.isNotEmpty()) R.id.moviesList else R.id.showsList).getChildAt(0)?.requestFocus() }
        }
        if (!Tmdb.enabled) {
            bio.text = "Stel eerst een TMDB-sleutel in via ⚙ Instellingen."
            Toast.makeText(this, "TMDB-sleutel nodig", Toast.LENGTH_SHORT).show()
        }
    }
}
