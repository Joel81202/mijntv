package nl.michel.iptv

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** Live tv in lijstweergave (TiviMate-stijl) met voorbeeldscherm. */
class LiveActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var groupAdapter: GroupAdapter
    private lateinit var channelAdapter: ChannelAdapter
    private lateinit var channelList: RecyclerView
    private lateinit var groupTitle: TextView
    private lateinit var clock: TextView
    private lateinit var preview: PlayerView
    private lateinit var infoChannel: TextView
    private lateinit var infoNow: TextView
    private lateinit var infoProgress: ProgressBar
    private lateinit var infoDesc: TextView
    private lateinit var infoNext: TextView

    private var player: ExoPlayer? = null
    private var groupId = "*"
    private var focused: Item? = null
    private var previewItem: Item? = null
    private var useHls = false
    private var triedAlt = false

    private val handler = Handler(Looper.getMainLooper())
    private var previewTask: Runnable? = null
    private val epgListener: () -> Unit = {
        if (::channelAdapter.isInitialized) {
            channelAdapter.refresh()
            focused?.let { showInfo(it) }
        }
    }
    private val ticker = object : Runnable {
        override fun run() {
            clock.text = Epg.time(System.currentTimeMillis())
            channelAdapter.refresh()
            focused?.let { showInfo(it) }
            handler.postDelayed(this, 30_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Repo.liveLoaded || Repo.api == null) {
            finish()
            return
        }
        prefs = Prefs(this)
        useHls = prefs.hls
        setContentView(R.layout.activity_live)

        channelList = findViewById(R.id.channels)
        groupTitle = findViewById(R.id.liveGroupTitle)
        clock = findViewById(R.id.clock)
        preview = findViewById(R.id.preview)
        infoChannel = findViewById(R.id.infoChannel)
        infoNow = findViewById(R.id.infoNow)
        infoProgress = findViewById(R.id.infoProgress)
        infoDesc = findViewById(R.id.infoDesc)
        infoNext = findViewById(R.id.infoNext)
        preview.useController = false

        // Op smalle schermen (telefoon) geen voorbeeldkolom
        val dm = resources.displayMetrics
        if (dm.widthPixels / dm.density < 900) findViewById<View>(R.id.previewColumn).visibility = View.GONE

        groupAdapter = GroupAdapter(
            onClick = { pos, cat -> selectGroup(pos, cat, true) },
            onFocus = { _, _ -> }
        )
        channelAdapter = ChannelAdapter(
            prefs,
            onClick = { pos, item -> playFullscreen(pos, item) },
            onLongClick = { _, item -> toggleFav(item) },
            onFocus = { _, item -> onChannelFocus(item) }
        )
        findViewById<RecyclerView>(R.id.groups).apply {
            layoutManager = LinearLayoutManager(this@LiveActivity)
            adapter = groupAdapter
        }
        channelList.layoutManager = LinearLayoutManager(this)
        channelList.itemAnimator = null
        channelList.adapter = channelAdapter

        findViewById<View>(R.id.previewBox).setOnClickListener {
            val item = previewItem ?: focused ?: return@setOnClickListener
            val i = channelAdapter.items.indexOf(item)
            playFullscreen(if (i >= 0) i else 0, item)
        }
        findViewById<Button>(R.id.btnGuide).setOnClickListener {
            startActivity(Intent(this, GuideActivity::class.java).putExtra("group", groupId))
        }

        // Laatste groep en zender herstellen
        val groups = liveGroups(prefs)
        var gi = groups.indexOfFirst { it.first.id == prefs.lastGroup }
        if (gi < 0) gi = groups.indexOfFirst { it.first.id == "*" }.coerceAtLeast(0)
        groupAdapter.submit(groups, gi)
        groups.getOrNull(gi)?.let { selectGroup(gi, it.first, false) }

        val lastId = prefs.lastChannel
        val idx = channelAdapter.items.indexOfFirst { it.id == lastId }
        if (idx >= 0) {
            (channelList.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(idx, dp(this, 120f))
            focused = channelAdapter.items[idx]
            previewItem = channelAdapter.items[idx]
            showInfo(channelAdapter.items[idx])
            channelList.post {
                channelList.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus()
            }
        } else {
            channelList.post { channelList.getChildAt(0)?.requestFocus() }
        }

        Epg.addListener(epgListener)
        Epg.load()
    }

    override fun onStart() {
        super.onStart()
        if (!::prefs.isInitialized) return
        handler.post(ticker)
        if (findViewById<View>(R.id.previewColumn).visibility == View.VISIBLE) {
            initPlayer()
            previewItem?.let { startPreview(it) }
        }
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        if (::preview.isInitialized) preview.player = null
    }

    override fun onDestroy() {
        Epg.removeListener(epgListener)
        super.onDestroy()
    }

    private fun selectGroup(pos: Int, cat: Category, moveFocus: Boolean) {
        groupId = cat.id
        prefs.lastGroup = cat.id
        groupAdapter.select(pos)
        val list = liveChannels(prefs, cat.id)
        channelAdapter.playingId = previewItem?.id ?: ""
        channelAdapter.submit(list)
        groupTitle.text = "${cat.name}  ·  ${list.size} zenders"
        channelList.scrollToPosition(0)
        if (moveFocus) channelList.post { channelList.getChildAt(0)?.requestFocus() }
    }

    private fun onChannelFocus(item: Item) {
        focused = item
        showInfo(item)
        Epg.fetchShort(item) { if (focused == item) showInfo(item); channelAdapter.refresh() }
        previewTask?.let { handler.removeCallbacks(it) }
        if (player != null && item != previewItem) {
            val r = Runnable { startPreview(item) }
            previewTask = r
            handler.postDelayed(r, 900)
        }
    }

    private fun showInfo(item: Item) {
        val (now, desc, next) = programInfo(item)
        infoChannel.text = item.name
        infoNow.text = now
        infoDesc.text = desc
        infoNext.text = next
        val p = Epg.now(item)
        infoProgress.visibility = if (p != null) View.VISIBLE else View.INVISIBLE
        if (p != null) infoProgress.progress = Epg.progress(p)
    }

    // ---------- Voorbeeldscherm ----------

    private fun initPlayer() {
        if (player != null) return
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(Xtream.UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(30000)
        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val item = previewItem ?: return
                if (!triedAlt) {
                    triedAlt = true
                    useHls = !useHls
                    play(item)
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY && triedAlt) prefs.hls = useHls
            }
        })
        preview.player = p
        player = p
    }

    private fun startPreview(item: Item) {
        previewItem = item
        triedAlt = false
        useHls = prefs.hls
        channelAdapter.playingId = item.id
        channelAdapter.refresh()
        play(item)
    }

    private fun play(item: Item) {
        val p = player ?: return
        val api = Repo.api ?: return
        val mi = MediaItem.Builder()
            .setUri(api.streamUrl(item, useHls))
            .setMimeType(if (useHls) MimeTypes.APPLICATION_M3U8 else MimeTypes.VIDEO_MP2T)
            .build()
        p.setMediaItem(mi)
        p.prepare()
        p.playWhenReady = true
    }

    // ---------- Acties ----------

    private fun playFullscreen(pos: Int, item: Item) {
        prefs.lastChannel = item.id
        previewItem = item
        PlayQueue.set(channelAdapter.items, item)
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun toggleFav(item: Item) {
        val added = prefs.toggleFav(item.favKey)
        Toast.makeText(this, if (added) "Toegevoegd aan Favorieten" else "Verwijderd uit Favorieten", Toast.LENGTH_SHORT).show()
        val groups = liveGroups(prefs)
        val gi = groups.indexOfFirst { it.first.id == groupId }
        groupAdapter.submit(groups, gi)
        if (groupId == "FAV") {
            if (gi >= 0) selectGroup(gi, groups[gi].first, false)
            else selectGroup(0, groups[0].first, true)
        }
    }
}
