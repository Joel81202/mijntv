package nl.michel.iptv

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** Live tv in lijstweergave (TiviMate-stijl) met voorbeeldscherm. */
class LiveActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var groupAdapter: GroupAdapter
    private lateinit var channelAdapter: ChannelAdapter
    private lateinit var channelList: RecyclerView
    private lateinit var groupTitle: TextView
    private lateinit var clock: TextView
    private lateinit var preview: PlayerView
    private lateinit var infoChannel: TextView
    private lateinit var infoNow: TextView
    private lateinit var infoProgress: ProgressBar
    private lateinit var infoDesc: TextView
    private lateinit var programAdapter: ProgramAdapter
    private lateinit var programList: RecyclerView

    private var player: ExoPlayer? = null
    private var groupId = "*"
    private var focused: Item? = null
    private var previewItem: Item? = null
    private var useHls = false
    private var triedAlt = false

    private val handler = Handler(Looper.getMainLooper())
    private var previewTask: Runnable? = null
    private val epgListener: () -> Unit = {
        if (::channelAdapter.isInitialized) {
            channelAdapter.refresh()
            focused?.let { showInfo(it) }
        }
    }
    private val ticker = object : Runnable {
        override fun run() {
            clock.text = Epg.time(System.currentTimeMillis())
            channelAdapter.refresh()
            focused?.let { showInfo(it) }
            handler.postDelayed(this, 30_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Repo.liveLoaded || Repo.api == null) {
            finish()
            return
        }
        prefs = Prefs(this)
        useHls = prefs.hls
        setContentView(R.layout.activity_live)

        channelList = findViewById(R.id.channels)
        groupTitle = findViewById(R.id.liveGroupTitle)
        clock = findViewById(R.id.clock)
        preview = findViewById(R.id.preview)
        infoChannel = findViewById(R.id.infoChannel)
        infoNow = findViewById(R.id.infoNow)
        infoProgress = findViewById(R.id.infoProgress)
        infoDesc = findViewById(R.id.infoDesc)
        programList = findViewById(R.id.programList)
        programAdapter = ProgramAdapter { p -> onProgramClick(p) }
        programList.layoutManager = LinearLayoutManager(this)
        programList.itemAnimator = null
        programList.adapter = programAdapter
        preview.useController = false

        // Op smalle schermen (telefoon) geen voorbeeldkolom
        val dm = resources.displayMetrics
        if (dm.widthPixels / dm.density < 900) findViewById<View>(R.id.previewColumn).visibility = View.GONE

        groupAdapter = GroupAdapter(
            onClick = { pos, cat -> selectGroup(pos, cat, true) },
            onFocus = { _, _ -> }
        )
        channelAdapter = ChannelAdapter(
            prefs,
            onClick = { pos, item -> playFullscreen(pos, item) },
            onLongClick = { _, item -> toggleFav(item) },
            onFocus = { _, item -> onChannelFocus(item) }
        )
        findViewById<RecyclerView>(R.id.groups).apply {
            layoutManager = LinearLayoutManager(this@LiveActivity)
            adapter = groupAdapter
        }
        channelList.layoutManager = LinearLayoutManager(this)
        channelList.itemAnimator = null
        channelList.adapter = channelAdapter

        findViewById<View>(R.id.previewBox).setOnClickListener {
            val item = previewItem ?: focused ?: return@setOnClickListener
            val i = channelAdapter.items.indexOf(item)
            playFullscreen(if (i >= 0) i else 0, item)
        }
        val btnProvider = findViewById<Button>(R.id.btnProvider)
        btnProvider.text = "👤 " + Repo.currentName()
        // Alle providers staan nu links onder elkaar; wisselen is niet meer nodig
        btnProvider.visibility = View.GONE
        btnProvider.setOnClickListener {
            chooseProvider(this, prefs) {
                btnProvider.text = "👤 " + Repo.currentName()
                groupId = "*"
                reloadGroups()
                channelList.post { channelList.getChildAt(0)?.requestFocus() }
            }
        }

        findViewById<Button>(R.id.btnGroups).setOnClickListener {
            val multi = Repo.apis.size > 1
            val withChannels = Repo.liveCats.filter { (Repo.liveByCat[it.id]?.size ?: 0) > 0 }
                .map { c -> if (multi) Category(c.id, (Repo.names[Repo.catSrc[c.id] ?: ""] ?: "") + " · " + c.name) else c }
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Groepen")
                .setItems(arrayOf<CharSequence>("★  Favoriete groepen (bovenaan)", "👁  Tonen / verbergen", "↕  Volgorde wijzigen")) { _, which ->
                    val hidden = prefs.hiddenGroups()
                    when (which) {
                        0 -> choosePinned(this, prefs, "live", withChannels.filter { !hidden.contains("live:" + it.id) }) { reloadGroups() }
                        1 -> {
                            val entries = ArrayList<Pair<String, String>>()
                            entries.add(Pair("live:FAV", "★ Favorieten"))
                            for (c in arrangeCats(prefs, "live", withChannels)) entries.add(Pair("live:" + c.id, c.name))
                            chooseHiddenGroups(this, prefs, "Welke groepen wil je zien?", entries) { reloadGroups() }
                        }
                        else -> reorderGroups(this, prefs, "live", withChannels.filter { !hidden.contains("live:" + it.id) }) { reloadGroups() }
                    }
                }
                .show()
        }
        findViewById<Button>(R.id.btnMatch).setOnClickListener {
            stopPreview()
            startActivity(Intent(this, MatchActivity::class.java))
        }
        findViewById<Button>(R.id.btnGuide).setOnClickListener {
            startActivity(Intent(this, GuideActivity::class.java).putExtra("group", groupId))
        }

        // Laatste groep en zender herstellen
        val groups = liveGroups(prefs)
        var gi = groups.indexOfFirst { it.first.id == prefs.lastGroup }
        if (gi < 0) gi = groups.indexOfFirst { it.first.id == "*@" + prefs.lastChannelSrc }
        if (gi < 0) gi = groups.indexOfFirst { it.first.id == "*@" + Repo.current }
        if (gi < 0) gi = groups.indexOfFirst { !isGroupHeader(it.first.id) }.coerceAtLeast(0)
        groupAdapter.submit(groups, gi)
        groups.getOrNull(gi)?.let { selectGroup(gi, it.first, false) }

        val lastId = prefs.lastChannel
        val idx = channelAdapter.items.indexOfFirst { it.id == lastId }
        if (idx >= 0) {
            (channelList.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(idx, dp(this, 120f))
            focused = channelAdapter.items[idx]
            previewItem = channelAdapter.items[idx]
            showInfo(channelAdapter.items[idx])
            channelList.post {
                channelList.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus()
            }
        } else {
            channelList.post { channelList.getChildAt(0)?.requestFocus() }
        }

        Epg.addListener(epgListener)
        Epg.load()
    }

    private val screenOff = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: android.content.Context, i: android.content.Intent) {
            handler.removeCallbacksAndMessages(null)
            if (::preview.isInitialized) stopPreview()
        }
    }

    override fun onStart() {
        super.onStart()
        runCatching { registerReceiver(screenOff, android.content.IntentFilter(android.content.Intent.ACTION_SCREEN_OFF)) }
        if (!::prefs.isInitialized) return
        handler.post(ticker)
        syncWithPlayer()
        if (findViewById<View>(R.id.previewColumn).visibility == View.VISIBLE) {
            // Even wachten tot de grote speler zijn verbinding heeft gesloten
            handler.postDelayed({
                if (isFinishing) return@postDelayed
                initPlayer()
                previewItem?.let { startPreview(it) }
            }, 700)
        }
    }

    override fun onStop() {
        super.onStop()
        runCatching { unregisterReceiver(screenOff) }
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        if (::preview.isInitialized) preview.player = null
    }

    override fun onDestroy() {
        Epg.removeListener(epgListener)
        super.onDestroy()
    }

    /** Terug uit volledig scherm: naar de zender die je op dat moment keek (ook na zappen). */
    private fun syncWithPlayer() {
        val cur = PlayQueue.current() ?: return
        if (cur.type != Type.LIVE || cur == previewItem) return
        val idx = channelAdapter.items.indexOf(cur)
        if (idx < 0) return
        previewItem = cur
        focused = cur
        channelAdapter.playingId = cur.id
        channelAdapter.refresh()
        showInfo(cur)
        (channelList.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(idx, dp(this, 120f))
        channelList.post { channelList.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus() }
    }

    private fun selectGroup(pos: Int, cat: Category, moveFocus: Boolean) {
        groupId = cat.id
        prefs.lastGroup = cat.id
        groupAdapter.select(pos)
        val list = liveChannels(prefs, cat.id)
        channelAdapter.playingId = previewItem?.id ?: ""
        channelAdapter.submit(list)
        groupTitle.text = (if (Repo.apis.size > 1) (Repo.names[groupSrc(cat.id)] ?: "") + "  ·  " else "") + "${cat.name}  ·  ${list.size} zenders"
        channelList.scrollToPosition(0)
        if (moveFocus) channelList.post { channelList.getChildAt(0)?.requestFocus() }
    }

    private fun reloadGroups() {
        val groups = liveGroups(prefs)
        var gi = groups.indexOfFirst { it.first.id == groupId }
        if (gi < 0) gi = groups.indexOfFirst { it.first.id == "*@" + groupSrc(groupId) }
        if (gi < 0) gi = groups.indexOfFirst { !isGroupHeader(it.first.id) }.coerceAtLeast(0)
        groupAdapter.submit(groups, gi)
        groups.getOrNull(gi)?.let { selectGroup(gi, it.first, false) }
    }

    private fun onChannelFocus(item: Item) {
        focused = item
        showInfo(item)
        Epg.fetchShort(item) { if (focused == item) showInfo(item); channelAdapter.refresh() }
        Epg.fetchArchive(item) { if (focused == item) showInfo(item) }
        previewTask?.let { handler.removeCallbacks(it) }
        if (player != null && item != previewItem) {
            val r = Runnable { startPreview(item) }
            previewTask = r
            handler.postDelayed(r, 900)
        }
    }

    private var programChannelId = ""

    private fun showInfo(item: Item) {
        val (now, desc, _) = programInfo(item)
        infoChannel.text = item.name + if (item.archive > 0) "   ⏪ ${item.archive} dagen terugkijken" else ""
        infoNow.text = now
        infoDesc.text = desc
        val p = Epg.now(item)
        infoProgress.visibility = if (p != null) View.VISIBLE else View.INVISIBLE
        if (p != null) infoProgress.progress = Epg.progress(p)

        // Programmalijst: nu en de komende programma's (terugkijken: nog een keer naar rechts)
        val t = System.currentTimeMillis()
        val all = Epg.programs(item)
        val list = all.filter { it.end > t }.take(150)
        val sameChannel = programChannelId == item.id
        programChannelId = item.id
        if (programList.hasFocus() && sameChannel) {
            programAdapter.notifyDataSetChanged()
            return
        }
        programAdapter.submit(item, list)
        val nowIndex = list.indexOfFirst { it.end > t }.coerceAtLeast(0)
        (programList.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(nowIndex, 0)
    }

    /** Nog een keer naar rechts in de programmalijst: volledige gids van deze zender (afgelopen week). */
    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.action == android.view.KeyEvent.ACTION_DOWN && event.keyCode == android.view.KeyEvent.KEYCODE_DPAD_RIGHT &&
            programList.hasFocus()
        ) {
            val ch = programAdapter.channel ?: focused
            if (ch != null) {
                stopPreview()
                ChannelEpgActivity.channel = ch
                ChannelEpgActivity.channels = channelAdapter.items
                startActivity(Intent(this, ChannelEpgActivity::class.java))
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun onProgramClick(p: Program) {
        val ch = programAdapter.channel ?: return
        val now = System.currentTimeMillis()
        when {
            p.start <= now && p.end > now -> {
                val i = channelAdapter.items.indexOf(ch)
                playFullscreen(if (i >= 0) i else 0, ch)
            }
            p.end <= now && Epg.canCatchup(ch, p, now) -> {
                stopPreview()
                val item = Epg.catchupItem(ch, p)
                PlayQueue.set(listOf(item), item)
                startActivity(Intent(this, PlayerActivity::class.java))
            }
            p.start > now -> Toast.makeText(this, "Begint om ${Epg.time(p.start)}", Toast.LENGTH_SHORT).show()
            else -> Toast.makeText(this, "Deze uitzending is niet terug te kijken", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Voorbeeldscherm ----------

    private fun initPlayer() {
        if (player != null) return
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(Xtream.UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(30000)
            .setDefaultRequestProperties(Repo.api?.streamHeaders() ?: emptyMap())
        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val item = previewItem ?: return
                if (!triedAlt) {
                    triedAlt = true
                    useHls = !useHls
                    play(item)
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY && triedAlt) prefs.hls = useHls
            }
        })
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setPreferredAudioLanguages("nl", "dut", "nld")
            .setPreferredAudioRoleFlags(C.ROLE_FLAG_MAIN)
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            .build()
        preview.player = p
        player = p
    }

    private fun startPreview(item: Item) {
        previewItem = item
        triedAlt = false
        useHls = prefs.hls
        channelAdapter.playingId = item.id
        channelAdapter.refresh()
        play(item)
    }

    private fun play(item: Item) {
        val p = player ?: return
        val api = Repo.apiFor(item) ?: return
        if (api.isEnigma) useHls = false
        val mi = MediaItem.Builder()
            .setUri(api.streamUrl(item, useHls))
            .setMimeType(if (useHls) MimeTypes.APPLICATION_M3U8 else MimeTypes.VIDEO_MP2T)
            .build()
        p.setMediaItem(mi)
        p.prepare()
        p.playWhenReady = true
    }

    // ---------- Acties ----------

    /** Voorbeeld stoppen zodat er nooit twee verbindingen tegelijk naar de provider lopen. */
    private fun stopPreview() {
        previewTask?.let { handler.removeCallbacks(it) }
        player?.let {
            it.stop()
            it.release()
        }
        player = null
        preview.player = null
    }

    private fun playFullscreen(pos: Int, item: Item) {
        stopPreview()
        prefs.lastChannel = item.id; prefs.lastChannelSrc = item.src
        previewItem = item
        PlayQueue.set(channelAdapter.items, item)
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun toggleFav(item: Item) {
        val added = prefs.toggleFav(item.favKey)
        Toast.makeText(this, if (added) "Toegevoegd aan Favorieten" else "Verwijderd uit Favorieten", Toast.LENGTH_SHORT).show()
        val groups = liveGroups(prefs)
        val gi = groups.indexOfFirst { it.first.id == groupId }
        groupAdapter.submit(groups, gi)
        if (groupId.startsWith("FAV")) {
            if (gi >= 0) selectGroup(gi, groups[gi].first, false)
            else {
                val first = groups.indexOfFirst { !isGroupHeader(it.first.id) }.coerceAtLeast(0)
                selectGroup(first, groups[first].first, true)
            }
        }
    }
}
