package nl.michel.iptv

import android.app.Activity
import android.content.Context
import java.io.File

/** Bewaart de foutmelding als de app crasht en toont die bij de volgende start (handig om op te sturen). */
object CrashLog {
    @Volatile private var installed = false

    private fun file(ctx: Context) = File(ctx.applicationContext.filesDir, "laatste_crash.txt")

    fun install(ctx: Context) {
        if (installed) return
        installed = true
        val app = ctx.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                val sw = java.io.StringWriter()
                e.printStackTrace(java.io.PrintWriter(sw))
                file(app).writeText("MijnTV ${BuildConfig.VERSION_NAME}\n" + sw.toString().lines().take(40).joinToString("\n"))
            }
            previous?.uncaughtException(t, e)
        }
    }

    fun showIfAny(act: Activity) {
        val f = file(act)
        if (!f.exists()) return
        val text = runCatching { f.readText() }.getOrDefault("")
        f.delete()
        if (text.isBlank()) return
        androidx.appcompat.app.AlertDialog.Builder(act)
            .setTitle("MijnTV is de vorige keer vastgelopen")
            .setMessage("Maak een foto van deze melding en stuur hem op, dan kan het opgelost worden.\n\n" + text.take(1500))
            .setPositiveButton("OK", null)
            .show()
    }
}
