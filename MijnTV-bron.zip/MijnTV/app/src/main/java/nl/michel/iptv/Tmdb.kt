package nl.michel.iptv

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/** Nederlandse metadata van TMDB. */
data class Meta(
    val tmdbId: String,
    val title: String,
    val overview: String,
    val backdrop: String,
    val poster: String,
    val year: String,
    val rating: String,
    val genres: String,
    val runtime: String
)

data class Person(val id: String, val name: String, val role: String, val photo: String)

data class Credits(val cast: List<Person>, val director: String, val recs: List<Item>)

data class PersonInfo(
    val name: String,
    val bio: String,
    val photo: String,
    val born: String,
    val movies: List<Item>,
    val shows: List<Item>
)

data class EpMeta(val number: String, val name: String, val overview: String, val still: String, val runtime: String)

object Tmdb {
    private const val IMG = "https://image.tmdb.org/t/p/"
    private val mem = HashMap<String, Meta?>()
    private val seasons = HashMap<String, List<EpMeta>>()
    private val waiting = HashMap<String, MutableList<(Meta?) -> Unit>>()
    private var store: SharedPreferences? = null
    var key = ""

    val enabled: Boolean get() = key.isNotBlank()

    fun init(ctx: Context) {
        if (store == null) store = ctx.applicationContext.getSharedPreferences("tmdbcache", Context.MODE_PRIVATE)
        key = Prefs(ctx).tmdbKey
    }

    fun reset() {
        mem.clear(); seasons.clear()
        store?.edit()?.clear()?.apply()
    }

    private val creditCache = HashMap<String, Credits>()
    private val personCache = HashMap<String, PersonInfo>()

    private fun cacheKey(item: Item) =
        if (item.id.isEmpty()) "tmdb:" + item.type.name + ":" + item.tmdb else item.type.name + ":" + item.id

    /** Cast, regie en "meer zoals dit" voor een film of serie. */
    fun credits(type: Type, tmdbId: String, done: (Credits?) -> Unit) {
        if (!enabled || tmdbId.isEmpty()) {
            done(null); return
        }
        val k = type.name + tmdbId
        creditCache[k]?.let { done(it); return }
        Bg.go({
            val movie = type == Type.MOVIE
            val t = if (movie) "movie" else "tv"
            val d = get("/$t/$tmdbId", "language=nl-NL&append_to_response=" +
                if (movie) "credits,recommendations" else "aggregate_credits,recommendations")
            val credits = d.optJSONObject("credits") ?: d.optJSONObject("aggregate_credits")
            val cast = credits?.optJSONArray("cast")?.objects()?.take(25)?.map { o ->
                Person(
                    o.s("id"), o.s("name"),
                    o.s("character").ifEmpty { o.optJSONArray("roles")?.optJSONObject(0)?.s("character") ?: "" },
                    img("w342", o.s("profile_path"))
                )
            }.orEmpty()
            val director = if (movie) {
                credits?.optJSONArray("crew")?.objects()?.filter { it.s("job") == "Director" }
                    ?.joinToString(", ") { it.s("name") } ?: ""
            } else {
                d.optJSONArray("created_by")?.objects()?.joinToString(", ") { it.s("name") } ?: ""
            }
            val recs = d.optJSONObject("recommendations")?.optJSONArray("results")?.objects()
                ?.take(20)?.map { toItem(it, type) }.orEmpty()
            Credits(cast, director, recs)
        }) { r ->
            val c = r.getOrNull()
            if (c != null) creditCache[k] = c
            done(c)
        }
    }

    /** Acteurspagina: biografie en bekende films/series. */
    fun person(personId: String, done: (PersonInfo?) -> Unit) {
        if (!enabled) {
            done(null); return
        }
        personCache[personId]?.let { done(it); return }
        Bg.go({
            val d = get("/person/$personId", "language=nl-NL&append_to_response=combined_credits")
            var bio = d.s("biography")
            if (bio.isEmpty()) bio = runCatching { get("/person/$personId", "language=en-US").s("biography") }.getOrDefault("")
            val all = d.optJSONObject("combined_credits")?.optJSONArray("cast")?.objects().orEmpty()
            val seen = HashSet<String>()
            val sorted = all.sortedByDescending { it.optDouble("popularity", 0.0) }
                .filter { seen.add(it.s("media_type") + it.s("id")) }
            val movies = sorted.filter { it.s("media_type") == "movie" }.take(40).map { toItem(it, Type.MOVIE) }
            val shows = sorted.filter { o ->
                if (o.s("media_type") != "tv") return@filter false
                val g = o.optJSONArray("genre_ids")
                val talk = g != null && (0 until g.length()).any { g.optInt(it) == 10767 || g.optInt(it) == 10763 }
                !talk
            }.take(30).map { toItem(it, Type.SERIES) }
            val parts = ArrayList<String>()
            val bday = d.s("birthday")
            if (bday.length == 10) parts.add("Geboren " + bday.substring(8, 10) + "-" + bday.substring(5, 7) + "-" + bday.substring(0, 4))
            val dday = d.s("deathday")
            if (dday.length == 10) parts.add("† " + dday.substring(8, 10) + "-" + dday.substring(5, 7) + "-" + dday.substring(0, 4))
            val place = d.s("place_of_birth")
            if (place.isNotEmpty()) parts.add(place)
            PersonInfo(d.s("name"), bio, img("w500", d.s("profile_path")), parts.joinToString("   •   "), movies, shows)
        }) { r ->
            val p = r.getOrNull()
            if (p != null) personCache[personId] = p
            done(p)
        }
    }

    /** TMDB-resultaat -> item uit je eigen bibliotheek als die er is, anders alleen info. */
    private fun toItem(o: JSONObject, type: Type): Item {
        val movie = type == Type.MOVIE
        val title = if (movie) o.s("title") else o.s("name")
        val orig = if (movie) o.s("original_title") else o.s("original_name")
        val year = (if (movie) o.s("release_date") else o.s("first_air_date")).take(4)
        val id = o.s("id")
        Repo.libraryMatch(type, id, listOf(title, orig), year)?.let { return it }
        val vote = o.optDouble("vote_average", 0.0)
        return Item(
            "", title, img("w342", o.s("poster_path")), "", type,
            plot = o.s("overview"),
            rating = if (vote > 0) String.format(Locale.US, "%.1f", vote) else "",
            year = year, backdrop = img("w1280", o.s("backdrop_path")), tmdb = id
        )
    }

    /** Direct uit het geheugen of de opslag, zonder netwerk. */
    fun cached(item: Item): Meta? {
        val k = cacheKey(item)
        if (mem.containsKey(k)) return mem[k]
        val json = store?.getString(k, null) ?: return null
        val m = runCatching { fromJson(JSONObject(json)) }.getOrNull()?.takeIf { it.tmdbId.isNotEmpty() }
        mem[k] = m
        return m
    }

    fun known(item: Item): Boolean {
        val k = cacheKey(item)
        return mem.containsKey(k) || store?.contains(k) == true
    }

    /** Metadata opzoeken; het antwoord komt altijd op de UI-thread. */
    fun lookup(item: Item, done: (Meta?) -> Unit) {
        if (!enabled || (item.type != Type.MOVIE && item.type != Type.SERIES)) {
            done(null); return
        }
        val k = cacheKey(item)
        if (mem.containsKey(k) || store?.contains(k) == true) {
            done(cached(item)); return
        }
        val list = waiting[k]
        if (list != null) {
            list.add(done); return
        }
        waiting[k] = mutableListOf(done)
        Bg.go({ fetch(item) }) { r ->
            val m = r.getOrNull()
            // Netwerkfout: niet onthouden, dan proberen we het later opnieuw
            if (r.isSuccess) {
                mem[k] = m
                store?.edit()?.putString(k, m?.let { toJson(it).toString() } ?: "{}")?.apply()
            }
            val cbs = waiting.remove(k).orEmpty()
            for (cb in cbs) cb(m)
        }
    }

    /** Nederlandse afleveringstitels en beschrijvingen van één seizoen. */
    fun season(tvId: String, season: String, done: (List<EpMeta>) -> Unit) {
        if (!enabled || tvId.isEmpty()) {
            done(emptyList()); return
        }
        val k = "$tvId:$season"
        seasons[k]?.let { done(it); return }
        Bg.go({
            val nl = get("/tv/$tvId/season/$season", "language=nl-NL")
            val arr = nl.optJSONArray("episodes")
            val en = if (arr != null && arr.objects().any { it.s("overview").isEmpty() }) {
                runCatching { get("/tv/$tvId/season/$season", "language=en-US") }.getOrNull()
            } else null
            val enMap = en?.optJSONArray("episodes")?.objects()?.associateBy { it.s("episode_number") }.orEmpty()
            arr?.objects()?.map { e ->
                val n = e.s("episode_number")
                val fallback = enMap[n]
                EpMeta(
                    n,
                    e.s("name").ifEmpty { fallback?.s("name") ?: "" },
                    e.s("overview").ifEmpty { fallback?.s("overview") ?: "" },
                    img("w500", e.s("still_path")),
                    fmtDuration(e.s("runtime"))
                )
            }.orEmpty()
        }) { r ->
            val list = r.getOrNull().orEmpty()
            if (r.isSuccess) seasons[k] = list
            done(list)
        }
    }

    // ---------- intern ----------

    private fun img(size: String, path: String) = if (path.isEmpty()) "" else IMG + size + path

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun get(path: String, params: String): JSONObject {
        val bearer = key.startsWith("eyJ")
        val url = "https://api.themoviedb.org/3$path?$params" + if (bearer) "" else "&api_key=" + enc(key)
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("Accept", "application/json")
        if (bearer) c.setRequestProperty("Authorization", "Bearer $key")
        try {
            val code = c.responseCode
            if (code == 401) throw IOException("TMDB-sleutel ongeldig")
            if (code == 404) return JSONObject()
            if (code !in 200..299) throw IOException("TMDB fout $code")
            return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } finally {
            c.disconnect()
        }
    }

    private fun fetch(item: Item): Meta? {
        val type = if (item.type == Type.MOVIE) "movie" else "tv"
        var id = item.tmdb.takeIf { it.isNotEmpty() && it != "0" } ?: ""
        if (id.isEmpty()) {
            val (query, year) = cleanTitle(item.name)
            val yearParam = if (type == "movie") "year" else "first_air_date_year"
            var res = get("/search/$type", "query=${enc(query)}&language=nl-NL" + if (year.isNotEmpty()) "&$yearParam=$year" else "")
            if ((res.optJSONArray("results")?.length() ?: 0) == 0 && year.isNotEmpty()) {
                res = get("/search/$type", "query=${enc(query)}&language=nl-NL")
            }
            id = res.optJSONArray("results")?.optJSONObject(0)?.s("id") ?: ""
        }
        if (id.isEmpty()) return null

        val d = get("/$type/$id", "language=nl-NL")
        if (d.length() == 0) return null
        var overview = d.s("overview")
        if (overview.isEmpty()) {
            overview = runCatching { get("/$type/$id", "language=en-US").s("overview") }.getOrDefault("")
        }
        val title = if (type == "movie") d.s("title") else d.s("name")
        val date = if (type == "movie") d.s("release_date") else d.s("first_air_date")
        val vote = d.optDouble("vote_average", 0.0)
        val genres = d.optJSONArray("genres")?.objects()?.map { it.s("name") }?.take(3)?.joinToString(", ") ?: ""
        val runtime = if (type == "movie") {
            val m = d.optInt("runtime", 0)
            if (m > 0) (if (m >= 60) "${m / 60}u ${m % 60}m" else "${m}m") else ""
        } else {
            val n = d.optInt("number_of_seasons", 0)
            if (n > 0) (if (n == 1) "1 seizoen" else "$n seizoenen") else ""
        }
        return Meta(
            id, title, overview,
            img("w1280", d.s("backdrop_path")), img("w500", d.s("poster_path")),
            date.take(4),
            if (vote > 0) String.format(Locale.US, "%.1f", vote) else "",
            genres, runtime
        )
    }

    /** "NL - De Matrix (1999) [4K]" -> ("De Matrix", "1999") */
    fun cleanTitle(name: String): Pair<String, String> {
        val year = Regex("\\b(19|20)\\d{2}\\b").findAll(name).lastOrNull()?.value ?: ""
        var s = name
        s = s.replace(Regex("^\\s*\\|[^|]{1,8}\\|\\s*"), "")
        s = s.replace(Regex("^\\s*[\\[(]?[A-Z]{2,4}[\\])]?\\s*[-:|]\\s*"), "")
        s = s.replace(Regex("\\[[^\\]]*\\]"), " ").replace(Regex("\\([^)]*\\)"), " ")
        if (year.isNotEmpty()) s = s.replace(year, " ")
        s = s.replace(
            Regex("(?i)\\b(4k|uhd|fhd|hd|sd|hevc|x264|x265|h264|h265|multi|nl|gesproken|subs?|ondertiteld|vlaams|dubbed|dub)\\b"),
            " "
        )
        s = s.replace(Regex("[._]"), " ").replace(Regex("\\s+"), " ").trim().trim('-', ':', '|', ' ')
        return Pair(s.ifEmpty { name }, year)
    }

    private fun toJson(m: Meta) = JSONObject()
        .put("id", m.tmdbId).put("t", m.title).put("o", m.overview).put("b", m.backdrop)
        .put("p", m.poster).put("y", m.year).put("r", m.rating).put("g", m.genres).put("rt", m.runtime)

    private fun fromJson(o: JSONObject) = Meta(
        o.s("id"), o.s("t"), o.s("o"), o.s("b"), o.s("p"), o.s("y"), o.s("r"), o.s("g"), o.s("rt")
    )
}

/** Regel met type, jaar, beoordeling, genres en duur op basis van TMDB. */
fun metaLine(item: Item, m: Meta): String {
    val parts = ArrayList<String>()
    parts.add(if (item.type == Type.MOVIE) "Film" else "Serie")
    if (m.year.isNotEmpty()) parts.add(m.year)
    if (m.rating.isNotEmpty()) parts.add("★ " + m.rating)
    if (m.genres.isNotEmpty()) parts.add(m.genres)
    if (m.runtime.isNotEmpty()) parts.add(m.runtime)
    return parts.joinToString("   •   ")
}
