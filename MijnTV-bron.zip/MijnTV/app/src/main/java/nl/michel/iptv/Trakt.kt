package nl.michel.iptv

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Trakt: je lijsten als rijen in MijnTV. Koppelen gaat met een code op trakt.tv/activate. */
object Trakt {
    private const val API = "https://api.trakt.tv"

    data class DeviceCode(val deviceCode: String, val userCode: String, val url: String, val interval: Int, val expiresIn: Int)

    fun configured(prefs: Prefs) = BuildConfig.HAS_TRAKT && prefs.traktId.isNotBlank()

    /** Client Secret is bij nieuwe Trakt-apps niet meer nodig; alleen meesturen als die is ingevuld. */
    private fun JSONObject.withSecret(prefs: Prefs): JSONObject {
        if (prefs.traktSecret.isNotBlank()) put("client_secret", prefs.traktSecret.trim())
        return this
    }
    fun linked(prefs: Prefs) = BuildConfig.HAS_TRAKT && prefs.traktToken.isNotBlank()

    private fun call(prefs: Prefs, method: String, path: String, body: JSONObject? = null, auth: Boolean = true): Pair<Int, String> {
        val c = URL(API + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 45000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("trakt-api-version", "2")
        c.setRequestProperty("trakt-api-key", prefs.traktId.trim())
        c.setRequestProperty("User-Agent", "MijnTV/1.6")
        if (auth && prefs.traktToken.isNotEmpty()) c.setRequestProperty("Authorization", "Bearer " + prefs.traktToken)
        if (body != null) {
            c.doOutput = true
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        }
        try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            return Pair(code, stream?.bufferedReader()?.use { it.readText() } ?: "")
        } finally {
            c.disconnect()
        }
    }

    // ---------- Koppelen ----------

    fun deviceCode(prefs: Prefs): DeviceCode {
        val (code, text) = call(prefs, "POST", "/oauth/device/code", JSONObject().put("client_id", prefs.traktId.trim()), auth = false)
        if (code !in 200..299) throw IOException("Trakt fout $code: controleer Client ID")
        val o = JSONObject(text)
        return DeviceCode(o.s("device_code"), o.s("user_code"), o.s("verification_url"), o.optInt("interval", 5), o.optInt("expires_in", 600))
    }

    /** true = gekoppeld, false = mislukt/verlopen, null = nog wachten. */
    fun pollToken(prefs: Prefs, device: DeviceCode): Boolean? {
        val body = JSONObject().put("code", device.deviceCode)
            .put("client_id", prefs.traktId.trim()).withSecret(prefs)
        val (code, text) = call(prefs, "POST", "/oauth/device/token", body, auth = false)
        return when (code) {
            200 -> {
                val o = JSONObject(text)
                prefs.traktToken = o.s("access_token")
                prefs.traktRefresh = o.s("refresh_token")
                true
            }
            400, 429 -> null
            else -> false
        }
    }

    private fun refresh(prefs: Prefs): Boolean {
        if (prefs.traktRefresh.isEmpty()) return false
        val body = JSONObject().put("refresh_token", prefs.traktRefresh)
            .put("client_id", prefs.traktId.trim()).withSecret(prefs)
            .put("redirect_uri", "urn:ietf:wg:oauth:2.0:oob").put("grant_type", "refresh_token")
        val (code, text) = call(prefs, "POST", "/oauth/token", body, auth = false)
        if (code != 200) return false
        val o = JSONObject(text)
        prefs.traktToken = o.s("access_token")
        prefs.traktRefresh = o.s("refresh_token")
        return true
    }

    private fun getArray(prefs: Prefs, path: String): JSONArray {
        var (code, text) = call(prefs, "GET", path)
        if (code == 401 && refresh(prefs)) {
            val r = call(prefs, "GET", path)
            code = r.first; text = r.second
        }
        if (code == 401) throw IOException("Trakt-koppeling verlopen, koppel opnieuw via Instellingen")
        if (code !in 200..299) throw IOException("Trakt fout $code")
        return if (text.trim().startsWith("[")) JSONArray(text) else JSONArray()
    }

    fun getArrayPublic(prefs: Prefs, path: String): JSONArray = getArray(prefs, path)

    fun getObject(prefs: Prefs, path: String): JSONObject? {
        var (code, text) = call(prefs, "GET", path)
        if (code == 401 && refresh(prefs)) {
            val r = call(prefs, "GET", path)
            code = r.first; text = r.second
        }
        if (code !in 200..299) return null
        return runCatching { JSONObject(text) }.getOrNull()
    }

    fun post(prefs: Prefs, path: String, body: JSONObject): Int {
        var (code, _) = call(prefs, "POST", path, body)
        if (code == 401 && refresh(prefs)) code = call(prefs, "POST", path, body).first
        return code
    }

    // ---------- Lijsten ----------

    private fun toItems(arr: JSONArray, max: Int = 80): List<Item> = arr.objects().mapNotNull { o ->
        val kind = o.s("type")
        val type = when (kind) {
            "movie" -> Type.MOVIE
            "show" -> Type.SERIES
            else -> return@mapNotNull null
        }
        val m = o.optJSONObject(kind) ?: return@mapNotNull null
        val tmdb = m.optJSONObject("ids")?.s("tmdb") ?: ""
        val title = m.s("title")
        val year = m.s("year")
        Repo.libraryMatch(type, tmdb, listOf(title), year)
            ?: if (tmdb.isEmpty()) null else Item("", title, "", "", type, year = year, tmdb = tmdb)
    }.take(max)

    /** Watchlist, je eigen lijsten en gelikete lijsten (bijv. van Bingecat). */
    fun rows(prefs: Prefs): List<Row> {
        val rows = ArrayList<Row>()
        runCatching {
            val wl = toItems(getArray(prefs, "/sync/watchlist?sort_by=added&sort_how=desc"))
            if (wl.isNotEmpty()) rows.add(Row("Trakt: Watchlist", wl))
        }
        val own = runCatching { getArray(prefs, "/users/me/lists") }.getOrNull()
        own?.objects()?.take(20)?.forEach { l ->
            val id = l.optJSONObject("ids")?.s("trakt") ?: return@forEach
            runCatching {
                val items = toItems(getArray(prefs, "/users/me/lists/$id/items"))
                if (items.isNotEmpty()) rows.add(Row(l.s("name"), items))
            }
        }
        val liked = runCatching { getArray(prefs, "/users/likes/lists?limit=30") }.getOrNull()
        liked?.objects()?.take(15)?.forEach { w ->
            val l = w.optJSONObject("list") ?: return@forEach
            val id = l.optJSONObject("ids")?.s("trakt") ?: return@forEach
            val user = l.optJSONObject("user")?.optJSONObject("ids")?.s("slug") ?: return@forEach
            runCatching {
                val items = toItems(getArray(prefs, "/users/$user/lists/$id/items"))
                if (items.isNotEmpty()) rows.add(Row(l.s("name"), items))
            }
        }
        return rows
    }

    /** Koppelscherm: toont de code en wacht tot je hem op trakt.tv/activate hebt ingevuld. */
    fun link(act: Activity, prefs: Prefs, done: () -> Unit) {
        if (!configured(prefs)) {
            Toast.makeText(act, "Vul eerst je Trakt Client ID in", Toast.LENGTH_LONG).show()
            return
        }
        Bg.go({ deviceCode(prefs) }) { r ->
            val dc = r.getOrElse { e ->
                Toast.makeText(act, e.message ?: "Trakt fout", Toast.LENGTH_LONG).show()
                return@go
            }
            val dialog = androidx.appcompat.app.AlertDialog.Builder(act)
                .setTitle("Trakt koppelen")
                .setMessage("Ga op je telefoon of pc naar\n\n${dc.url}\n\nen vul deze code in:\n\n${dc.userCode}\n\nDit venster sluit vanzelf als het gelukt is.")
                .setNegativeButton("Annuleren", null)
                .show()
            val handler = Handler(Looper.getMainLooper())
            val until = System.currentTimeMillis() + dc.expiresIn * 1000L
            val poll = object : Runnable {
                override fun run() {
                    if (act.isFinishing || dialog?.isShowing == false) return
                    if (System.currentTimeMillis() > until) {
                        dialog?.dismiss()
                        Toast.makeText(act, "Code verlopen, probeer opnieuw", Toast.LENGTH_LONG).show()
                        return
                    }
                    val self = this
                    Bg.go({ pollToken(prefs, dc) }) { res ->
                        when (res.getOrNull()) {
                            true -> {
                                dialog?.dismiss()
                                Toast.makeText(act, "Trakt gekoppeld", Toast.LENGTH_LONG).show()
                                done()
                            }
                            false -> {
                                dialog?.dismiss()
                                Toast.makeText(act, "Koppelen mislukt", Toast.LENGTH_LONG).show()
                            }
                            null -> handler.postDelayed(self, dc.interval * 1000L)
                        }
                    }
                }
            }
            handler.postDelayed(poll, dc.interval * 1000L)
        }
    }
}

/** Een film of serie openen in Nuvio (voor titels die je provider niet heeft). */
object Nuvio {
    fun open(act: Activity, item: Item) {
        val known = item.tmdb.takeIf { it.isNotEmpty() && it != "0" } ?: Tmdb.cached(item)?.tmdbId
        if (known != null) {
            launch(act, item.type, known); return
        }
        Tmdb.lookup(item) { m ->
            if (m == null) Toast.makeText(act, "Titel niet gevonden voor Nuvio", Toast.LENGTH_LONG).show()
            else launch(act, item.type, m.tmdbId)
        }
    }

    private fun launch(act: Activity, type: Type, tmdbId: String) {
        val kind = if (type == Type.MOVIE) "movie" else "tv"
        try {
            act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("nuvio://tmdb/$kind/$tmdbId")))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(act, "Nuvio is niet geïnstalleerd op dit apparaat", Toast.LENGTH_LONG).show()
        }
    }
}

/** Kijkgeschiedenis van Trakt: wat is gezien, wat is half gekeken. */
object TraktSync {
    data class Playback(val type: Type, val tmdb: String, val season: Int, val number: Int, val progress: Float, val title: String, val year: String)

    @Volatile var watchedMovies: Set<String> = emptySet()
    /** show-tmdb -> set van "seizoen:aflevering" */
    @Volatile var watchedEpisodes: Map<String, Set<String>> = emptyMap()
    @Volatile var playback: List<Playback> = emptyList()
    @Volatile var loaded = false

    fun reset() {
        watchedMovies = emptySet(); watchedEpisodes = emptyMap(); playback = emptyList(); loaded = false
    }

    fun load(prefs: Prefs) {
        val movies = HashSet<String>()
        runCatching {
            for (o in Trakt.getArrayPublic(prefs, "/sync/watched/movies").objects()) {
                o.optJSONObject("movie")?.optJSONObject("ids")?.s("tmdb")?.takeIf { it.isNotEmpty() }?.let { movies.add(it) }
            }
        }
        val eps = HashMap<String, MutableSet<String>>()
        runCatching {
            for (o in Trakt.getArrayPublic(prefs, "/sync/watched/shows").objects()) {
                val tmdb = o.optJSONObject("show")?.optJSONObject("ids")?.s("tmdb") ?: continue
                if (tmdb.isEmpty()) continue
                val set = eps.getOrPut(tmdb) { HashSet() }
                o.optJSONArray("seasons")?.objects()?.forEach { s ->
                    val sn = s.optInt("number")
                    s.optJSONArray("episodes")?.objects()?.forEach { e -> set.add("$sn:${e.optInt("number")}") }
                }
            }
        }
        val pb = ArrayList<Playback>()
        runCatching {
            for (o in Trakt.getArrayPublic(prefs, "/sync/playback").objects()) {
                val prog = o.optDouble("progress", 0.0).toFloat()
                when (o.s("type")) {
                    "movie" -> {
                        val m = o.optJSONObject("movie") ?: continue
                        val tmdb = m.optJSONObject("ids")?.s("tmdb") ?: continue
                        pb.add(Playback(Type.MOVIE, tmdb, 0, 0, prog, m.s("title"), m.s("year")))
                    }
                    "episode" -> {
                        val sh = o.optJSONObject("show") ?: continue
                        val ep = o.optJSONObject("episode") ?: continue
                        val tmdb = sh.optJSONObject("ids")?.s("tmdb") ?: continue
                        pb.add(Playback(Type.SERIES, tmdb, ep.optInt("season"), ep.optInt("number"), prog, sh.s("title"), sh.s("year")))
                    }
                }
            }
        }
        watchedMovies = movies
        watchedEpisodes = eps
        playback = pb
        loaded = true
    }

    /**
     * Gekeken afleveringen van één serie rechtstreeks bij Trakt opvragen (altijd actueel).
     * Zoekt via TMDB-id; lukt dat niet, dan via titel (+ jaar). Resultaat: "seizoen:aflevering".
     */
    fun showWatched(prefs: Prefs, tmdb: String, title: String, year: String): Set<String> {
        if (!Trakt.linked(prefs)) return emptySet()
        var traktId = ""
        if (tmdb.isNotEmpty()) {
            runCatching {
                Trakt.getArrayPublic(prefs, "/search/tmdb/$tmdb?type=show").objects().firstOrNull()
                    ?.optJSONObject("show")?.optJSONObject("ids")?.optInt("trakt", 0)?.takeIf { it > 0 }
                    ?.let { traktId = it.toString() }
            }
        }
        val fromId = if (traktId.isNotEmpty()) progress(prefs, traktId) else emptySet()
        if (fromId.isNotEmpty() || title.isBlank()) return remember(tmdb, fromId)
        // Geen resultaat (verkeerd TMDB-id?): zoeken op titel
        runCatching {
            val q = java.net.URLEncoder.encode(title, "UTF-8")
            val hits = Trakt.getArrayPublic(prefs, "/search/show?query=$q&limit=10").objects()
                .mapNotNull { it.optJSONObject("show") }
            val norm = title.lowercase().replace(Regex("[^a-z0-9]"), "")
            val same = hits.filter { it.s("title").lowercase().replace(Regex("[^a-z0-9]"), "") == norm }
            val pick = same.firstOrNull { year.isNotEmpty() && it.s("year") == year }
            val candidates = listOfNotNull(pick) + same.filter { it != pick }
            for (sh in candidates.take(3)) {
                val id = sh.optJSONObject("ids")?.optInt("trakt", 0) ?: 0
                if (id <= 0 || id.toString() == traktId) continue
                val set = progress(prefs, id.toString())
                if (set.isNotEmpty()) return remember(tmdb, set)
            }
        }
        return remember(tmdb, fromId)
    }

    private fun progress(prefs: Prefs, traktId: String): Set<String> {
        val o = runCatching { Trakt.getObject(prefs, "/shows/$traktId/progress/watched?hidden=false&specials=false") }.getOrNull()
            ?: return emptySet()
        val set = HashSet<String>()
        o.optJSONArray("seasons")?.objects()?.forEach { s ->
            val sn = s.optInt("number")
            s.optJSONArray("episodes")?.objects()?.forEach { e ->
                if (e.optBoolean("completed")) set.add("$sn:${e.optInt("number")}")
            }
        }
        return set
    }

    private fun remember(tmdb: String, set: Set<String>): Set<String> {
        if (tmdb.isNotEmpty() && set.isNotEmpty()) {
            watchedEpisodes = watchedEpisodes + (tmdb to ((watchedEpisodes[tmdb] ?: emptySet()) + set))
        }
        return set
    }

    fun tmdbOf(item: Item): String =
        item.tmdb.takeIf { it.isNotEmpty() && it != "0" } ?: Tmdb.cached(item)?.tmdbId ?: ""

    fun isMovieWatched(item: Item): Boolean = item.type == Type.MOVIE && tmdbOf(item).let { it.isNotEmpty() && watchedMovies.contains(it) }

    fun watchedIn(showTmdb: String, season: String): Set<String> {
        val all = watchedEpisodes[showTmdb] ?: return emptySet()
        val prefix = "${season.toIntOrNull() ?: season}:"
        return all.filter { it.startsWith(prefix) }.map { it.removePrefix(prefix) }.toSet()
    }

    /** Volgende ongeziene aflevering na de laatst geziene: (seizoen, aflevering). */
    fun nextEpisode(showTmdb: String): Pair<Int, Int>? {
        pbFor(showTmdb)?.let { return Pair(it.season, it.number) }
        val all = watchedEpisodes[showTmdb] ?: return null
        val last = all.mapNotNull { k -> k.split(":").let { p -> if (p.size == 2) Pair(p[0].toIntOrNull() ?: 0, p[1].toIntOrNull() ?: 0) else null } }
            .filter { it.first > 0 }.maxWithOrNull(compareBy({ it.first }, { it.second })) ?: return null
        return Pair(last.first, last.second + 1)
    }

    private fun pbFor(showTmdb: String) = playback.firstOrNull { it.type == Type.SERIES && it.tmdb == showTmdb }

    /** Half gekeken voortgang (0..100) voor een film of aflevering, of 0. */
    fun progressFor(item: Item, series: Item?): Float {
        if (item.type == Type.MOVIE) {
            val t = tmdbOf(item)
            return playback.firstOrNull { it.type == Type.MOVIE && it.tmdb == t }?.progress ?: 0f
        }
        if (item.type == Type.EPISODE && series != null) {
            val t = tmdbOf(series)
            val s = item.categoryId.toIntOrNull() ?: return 0f
            val n = item.num.toIntOrNull() ?: return 0f
            return playback.firstOrNull { it.type == Type.SERIES && it.tmdb == t && it.season == s && it.number == n }?.progress ?: 0f
        }
        return 0f
    }

    /** Afspelen doorgeven aan Trakt. Vanaf 80% markeert Trakt het als gezien. */
    fun scrobble(prefs: Prefs, item: Item, series: Item?, progress: Float) {
        if (!Trakt.linked(prefs)) return
        val body = JSONObject().put("progress", progress.coerceIn(0f, 100f).toDouble())
        when {
            item.type == Type.MOVIE -> {
                val t = tmdbOf(item).toLongOrNull() ?: return
                body.put("movie", JSONObject().put("ids", JSONObject().put("tmdb", t)))
            }
            item.type == Type.EPISODE && series != null -> {
                val t = tmdbOf(series).toLongOrNull() ?: return
                val s = item.categoryId.toIntOrNull() ?: return
                val n = item.num.toIntOrNull() ?: return
                body.put("show", JSONObject().put("ids", JSONObject().put("tmdb", t)))
                body.put("episode", JSONObject().put("season", s).put("number", n))
            }
            else -> return
        }
        Bg.go({ Trakt.post(prefs, "/scrobble/stop", body) }) { }
        // Lokaal meteen bijwerken
        if (progress >= 80f) {
            if (item.type == Type.MOVIE) watchedMovies = watchedMovies + tmdbOf(item)
            else if (series != null) {
                val t = tmdbOf(series)
                val k = "${item.categoryId.toIntOrNull() ?: 0}:${item.num.toIntOrNull() ?: 0}"
                watchedEpisodes = watchedEpisodes + (t to ((watchedEpisodes[t] ?: emptySet()) + k))
            }
        }
    }
}
