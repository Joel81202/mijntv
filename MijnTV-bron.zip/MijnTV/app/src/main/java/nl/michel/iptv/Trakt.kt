package nl.michel.iptv

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Trakt: je lijsten als rijen in MijnTV. Koppelen gaat met een code op trakt.tv/activate. */
object Trakt {
    private const val API = "https://api.trakt.tv"

    data class DeviceCode(val deviceCode: String, val userCode: String, val url: String, val interval: Int, val expiresIn: Int)

    fun configured(prefs: Prefs) = prefs.traktId.isNotBlank() && prefs.traktSecret.isNotBlank()
    fun linked(prefs: Prefs) = prefs.traktToken.isNotBlank()

    private fun call(prefs: Prefs, method: String, path: String, body: JSONObject? = null, auth: Boolean = true): Pair<Int, String> {
        val c = URL(API + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("trakt-api-version", "2")
        c.setRequestProperty("trakt-api-key", prefs.traktId.trim())
        c.setRequestProperty("User-Agent", "MijnTV/1.6")
        if (auth && prefs.traktToken.isNotEmpty()) c.setRequestProperty("Authorization", "Bearer " + prefs.traktToken)
        if (body != null) {
            c.doOutput = true
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        }
        try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            return Pair(code, stream?.bufferedReader()?.use { it.readText() } ?: "")
        } finally {
            c.disconnect()
        }
    }

    // ---------- Koppelen ----------

    fun deviceCode(prefs: Prefs): DeviceCode {
        val (code, text) = call(prefs, "POST", "/oauth/device/code", JSONObject().put("client_id", prefs.traktId.trim()), auth = false)
        if (code !in 200..299) throw IOException("Trakt fout $code: controleer Client ID")
        val o = JSONObject(text)
        return DeviceCode(o.s("device_code"), o.s("user_code"), o.s("verification_url"), o.optInt("interval", 5), o.optInt("expires_in", 600))
    }

    /** true = gekoppeld, false = mislukt/verlopen, null = nog wachten. */
    fun pollToken(prefs: Prefs, device: DeviceCode): Boolean? {
        val body = JSONObject().put("code", device.deviceCode)
            .put("client_id", prefs.traktId.trim()).put("client_secret", prefs.traktSecret.trim())
        val (code, text) = call(prefs, "POST", "/oauth/device/token", body, auth = false)
        return when (code) {
            200 -> {
                val o = JSONObject(text)
                prefs.traktToken = o.s("access_token")
                prefs.traktRefresh = o.s("refresh_token")
                true
            }
            400, 429 -> null
            else -> false
        }
    }

    private fun refresh(prefs: Prefs): Boolean {
        if (prefs.traktRefresh.isEmpty()) return false
        val body = JSONObject().put("refresh_token", prefs.traktRefresh)
            .put("client_id", prefs.traktId.trim()).put("client_secret", prefs.traktSecret.trim())
            .put("redirect_uri", "urn:ietf:wg:oauth:2.0:oob").put("grant_type", "refresh_token")
        val (code, text) = call(prefs, "POST", "/oauth/token", body, auth = false)
        if (code != 200) return false
        val o = JSONObject(text)
        prefs.traktToken = o.s("access_token")
        prefs.traktRefresh = o.s("refresh_token")
        return true
    }

    private fun getArray(prefs: Prefs, path: String): JSONArray {
        var (code, text) = call(prefs, "GET", path)
        if (code == 401 && refresh(prefs)) {
            val r = call(prefs, "GET", path)
            code = r.first; text = r.second
        }
        if (code == 401) throw IOException("Trakt-koppeling verlopen, koppel opnieuw via Instellingen")
        if (code !in 200..299) throw IOException("Trakt fout $code")
        return if (text.trim().startsWith("[")) JSONArray(text) else JSONArray()
    }

    // ---------- Lijsten ----------

    private fun toItems(arr: JSONArray, max: Int = 80): List<Item> = arr.objects().mapNotNull { o ->
        val kind = o.s("type")
        val type = when (kind) {
            "movie" -> Type.MOVIE
            "show" -> Type.SERIES
            else -> return@mapNotNull null
        }
        val m = o.optJSONObject(kind) ?: return@mapNotNull null
        val tmdb = m.optJSONObject("ids")?.s("tmdb") ?: ""
        val title = m.s("title")
        val year = m.s("year")
        Repo.libraryMatch(type, tmdb, listOf(title), year)
            ?: if (tmdb.isEmpty()) null else Item("", title, "", "", type, year = year, tmdb = tmdb)
    }.take(max)

    /** Watchlist, je eigen lijsten en gelikete lijsten (bijv. van Bingecat). */
    fun rows(prefs: Prefs): List<Row> {
        val rows = ArrayList<Row>()
        runCatching {
            val wl = toItems(getArray(prefs, "/sync/watchlist?sort_by=added&sort_how=desc"))
            if (wl.isNotEmpty()) rows.add(Row("Trakt: Watchlist", wl))
        }
        val own = runCatching { getArray(prefs, "/users/me/lists") }.getOrNull()
        own?.objects()?.take(20)?.forEach { l ->
            val id = l.optJSONObject("ids")?.s("trakt") ?: return@forEach
            runCatching {
                val items = toItems(getArray(prefs, "/users/me/lists/$id/items"))
                if (items.isNotEmpty()) rows.add(Row(l.s("name"), items))
            }
        }
        val liked = runCatching { getArray(prefs, "/users/likes/lists?limit=30") }.getOrNull()
        liked?.objects()?.take(15)?.forEach { w ->
            val l = w.optJSONObject("list") ?: return@forEach
            val id = l.optJSONObject("ids")?.s("trakt") ?: return@forEach
            val user = l.optJSONObject("user")?.optJSONObject("ids")?.s("slug") ?: return@forEach
            runCatching {
                val items = toItems(getArray(prefs, "/users/$user/lists/$id/items"))
                if (items.isNotEmpty()) rows.add(Row(l.s("name"), items))
            }
        }
        return rows
    }

    /** Koppelscherm: toont de code en wacht tot je hem op trakt.tv/activate hebt ingevuld. */
    fun link(act: Activity, prefs: Prefs, done: () -> Unit) {
        if (!configured(prefs)) {
            Toast.makeText(act, "Vul eerst Trakt Client ID en Client Secret in", Toast.LENGTH_LONG).show()
            return
        }
        Bg.go({ deviceCode(prefs) }) { r ->
            val dc = r.getOrElse { e ->
                Toast.makeText(act, e.message ?: "Trakt fout", Toast.LENGTH_LONG).show()
                return@go
            }
            val dialog = androidx.appcompat.app.AlertDialog.Builder(act)
                .setTitle("Trakt koppelen")
                .setMessage("Ga op je telefoon of pc naar\n\n${dc.url}\n\nen vul deze code in:\n\n${dc.userCode}\n\nDit venster sluit vanzelf als het gelukt is.")
                .setNegativeButton("Annuleren", null)
                .show()
            val handler = Handler(Looper.getMainLooper())
            val until = System.currentTimeMillis() + dc.expiresIn * 1000L
            val poll = object : Runnable {
                override fun run() {
                    if (act.isFinishing || dialog?.isShowing == false) return
                    if (System.currentTimeMillis() > until) {
                        dialog?.dismiss()
                        Toast.makeText(act, "Code verlopen, probeer opnieuw", Toast.LENGTH_LONG).show()
                        return
                    }
                    val self = this
                    Bg.go({ pollToken(prefs, dc) }) { res ->
                        when (res.getOrNull()) {
                            true -> {
                                dialog?.dismiss()
                                Toast.makeText(act, "Trakt gekoppeld", Toast.LENGTH_LONG).show()
                                done()
                            }
                            false -> {
                                dialog?.dismiss()
                                Toast.makeText(act, "Koppelen mislukt", Toast.LENGTH_LONG).show()
                            }
                            null -> handler.postDelayed(self, dc.interval * 1000L)
                        }
                    }
                }
            }
            handler.postDelayed(poll, dc.interval * 1000L)
        }
    }
}

/** Een film of serie openen in Nuvio (voor titels die je provider niet heeft). */
object Nuvio {
    fun open(act: Activity, item: Item) {
        val known = item.tmdb.takeIf { it.isNotEmpty() && it != "0" } ?: Tmdb.cached(item)?.tmdbId
        if (known != null) {
            launch(act, item.type, known); return
        }
        Tmdb.lookup(item) { m ->
            if (m == null) Toast.makeText(act, "Titel niet gevonden voor Nuvio", Toast.LENGTH_LONG).show()
            else launch(act, item.type, m.tmdbId)
        }
    }

    private fun launch(act: Activity, type: Type, tmdbId: String) {
        val kind = if (type == Type.MOVIE) "movie" else "tv"
        try {
            act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("nuvio://tmdb/$kind/$tmdbId")))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(act, "Nuvio is niet geïnstalleerd op dit apparaat", Toast.LENGTH_LONG).show()
        }
    }
}
