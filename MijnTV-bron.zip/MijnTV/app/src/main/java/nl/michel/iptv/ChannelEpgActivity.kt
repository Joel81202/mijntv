package nl.michel.iptv

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Volledige tv-gids van één zender: de afgelopen week per dag, met terugkijken (zoals TiviMate). */
class ChannelEpgActivity : AppCompatActivity() {

    companion object {
        var channel: Item? = null
        var channels: List<Item> = emptyList()
    }

    private lateinit var ch: Item
    private lateinit var days: RecyclerView
    private lateinit var programs: RecyclerView
    private val dayAdapter = DayAdapter()
    private val programAdapter = EpgProgramAdapter()
    private var dayStarts: List<Long> = emptyList()
    private var all: List<Program> = emptyList()
    private var selectedDay = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ch = channel ?: run { finish(); return }
        setContentView(R.layout.activity_channel_epg)
        val logo = findViewById<ImageView>(R.id.epgLogo)
        if (ch.icon.isNotEmpty()) Glide.with(logo).load(ch.icon).into(logo)
        findViewById<TextView>(R.id.epgChannel).text = ch.name
        findViewById<TextView>(R.id.epgArchive).text =
            if (ch.archive > 0) "⏪ ${ch.archive} dagen terugkijken" else "Geen terugkijken bij deze zender"

        days = findViewById(R.id.epgDays)
        programs = findViewById(R.id.epgPrograms)
        days.layoutManager = LinearLayoutManager(this)
        days.itemAnimator = null
        days.adapter = dayAdapter
        programs.layoutManager = LinearLayoutManager(this)
        programs.itemAnimator = null
        programs.adapter = programAdapter

        build(Epg.programs(ch), focusNow = true)
        // Volledige gids ophalen bij de provider: archief én de komende dagen
        val api = Repo.apiFor(ch) ?: return
        Bg.go({
            val got = ArrayList<Program>()
            runCatching { api.fullEpg(ch.id) }.getOrNull().orEmpty()
                .filter { it.end > 0 }.forEach { got.add(Program(it.start * 1000, it.end * 1000, it.title, it.desc)) }
            runCatching { api.shortEpg(ch.id, 500) }.getOrNull().orEmpty()
                .filter { it.end > 0 }.forEach { got.add(Program(it.start * 1000, it.end * 1000, it.title, it.desc)) }
            got
        }) { r ->
            if (isFinishing) return@go
            val extra = r.getOrNull().orEmpty()
            if (extra.isNotEmpty()) {
                val merged = (all + extra).associateBy { it.start }.values.sortedBy { it.start }
                build(merged, focusNow = !programs.hasFocus() && !days.hasFocus())
            }
            // Nog steeds niet ver vooruit? Dan de XMLTV-gids voor deze ene zender doorzoeken
            if (all.none { it.start > System.currentTimeMillis() + 30 * 3600_000L }) {
                Bg.go({ Epg.weekFromXmltv(ch) }) { r2 ->
                    val week = r2.getOrNull().orEmpty()
                    if (isFinishing || week.isEmpty()) return@go
                    val merged = (all + week).associateBy { it.start }.values.sortedBy { it.start }
                    build(merged, focusNow = !programs.hasFocus() && !days.hasFocus())
                }
            }
        }
    }

    private fun dayStart(ms: Long): Long = Calendar.getInstance().apply {
        timeInMillis = ms
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun build(list: List<Program>, focusNow: Boolean) {
        val now = System.currentTimeMillis()
        val oldest = dayStart(now) - 7 * 86_400_000L
        all = list.filter { it.end > oldest }
        dayStarts = all.map { dayStart(it.start) }.distinct().sorted()
        if (dayStarts.isEmpty()) {
            findViewById<TextView>(R.id.epgTitle).text = "Geen gids beschikbaar voor deze zender"
            return
        }
        dayAdapter.notifyDataSetChanged()
        val today = dayStarts.indexOf(dayStart(now)).takeIf { it >= 0 } ?: (dayStarts.size - 1)
        val keep = if (selectedDay in dayStarts.indices && !focusNow) selectedDay else today
        selectDay(keep, focusPrograms = focusNow)
    }

    private fun selectDay(i: Int, focusPrograms: Boolean) {
        if (i !in dayStarts.indices) return
        val old = selectedDay
        val changed = i != old
        selectedDay = i
        if (old in dayStarts.indices) dayAdapter.notifyItemChanged(old)
        dayAdapter.notifyItemChanged(i)
        val start = dayStarts[i]
        val dayList = all.filter { it.start >= start && it.start < start + 86_400_000L }
        if (!changed && programAdapter.items == dayList && !focusPrograms) return
        programAdapter.items = dayList
        programAdapter.notifyDataSetChanged()
        val now = System.currentTimeMillis()
        // Vandaag: bij het programma van nu. Andere dagen: bij het begin van de dag.
        val isToday = start == dayStart(now)
        val target = if (isToday) dayList.indexOfFirst { it.end > now }.let { if (it < 0) dayList.size - 1 else it }.coerceAtLeast(0) else 0
        (programs.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(target, if (isToday) dp(this, 80f) else 0)
        dayList.getOrNull(target)?.let { showDetails(it) }
        if (focusPrograms) programs.post { programs.findViewHolderForAdapterPosition(target)?.itemView?.requestFocus() }
    }

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.action == android.view.KeyEvent.ACTION_DOWN && event.keyCode == android.view.KeyEvent.KEYCODE_DPAD_LEFT &&
            programs.hasFocus()
        ) {
            // Terug naar de gekozen dag (niet naar een willekeurige)
            days.scrollToPosition(selectedDay)
            days.post { days.findViewHolderForAdapterPosition(selectedDay)?.itemView?.requestFocus() }
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun showDetails(p: Program) {
        findViewById<TextView>(R.id.epgTitle).text = p.title
        val now = System.currentTimeMillis()
        val state = when {
            p.start <= now && p.end > now -> "   ·   NU OP TV"
            p.end <= now && Epg.canCatchup(ch, p, now) -> "   ·   ⏪ terugkijken"
            p.start > now -> ""
            else -> "   ·   niet terug te kijken"
        }
        findViewById<TextView>(R.id.epgTime).text =
            "${Epg.day(p.start)}  ${Epg.time(p.start)} – ${Epg.time(p.end)}$state"
        findViewById<TextView>(R.id.epgDesc).text = p.desc
    }

    private fun play(p: Program) {
        val now = System.currentTimeMillis()
        when {
            p.start <= now && p.end > now -> {
                prefs().lastChannel = ch.id; prefs().lastChannelSrc = ch.src
                PlayQueue.set(channels.ifEmpty { listOf(ch) }, ch)
                startActivity(Intent(this, PlayerActivity::class.java))
                finish()
            }
            p.end <= now && Epg.canCatchup(ch, p, now) -> {
                val item = Epg.catchupItem(ch, p)
                PlayQueue.set(listOf(item), item)
                startActivity(Intent(this, PlayerActivity::class.java))
            }
            p.start > now -> Toast.makeText(this, "Begint ${Epg.day(p.start).lowercase()} om ${Epg.time(p.start)}", Toast.LENGTH_SHORT).show()
            else -> Toast.makeText(this, "Deze uitzending is niet terug te kijken", Toast.LENGTH_SHORT).show()
        }
    }

    private var prefsCache: Prefs? = null
    private fun prefs(): Prefs = prefsCache ?: Prefs(this).also { prefsCache = it }

    private val dayFormat = SimpleDateFormat("EEE d MMM", Locale("nl", "NL"))

    private fun dayLabel(start: Long): String {
        val d = Epg.day(start)
        val date = dayFormat.format(start)
        return if (d == "Vandaag" || d == "Gisteren" || d == "Morgen") "$d  ·  $date" else date.replaceFirstChar { it.uppercase() }
    }

    // ---------- Lijsten ----------

    inner class DayAdapter : RecyclerView.Adapter<DayAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val time: TextView = v.findViewById(R.id.prTime)
            val title: TextView = v.findViewById(R.id.prTitle)
            val badge: TextView = v.findViewById(R.id.prBadge)
        }

        override fun getItemCount() = dayStarts.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_program, parent, false))

        override fun onBindViewHolder(h: VH, position: Int) {
            h.time.visibility = View.GONE
            h.title.text = dayLabel(dayStarts[position])
            h.badge.text = if (position == selectedDay) "▶" else ""
            h.itemView.isSelected = position == selectedDay
            h.itemView.setOnFocusChangeListener { _, has ->
                val i = h.bindingAdapterPosition
                if (has && i != RecyclerView.NO_POSITION && i != selectedDay) selectDay(i, focusPrograms = false)
            }
            h.itemView.setOnClickListener {
                val i = h.bindingAdapterPosition
                if (i != RecyclerView.NO_POSITION) selectDay(i, focusPrograms = true)
            }
        }
    }

    inner class EpgProgramAdapter : RecyclerView.Adapter<EpgProgramAdapter.VH>() {
        var items: List<Program> = emptyList()

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val time: TextView = v.findViewById(R.id.prTime)
            val title: TextView = v.findViewById(R.id.prTitle)
            val badge: TextView = v.findViewById(R.id.prBadge)
        }

        override fun getItemCount() = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_program, parent, false))

        override fun onBindViewHolder(h: VH, position: Int) {
            val p = items[position]
            val now = System.currentTimeMillis()
            h.time.text = "${Epg.time(p.start)} – ${Epg.time(p.end)}"
            h.time.layoutParams = h.time.layoutParams.apply { width = dp(h.itemView.context, 120f) }
            h.title.text = p.title
            val catchup = p.end <= now && Epg.canCatchup(ch, p, now)
            h.badge.text = when {
                p.start <= now && p.end > now -> "NU"
                catchup -> "⏪"
                else -> ""
            }
            h.itemView.alpha = if (p.end <= now && !catchup) 0.5f else 1f
            h.itemView.setOnFocusChangeListener { _, has ->
                val i = h.bindingAdapterPosition
                if (has && i != RecyclerView.NO_POSITION) showDetails(items[i])
            }
            h.itemView.setOnClickListener {
                val i = h.bindingAdapterPosition
                if (i != RecyclerView.NO_POSITION) play(items[i])
            }
        }
    }
}
