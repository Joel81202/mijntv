package nl.michel.iptv

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.Base64
import android.widget.EditText
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Back-up en synchronisatie via Google Drive.
 *
 * Alle instellingen, providers, profielen en kijkvoortgang staan versleuteld (met jouw pincode)
 * in één bestand in je eigen Google Drive. Elk apparaat voegt zijn wijzigingen samen met die
 * van de andere apparaten: per instelling wint de laatst gewijzigde.
 */
object Cloud {
    private const val FILE_NAME = "MijnTV-sync.json"
    private const val SCOPE = "https://www.googleapis.com/auth/drive.file"

    private val clientId get() = BuildConfig.GOOGLE_CLIENT_ID
    private val clientSecret get() = BuildConfig.GOOGLE_CLIENT_SECRET

    fun configured() = clientId.isNotEmpty()

    private fun cfg(ctx: Context) = ctx.applicationContext.getSharedPreferences("mijntv_cloud", Context.MODE_PRIVATE)
    private fun stamps(ctx: Context) = ctx.applicationContext.getSharedPreferences("mijntv_cloudts", Context.MODE_PRIVATE)

    fun linked(ctx: Context) = configured() &&
        !cfg(ctx).getString("refresh", null).isNullOrEmpty() && !cfg(ctx).getString("pin", null).isNullOrEmpty()

    fun lastSync(ctx: Context): Long = cfg(ctx).getLong("last", 0L)

    // ---------- Welke gegevens gaan mee ----------

    private fun files(ctx: Context): List<String> =
        listOf("mijntv_global", "mijntv") + UserProfiles.users(ctx).filter { it.id.isNotEmpty() }.map { "mijntv_u_${it.id}" }

    private fun validFile(name: String) = name == "mijntv_global" || name == "mijntv" || name.startsWith("mijntv_u_")

    /** Apparaat-eigen zaken blijven lokaal. */
    private fun excluded(file: String, key: String): Boolean {
        if (file == "mijntv_global") return key == "active"
        return key == "trakttoken" || key == "traktrefresh" || key == "lastch" || key == "lastchsrc" || key.startsWith("sub:")
    }

    // ---------- Bijhouden wanneer iets veranderde ----------

    private val listeners = HashMap<String, SharedPreferences.OnSharedPreferenceChangeListener>()
    private val applying = java.util.Collections.synchronizedSet(HashSet<String>())

    /** Wijzigingen gaan bijhouden (veilig om vaker aan te roepen). */
    fun init(ctx: Context) {
        if (!configured()) return
        val app = ctx.applicationContext
        synchronized(listeners) {
            for (f in files(app)) {
                if (listeners.containsKey(f)) continue
                val l = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
                    if (key == null || excluded(f, key)) return@OnSharedPreferenceChangeListener
                    if (applying.remove("$f|$key")) return@OnSharedPreferenceChangeListener
                    stamps(app).edit().putLong("$f|$key", System.currentTimeMillis()).apply()
                }
                listeners[f] = l
                app.getSharedPreferences(f, Context.MODE_PRIVATE).registerOnSharedPreferenceChangeListener(l)
            }
        }
    }

    // ---------- Google-login (code invullen op google.com/device) ----------

    private class DeviceCode(val device: String, val user: String, val url: String, val interval: Int, val expires: Int)

    private fun form(url: String, params: Map<String, String>): Pair<Int, String> {
        val body = params.entries.joinToString("&") { it.key + "=" + URLEncoder.encode(it.value, "UTF-8") }
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000; c.readTimeout = 20000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        c.outputStream.use { it.write(body.toByteArray()) }
        try {
            val code = c.responseCode
            val s = if (code in 200..299) c.inputStream else c.errorStream
            return Pair(code, s?.bufferedReader()?.use { it.readText() } ?: "")
        } finally { c.disconnect() }
    }

    private fun deviceCode(): DeviceCode {
        val (code, text) = form("https://oauth2.googleapis.com/device/code", mapOf("client_id" to clientId, "scope" to SCOPE))
        if (code !in 200..299) throw IOException("Google fout $code: " + JSONObject(text.ifEmpty { "{}" }).optString("error_description", text.take(120)))
        val o = JSONObject(text)
        return DeviceCode(
            o.getString("device_code"), o.getString("user_code"),
            o.optString("verification_url", "https://www.google.com/device"),
            o.optInt("interval", 5), o.optInt("expires_in", 900)
        )
    }

    /** true = gelukt, false = mislukt, null = nog wachten. */
    private fun poll(ctx: Context, dc: DeviceCode): Boolean? {
        val (code, text) = form(
            "https://oauth2.googleapis.com/token", mapOf(
                "client_id" to clientId, "client_secret" to clientSecret,
                "device_code" to dc.device, "grant_type" to "urn:ietf:params:oauth:grant-type:device_code"
            )
        )
        val o = runCatching { JSONObject(text) }.getOrElse { JSONObject() }
        if (code in 200..299) {
            cfg(ctx).edit()
                .putString("refresh", o.optString("refresh_token"))
                .putString("access", o.optString("access_token"))
                .putLong("exp", System.currentTimeMillis() + o.optLong("expires_in", 3600) * 1000L - 60_000L)
                .apply()
            return true
        }
        return when (o.optString("error")) {
            "authorization_pending", "slow_down" -> null
            else -> false
        }
    }

    private fun token(ctx: Context): String {
        val c = cfg(ctx)
        val access = c.getString("access", "") ?: ""
        if (access.isNotEmpty() && System.currentTimeMillis() < c.getLong("exp", 0L)) return access
        val refresh = c.getString("refresh", "") ?: ""
        if (refresh.isEmpty()) throw IOException("Niet gekoppeld met Google Drive")
        val (code, text) = form(
            "https://oauth2.googleapis.com/token", mapOf(
                "client_id" to clientId, "client_secret" to clientSecret,
                "refresh_token" to refresh, "grant_type" to "refresh_token"
            )
        )
        if (code !in 200..299) {
            if (code == 400 || code == 401) c.edit().remove("refresh").remove("access").apply()
            throw IOException("Google-koppeling verlopen, koppel opnieuw via Instellingen")
        }
        val o = JSONObject(text)
        val t = o.getString("access_token")
        c.edit().putString("access", t)
            .putLong("exp", System.currentTimeMillis() + o.optLong("expires_in", 3600) * 1000L - 60_000L).apply()
        return t
    }

    // ---------- Google Drive ----------

    private fun drive(ctx: Context, method: String, url: String, body: ByteArray? = null, type: String? = null): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        if (method == "PATCH") {
            c.requestMethod = "POST"
            c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
        } else c.requestMethod = method
        c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("Authorization", "Bearer " + token(ctx))
        if (body != null) {
            c.doOutput = true
            if (type != null) c.setRequestProperty("Content-Type", type)
            c.outputStream.use { it.write(body) }
        }
        try {
            val code = c.responseCode
            val s = if (code in 200..299) c.inputStream else c.errorStream
            return Pair(code, s?.bufferedReader()?.use { it.readText() } ?: "")
        } finally { c.disconnect() }
    }

    private fun findFile(ctx: Context): String? {
        val q = URLEncoder.encode("name='$FILE_NAME' and trashed=false", "UTF-8")
        val (code, text) = drive(ctx, "GET", "https://www.googleapis.com/drive/v3/files?q=$q&spaces=drive&fields=files(id,modifiedTime)&orderBy=modifiedTime%20desc")
        if (code !in 200..299) throw IOException("Google Drive fout $code")
        return JSONObject(text).optJSONArray("files")?.optJSONObject(0)?.optString("id")?.takeIf { it.isNotEmpty() }
    }

    private fun download(ctx: Context, id: String): String {
        val (code, text) = drive(ctx, "GET", "https://www.googleapis.com/drive/v3/files/$id?alt=media")
        if (code !in 200..299) throw IOException("Downloaden mislukt ($code)")
        return text
    }

    private fun upload(ctx: Context, id: String?, content: String) {
        val bytes = content.toByteArray(Charsets.UTF_8)
        val code = if (id != null) {
            drive(ctx, "PATCH", "https://www.googleapis.com/upload/drive/v3/files/$id?uploadType=media", bytes, "application/json").first
        } else {
            val boundary = "mijntv" + System.currentTimeMillis()
            val meta = JSONObject().put("name", FILE_NAME).put("mimeType", "application/json").toString()
            val body = "--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n" +
                "--$boundary\r\nContent-Type: application/json\r\n\r\n$content\r\n--$boundary--"
            drive(ctx, "POST", "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
                body.toByteArray(Charsets.UTF_8), "multipart/related; boundary=$boundary").first
        }
        if (code !in 200..299) throw IOException("Uploaden mislukt ($code)")
    }

    // ---------- Versleuteling met pincode ----------

    private fun key(pin: String, salt: ByteArray): SecretKeySpec {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
        val k = f.generateSecret(PBEKeySpec(pin.toCharArray(), salt, 20000, 256)).encoded
        return SecretKeySpec(k, "AES")
    }

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)

    private fun encrypt(pin: String, plain: String): String {
        val rnd = SecureRandom()
        val salt = ByteArray(16).also { rnd.nextBytes(it) }
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(pin, salt), GCMParameterSpec(128, iv))
        val data = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return JSONObject().put("app", "MijnTV").put("v", 1).put("updated", System.currentTimeMillis())
            .put("salt", b64(salt)).put("iv", b64(iv)).put("data", b64(data)).toString()
    }

    class WrongPin : IOException("Verkeerde pincode")

    private fun decrypt(pin: String, text: String): JSONObject {
        val o = JSONObject(text)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(pin, unb64(o.getString("salt"))), GCMParameterSpec(128, unb64(o.getString("iv"))))
        val plain = runCatching { c.doFinal(unb64(o.getString("data"))) }.getOrElse { throw WrongPin() }
        return JSONObject(String(plain, Charsets.UTF_8))
    }

    // ---------- Samenvoegen ----------

    private fun entry(value: Any?, t: Long): JSONObject {
        val e = JSONObject().put("t", t)
        when (value) {
            null -> e.put("del", true)
            is String -> e.put("type", "s").put("v", value)
            is Int -> e.put("type", "i").put("v", value)
            is Long -> e.put("type", "l").put("v", value)
            is Boolean -> e.put("type", "b").put("v", value)
            is Float -> e.put("type", "f").put("v", value.toDouble())
            is Set<*> -> e.put("type", "set").put("v", JSONArray(value.map { it.toString() }))
            else -> e.put("type", "s").put("v", value.toString())
        }
        return e
    }

    private fun valueOf(e: JSONObject): Any? {
        if (e.optBoolean("del")) return null
        return when (e.optString("type")) {
            "i" -> e.optInt("v")
            "l" -> e.optLong("v")
            "b" -> e.optBoolean("v")
            "f" -> e.optDouble("v").toFloat()
            "set" -> e.optJSONArray("v")?.let { a -> (0 until a.length()).map { a.optString(it) }.toSet() } ?: emptySet<String>()
            else -> e.optString("v")
        }
    }

    private fun sameValue(a: Any?, b: Any?): Boolean = when {
        a is Float && b is Float -> Math.abs(a - b) < 1e-6
        a is Set<*> && b is Set<*> -> a.map { it.toString() }.toSet() == b.map { it.toString() }.toSet()
        else -> a == b
    }

    /** Huidige lokale stand van één bestand, met tijdstempels. */
    private fun local(ctx: Context, file: String): Map<String, JSONObject> {
        val all = ctx.applicationContext.getSharedPreferences(file, Context.MODE_PRIVATE).all
        val st = stamps(ctx).all
        val out = HashMap<String, JSONObject>()
        for ((k, v) in all) if (!excluded(file, k)) out[k] = entry(v, (st["$file|$k"] as? Long) ?: 1L)
        // Verwijderde sleutels (met tijdstempel) als "verwijderd" doorgeven
        val prefix = "$file|"
        for ((sk, t) in st) {
            if (!sk.startsWith(prefix)) continue
            val k = sk.removePrefix(prefix)
            if (!all.containsKey(k) && !excluded(file, k)) out[k] = entry(null, (t as? Long) ?: 1L)
        }
        return out
    }

    private fun stampAll(ctx: Context) {
        val now = System.currentTimeMillis()
        val e = stamps(ctx).edit()
        for (f in files(ctx)) {
            for (k in ctx.applicationContext.getSharedPreferences(f, Context.MODE_PRIVATE).all.keys) {
                if (!excluded(f, k)) e.putLong("$f|$k", now)
            }
        }
        e.commit()
    }

    private fun applyEntries(ctx: Context, file: String, changes: Map<String, JSONObject>): Boolean {
        if (changes.isEmpty()) return false
        var wrote = false
        val sp = ctx.applicationContext.getSharedPreferences(file, Context.MODE_PRIVATE)
        val cur = sp.all
        val ed = sp.edit()
        val st = stamps(ctx).edit()
        for ((k, e) in changes) {
            val v = valueOf(e)
            val exists = cur.containsKey(k)
            if (v == null) {
                if (exists) { applying.add("$file|$k"); ed.remove(k); wrote = true }
            } else if (!exists || !sameValue(cur[k], v)) {
                applying.add("$file|$k")
                wrote = true
                when (v) {
                    is String -> ed.putString(k, v)
                    is Int -> ed.putInt(k, v)
                    is Long -> ed.putLong(k, v)
                    is Boolean -> ed.putBoolean(k, v)
                    is Float -> ed.putFloat(k, v)
                    is Set<*> -> ed.putStringSet(k, v.map { it.toString() }.toSet())
                }
            }
            st.putLong("$file|$k", e.optLong("t"))
        }
        ed.commit()
        st.commit()
        return wrote
    }

    enum class Mode { MERGE, RESTORE, PUSH }

    private val busy = java.util.concurrent.atomic.AtomicBoolean(false)

    /** Samenvoegen met de cloud. Geeft true als er op dit apparaat iets veranderd is. */
    fun sync(ctx: Context, mode: Mode = Mode.MERGE, pinOverride: String? = null): Boolean {
        val pin = pinOverride ?: cfg(ctx).getString("pin", "") ?: ""
        if (pin.isEmpty()) throw IOException("Geen pincode ingesteld")
        if (!busy.compareAndSet(false, true)) return false
        try {
            init(ctx)
            val id = findFile(ctx)
            val remote = if (id != null) decrypt(pin, download(ctx, id)).optJSONObject("files") ?: JSONObject() else JSONObject()
            if (mode == Mode.RESTORE && id == null) throw IOException("Geen back-up gevonden in Google Drive")
            if (mode == Mode.PUSH) stampAll(ctx)

            var changed = false
            var needUpload = id == null
            val merged = JSONObject()
            val names = LinkedHashSet<String>()
            names.addAll(files(ctx))
            remote.keys().forEach { if (validFile(it)) names.add(it) }
            // Globale gegevens eerst: daarin staan de profielen
            for (file in names.sortedBy { if (it == "mijntv_global") 0 else 1 }) {
                val loc = local(ctx, file)
                val rem = remote.optJSONObject(file)
                val out = JSONObject()
                val toApply = HashMap<String, JSONObject>()
                val keys = HashSet(loc.keys)
                rem?.keys()?.forEach { keys.add(it) }
                for (k in keys) {
                    if (excluded(file, k)) continue
                    val l = loc[k]
                    val r = rem?.optJSONObject(k)
                    val remoteWins = r != null && (l == null || mode == Mode.RESTORE || r.optLong("t") > l.optLong("t"))
                    if (remoteWins) {
                        out.put(k, r)
                        if (l == null || !sameValue(valueOf(l), valueOf(r!!)) || l.optBoolean("del") != r.optBoolean("del")) {
                            toApply[k] = r!!
                        }
                    } else if (l != null) {
                        out.put(k, l)
                        if (r == null || l.optLong("t") != r.optLong("t")) needUpload = true
                    }
                }
                if (applyEntries(ctx, file, toApply)) changed = true
                merged.put(file, out)
            }
            if (needUpload) upload(ctx, id, encrypt(pin, JSONObject().put("files", merged).toString()))
            cfg(ctx).edit().putLong("last", System.currentTimeMillis()).apply()
            init(ctx) // eventuele nieuwe profielen ook volgen
            return changed
        } finally {
            busy.set(false)
        }
    }

    private var lastAuto = 0L

    /** Op de achtergrond synchroniseren; done(true) als er iets veranderd is. */
    fun syncAsync(ctx: Context, force: Boolean = false, done: (Boolean) -> Unit = {}) {
        if (!linked(ctx)) return
        val now = System.currentTimeMillis()
        if (!force && now - lastAuto < 60_000L) return
        lastAuto = now
        val app = ctx.applicationContext
        Bg.go({ sync(app) }) { r -> done(r.getOrDefault(false)) }
    }

    fun unlink(ctx: Context) {
        cfg(ctx).edit().clear().apply()
    }

    // ---------- Schermen ----------

    /** Koppelen: code tonen, pincode kiezen, en kiezen wat er moet gebeuren. */
    fun link(act: Activity, restoreOnly: Boolean, done: (restored: Boolean) -> Unit) {
        if (!configured()) {
            Toast.makeText(act, "Cloud-back-up is in deze versie niet ingesteld", Toast.LENGTH_LONG).show()
            return
        }
        Bg.go({ deviceCode() }) { r ->
            val dc = r.getOrElse { e ->
                Toast.makeText(act, e.message ?: "Google fout", Toast.LENGTH_LONG).show()
                return@go
            }
            val dialog = androidx.appcompat.app.AlertDialog.Builder(act)
                .setTitle("Koppelen met Google Drive")
                .setMessage("Ga op je telefoon of pc naar\n\n${dc.url}\n\nen vul deze code in:\n\n${dc.user}\n\nLog in met je Google-account. Dit venster sluit vanzelf als het gelukt is.")
                .setNegativeButton("Annuleren", null)
                .show()
            val handler = Handler(Looper.getMainLooper())
            val until = System.currentTimeMillis() + dc.expires * 1000L
            val loop = object : Runnable {
                override fun run() {
                    if (act.isFinishing || dialog?.isShowing == false) return
                    if (System.currentTimeMillis() > until) {
                        dialog?.dismiss()
                        Toast.makeText(act, "Code verlopen, probeer opnieuw", Toast.LENGTH_LONG).show()
                        return
                    }
                    val self = this
                    Bg.go({ poll(act, dc) }) { res ->
                        when (res.getOrNull()) {
                            true -> { dialog?.dismiss(); askPin(act, restoreOnly, done) }
                            false -> { dialog?.dismiss(); Toast.makeText(act, "Koppelen mislukt", Toast.LENGTH_LONG).show() }
                            null -> handler.postDelayed(self, dc.interval * 1000L)
                        }
                    }
                }
            }
            handler.postDelayed(loop, dc.interval * 1000L)
        }
    }

    private fun askPin(act: Activity, restoreOnly: Boolean, done: (Boolean) -> Unit) {
        Bg.go({ findFile(act) != null }) { r ->
            val exists = r.getOrElse { e ->
                Toast.makeText(act, e.message ?: "Google Drive fout", Toast.LENGTH_LONG).show()
                return@go
            }
            if (restoreOnly && !exists) {
                Toast.makeText(act, "Geen back-up gevonden in deze Google Drive", Toast.LENGTH_LONG).show()
                return@go
            }
            val field = EditText(act).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                hint = "Pincode (minstens 4 cijfers)"
            }
            androidx.appcompat.app.AlertDialog.Builder(act)
                .setTitle(if (exists) "Pincode van je back-up" else "Kies een pincode")
                .setMessage(
                    if (exists) "Vul de pincode in die je bij het aanmaken van de back-up hebt gekozen."
                    else "Hiermee worden je gegevens (ook wachtwoorden) versleuteld. Je hebt hem nodig op elk ander apparaat."
                )
                .setView(field)
                .setPositiveButton("OK") { _, _ ->
                    val pin = field.text.toString().trim()
                    if (pin.length < 4) {
                        Toast.makeText(act, "Pincode moet minstens 4 cijfers zijn", Toast.LENGTH_LONG).show()
                        askPin(act, restoreOnly, done)
                        return@setPositiveButton
                    }
                    if (!exists) run(act, Mode.PUSH, pin, done)
                    else if (restoreOnly) run(act, Mode.RESTORE, pin, done)
                    else chooseMode(act, pin, done)
                }
                .setNegativeButton("Annuleren", null)
                .show()
        }
    }

    private fun chooseMode(act: Activity, pin: String, done: (Boolean) -> Unit) {
        val opts = arrayOf(
            "Back-up terugzetten op dit apparaat",
            "Samenvoegen (nieuwste wint)",
            "Dit apparaat naar de cloud (back-up overschrijven)"
        )
        androidx.appcompat.app.AlertDialog.Builder(act)
            .setTitle("Er staat al een back-up")
            .setItems(opts) { _, which ->
                run(act, when (which) { 0 -> Mode.RESTORE; 1 -> Mode.MERGE; else -> Mode.PUSH }, pin, done)
            }
            .show()
    }

    private fun run(act: Activity, mode: Mode, pin: String, done: (Boolean) -> Unit) {
        Toast.makeText(act, "Bezig met synchroniseren…", Toast.LENGTH_SHORT).show()
        Bg.go({ sync(act, mode, pin) }) { r ->
            r.onSuccess { changed ->
                cfg(act).edit().putString("pin", pin).apply()
                Toast.makeText(act, if (mode == Mode.PUSH) "Back-up gemaakt in Google Drive" else "Gesynchroniseerd", Toast.LENGTH_LONG).show()
                done(changed && mode != Mode.PUSH)
            }.onFailure { e ->
                Toast.makeText(act, e.message ?: "Synchroniseren mislukt", Toast.LENGTH_LONG).show()
                if (e is WrongPin) askPin(act, mode == Mode.RESTORE, done)
            }
        }
    }

    /** App opnieuw opbouwen na terugzetten (providers, profielen…). */
    fun restart(act: Activity) {
        Repo.reset()
        Epg.clear()
        UserProfiles.chosen = false
        act.startActivity(
            Intent(act, LoginActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        )
        act.finish()
    }
}
