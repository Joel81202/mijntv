package nl.michel.iptv

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import org.json.JSONObject

/** Seriepagina in Netflix-stijl: info, seizoenen, afleveringen onder elkaar, cast en meer. */
class SeriesActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var series: Item
    private lateinit var episodeAdapter: EpisodeAdapter
    private lateinit var seasonAdapter: ChipAdapter
    private lateinit var btnPlay: Button
    private lateinit var btnFav: Button
    private lateinit var backdrop: ImageView

    private var seasons: List<Season> = emptyList()
    private var currentSeason = 0
    private var tvId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val parsed = intent.getStringExtra("item")?.let { runCatching { itemFromJson(JSONObject(it)) }.getOrNull() }
        val api = if (parsed != null && Repo.ensureApi(this)) Repo.apiFor(parsed) else null
        if (parsed == null || api == null) {
            finish(); return
        }
        series = parsed
        prefs = Prefs(this)
        Tmdb.init(this)
        setContentView(R.layout.activity_series)

        backdrop = findViewById(R.id.backdrop)
        val title = findViewById<TextView>(R.id.title)
        val meta = findViewById<TextView>(R.id.meta)
        val plot = findViewById<TextView>(R.id.plot)
        val extra = findViewById<TextView>(R.id.extra)
        btnPlay = findViewById(R.id.btnPlay)
        btnFav = findViewById(R.id.btnFav)
        val castTitle = findViewById<TextView>(R.id.castTitle)
        val castList = findViewById<RecyclerView>(R.id.castList)
        val recsTitle = findViewById<TextView>(R.id.recsTitle)
        val recsList = findViewById<RecyclerView>(R.id.recsList)

        title.text = series.name
        meta.text = metaLine(series)
        plot.text = series.plot
        loadBackdrop(series.backdrop.ifEmpty { series.icon })
        updateFavButton()

        btnPlay.zoomOnFocus()
        btnFav.zoomOnFocus()
        btnFav.setOnClickListener {
            prefs.toggleFav(series.favKey)
            updateFavButton()
        }
        btnPlay.setOnClickListener { playResumeOrFirst() }
        btnPlay.text = "Laden…"

        seasonAdapter = ChipAdapter { i -> showSeason(i) }
        findViewById<RecyclerView>(R.id.seasons).apply {
            layoutManager = LinearLayoutManager(this@SeriesActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = seasonAdapter
        }

        episodeAdapter = EpisodeAdapter(prefs) { ep, list -> play(ep, list) }
        episodeAdapter.fallbackImage = series.backdrop.ifEmpty { series.icon }
        findViewById<RecyclerView>(R.id.episodes).apply {
            layoutManager = LinearLayoutManager(this@SeriesActivity)
            isNestedScrollingEnabled = false
            adapter = episodeAdapter
        }

        val castAdapter = PersonAdapter { p -> openPerson(this, p) }
        castList.horizontal()
        castList.adapter = castAdapter
        val recsAdapter = CardAdapter(
            prefs,
            onClick = { it, list -> openItem(this, it, list) },
            onLongClick = { },
            onFocus = { }
        )
        recsList.horizontal()
        recsList.adapter = recsAdapter

        // Nederlandse info, cast en aanbevelingen van TMDB
        Tmdb.lookup(series) { m ->
            if (m == null || isFinishing) return@lookup
            tvId = m.tmdbId
            title.text = m.title.ifEmpty { series.name }
            meta.text = metaLine(series, m)
            if (m.overview.isNotEmpty()) plot.text = m.overview
            val img = m.backdrop.ifEmpty { m.poster }
            if (img.isNotEmpty()) {
                loadBackdrop(img)
                episodeAdapter.fallbackImage = img
            }
            if (seasons.isNotEmpty()) showSeason(currentSeason)
            Tmdb.credits(Type.SERIES, m.tmdbId) { c ->
                if (c == null || isFinishing) return@credits
                if (c.director.isNotEmpty()) extra.text = "Bedacht door: " + c.director
                if (c.cast.isNotEmpty()) {
                    castTitle.visibility = View.VISIBLE
                    castAdapter.submit(c.cast)
                }
                if (c.recs.isNotEmpty()) {
                    recsTitle.visibility = View.VISIBLE
                    recsAdapter.submit(c.recs)
                }
            }
        }

        // Seizoenen en afleveringen van de provider
        Bg.go({ api.seriesInfo(series.id) }) { result ->
            if (isFinishing) return@go
            result.onSuccess { d ->
                if (tvId.isEmpty()) {
                    meta.text = metaLine(series, d)
                    if (d.plot.isNotEmpty()) plot.text = d.plot
                    if (d.backdrop.isNotEmpty()) loadBackdrop(d.backdrop)
                    if (extra.text.isNullOrEmpty() && d.cast.isNotEmpty()) extra.text = "Met: " + d.cast
                }
                seasons = d.seasons
                if (seasons.isEmpty()) {
                    btnPlay.text = "Geen afleveringen"
                    return@onSuccess
                }
                seasonAdapter.submit(seasons.map { "Seizoen ${it.number}" }, 0)
                val last = findLastEpisode()
                showSeason(last?.first ?: 0)
                updatePlayButton()
                btnPlay.requestFocus()
            }.onFailure { e ->
                btnPlay.text = "Laden mislukt"
                plot.text = e.message ?: ""
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::episodeAdapter.isInitialized && seasons.isNotEmpty()) {
            episodeAdapter.lastWatchedId = prefs.lastEpisode(series.id)
            episodeAdapter.notifyDataSetChanged()
            updatePlayButton()
        }
    }

    private fun loadBackdrop(url: String) {
        if (url.isNotEmpty()) Glide.with(backdrop).load(url).into(backdrop)
    }

    private fun updateFavButton() {
        btnFav.text = if (prefs.isFav(series.favKey)) "✓  Mijn lijst" else "+  Mijn lijst"
    }

    private fun showSeason(i: Int) {
        if (i !in seasons.indices) return
        currentSeason = i
        seasonAdapter.select(i)
        episodeAdapter.lastWatchedId = prefs.lastEpisode(series.id)
        episodeAdapter.submit(seasons[i].episodes)
        val number = seasons[i].number
        if (tvId.isEmpty()) return
        Tmdb.season(tvId, number) { eps ->
            if (isFinishing || eps.isEmpty() || i !in seasons.indices) return@season
            val byNum = eps.associateBy { it.number }
            val enriched = seasons[i].episodes.map { ep ->
                val e = byNum[ep.num] ?: return@map ep
                ep.copy(
                    name = e.name.ifEmpty { ep.name },
                    plot = e.overview.ifEmpty { ep.plot },
                    icon = e.still.ifEmpty { ep.icon },
                    duration = ep.duration.ifEmpty { e.runtime }
                )
            }
            seasons = seasons.toMutableList().also { it[i] = Season(number, enriched) }
            if (currentSeason == i) episodeAdapter.submit(enriched)
        }
    }

    /** Laatst bekeken aflevering: (seizoen-index, aflevering-index). */
    private fun findLastEpisode(): Pair<Int, Int>? {
        val lastId = prefs.lastEpisode(series.id)
        if (lastId.isEmpty()) return null
        seasons.forEachIndexed { si, s ->
            val ei = s.episodes.indexOfFirst { it.id == lastId }
            if (ei >= 0) return Pair(si, ei)
        }
        return null
    }

    private fun updatePlayButton() {
        val last = findLastEpisode()
        btnPlay.text = if (last == null) {
            "▶  Afspelen"
        } else {
            val s = seasons[last.first]
            "▶  Verder kijken  S${s.number}:A${s.episodes[last.second].num}"
        }
    }

    private fun playResumeOrFirst() {
        if (seasons.isEmpty()) return
        val last = findLastEpisode()
        val s = seasons[last?.first ?: 0]
        val ep = s.episodes.getOrNull(last?.second ?: 0) ?: return
        play(ep, s.episodes)
    }

    private fun play(ep: Item, list: List<Item>) {
        prefs.setLastEpisode(series.id, ep.id)
        PlayQueue.set(list, ep, series)
        startActivity(Intent(this, PlayerActivity::class.java))
    }
}
