package nl.michel.iptv

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import org.json.JSONObject

/** Seriepagina in Netflix-stijl: info, seizoenen, afleveringen onder elkaar, cast en meer. */
class SeriesActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var series: Item
    private lateinit var episodeAdapter: EpisodeAdapter
    private lateinit var seasonAdapter: ChipAdapter
    private lateinit var btnPlay: Button
    private lateinit var btnFav: Button
    private lateinit var backdrop: ImageView

    private var seasons: List<Season> = emptyList()
    private var currentSeason = 0
    private var tvId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val parsed = intent.getStringExtra("item")?.let { runCatching { itemFromJson(JSONObject(it)) }.getOrNull() }
        val api = if (parsed != null && Repo.ensureApi(this)) Repo.apiFor(parsed) else null
        if (parsed == null || api == null) {
            finish(); return
        }
        series = parsed
        prefs = Prefs(this)
        Tmdb.init(this)
        setContentView(R.layout.activity_series)

        backdrop = findViewById(R.id.backdrop)
        val title = findViewById<TextView>(R.id.title)
        val meta = findViewById<TextView>(R.id.meta)
        val plot = findViewById<TextView>(R.id.plot)
        val extra = findViewById<TextView>(R.id.extra)
        btnPlay = findViewById(R.id.btnPlay)
        btnFav = findViewById(R.id.btnFav)
        val castTitle = findViewById<TextView>(R.id.castTitle)
        val castList = findViewById<RecyclerView>(R.id.castList)
        val recsTitle = findViewById<TextView>(R.id.recsTitle)
        val recsList = findViewById<RecyclerView>(R.id.recsList)

        title.text = series.name
        meta.text = metaLine(series)
        plot.text = series.plot
        loadBackdrop(series.backdrop.ifEmpty { series.icon })
        updateFavButton()

        btnPlay.zoomOnFocus()
        btnFav.zoomOnFocus()
        btnFav.setOnClickListener {
            prefs.toggleFav(series.favKey)
            updateFavButton()
        }
        btnPlay.setOnClickListener { playResumeOrFirst() }
        btnPlay.text = "Laden…"

        seasonAdapter = ChipAdapter { i -> showSeason(i) }
        findViewById<RecyclerView>(R.id.seasons).apply {
            layoutManager = LinearLayoutManager(this@SeriesActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = seasonAdapter
        }

        episodeAdapter = EpisodeAdapter(prefs) { ep, list -> play(ep, list) }
        episodeAdapter.fallbackImage = series.backdrop.ifEmpty { series.icon }
        findViewById<RecyclerView>(R.id.episodes).apply {
            layoutManager = LinearLayoutManager(this@SeriesActivity)
            isNestedScrollingEnabled = false
            adapter = episodeAdapter
        }

        val castAdapter = PersonAdapter { p -> openPerson(this, p) }
        castList.horizontal()
        castList.adapter = castAdapter
        val recsAdapter = CardAdapter(
            prefs,
            onClick = { it, list -> openItem(this, it, list) },
            onLongClick = { },
            onFocus = { }
        )
        recsList.horizontal()
        recsList.adapter = recsAdapter

        // Nederlandse info, cast en aanbevelingen van TMDB
        Tmdb.lookup(series) { m ->
            if (m == null || isFinishing) return@lookup
            tvId = m.tmdbId
            Tmdb.trailer(Type.SERIES, m.tmdbId) { key ->
                if (key == null || isFinishing) return@trailer
                findViewById<Button>(R.id.btnTrailer).apply {
                    visibility = View.VISIBLE
                    zoomOnFocus()
                    setOnClickListener { Tmdb.playTrailer(this@SeriesActivity, key) }
                }
            }
            title.text = m.title.ifEmpty { series.name }
            meta.text = metaLine(series, m)
            if (m.overview.isNotEmpty()) plot.text = m.overview
            val img = m.backdrop.ifEmpty { m.poster }
            if (img.isNotEmpty()) {
                loadBackdrop(img)
                episodeAdapter.fallbackImage = img
            }
            if (seasons.isNotEmpty()) showSeason(currentSeason)
            Tmdb.credits(Type.SERIES, m.tmdbId) { c ->
                if (c == null || isFinishing) return@credits
                if (c.director.isNotEmpty()) extra.text = "Bedacht door: " + c.director
                if (c.cast.isNotEmpty()) {
                    castTitle.visibility = View.VISIBLE
                    castAdapter.submit(c.cast)
                }
                if (c.recs.isNotEmpty()) {
                    recsTitle.visibility = View.VISIBLE
                    recsAdapter.submit(c.recs)
                }
            }
        }

        // Seizoenen en afleveringen van de provider
        Bg.go({ api.seriesInfo(series.id) }) { result ->
            if (isFinishing) return@go
            result.onSuccess { d ->
                if (tvId.isEmpty()) {
                    meta.text = metaLine(series, d)
                    if (d.plot.isNotEmpty()) plot.text = d.plot
                    if (d.backdrop.isNotEmpty()) loadBackdrop(d.backdrop)
                    if (extra.text.isNullOrEmpty() && d.cast.isNotEmpty()) extra.text = "Met: " + d.cast
                }
                seasons = d.seasons
                if (seasons.isEmpty()) {
                    btnPlay.text = "Geen afleveringen"
                    return@onSuccess
                }
                seasonAdapter.submit(seasons.map { "Seizoen ${it.number}" }, 0)
                val last = findLastEpisode()
                showSeason(last?.first ?: 0)
                updatePlayButton()
                btnPlay.requestFocus()
            }.onFailure { e ->
                btnPlay.text = "Laden mislukt"
                plot.text = e.message ?: ""
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::episodeAdapter.isInitialized && seasons.isNotEmpty()) {
            episodeAdapter.lastWatchedId = prefs.lastEpisode(series.id)
            episodeAdapter.notifyDataSetChanged()
            updatePlayButton()
        }
    }

    private fun loadBackdrop(url: String) {
        if (url.isNotEmpty()) Glide.with(backdrop).load(url).into(backdrop)
    }

    private fun updateFavButton() {
        btnFav.text = if (prefs.isFav(series.favKey)) "✓  Mijn lijst" else "+  Mijn lijst"
    }

    private fun showSeason(i: Int) {
        if (i !in seasons.indices) return
        currentSeason = i
        seasonAdapter.select(i)
        episodeAdapter.lastWatchedId = prefs.lastEpisode(series.id)
        val number = seasons[i].number
        val showTmdb = tvId.ifEmpty { TraktSync.tmdbOf(series) }
        episodeAdapter.watchedNums = traktSeen?.let { seen ->
            val prefix = "${number.toIntOrNull() ?: number}:"
            seen.filter { it.startsWith(prefix) }.map { it.removePrefix(prefix) }.toSet()
        } ?: if (showTmdb.isNotEmpty()) TraktSync.watchedIn(showTmdb, number) else emptySet()
        loadTraktSeen(showTmdb)
        episodeAdapter.submit(seasons[i].episodes)
        if (tvId.isEmpty()) return
        Tmdb.season(tvId, number) { eps ->
            if (isFinishing || eps.isEmpty() || i !in seasons.indices) return@season
            val byNum = eps.associateBy { it.number }
            val enriched = seasons[i].episodes.map { ep ->
                val e = byNum[ep.num] ?: return@map ep
                ep.copy(
                    name = e.name.ifEmpty { ep.name },
                    plot = e.overview.ifEmpty { ep.plot },
                    icon = e.still.ifEmpty { ep.icon },
                    duration = ep.duration.ifEmpty { e.runtime }
                )
            }
            seasons = seasons.toMutableList().also { it[i] = Season(number, enriched) }
            if (currentSeason == i) episodeAdapter.submit(enriched)
        }
    }

    /** Gekeken afleveringen van deze serie, vers van Trakt (null = nog niet opgehaald). */
    private var traktSeen: Set<String>? = null
    private var traktAsked = ""

    private fun loadTraktSeen(showTmdb: String) {
        if (!Trakt.linked(prefs) || traktAsked == showTmdb + "|" + tvId) return
        traktAsked = showTmdb + "|" + tvId
        val (title, year) = Tmdb.cleanTitle(series.name)
        val y = series.year.ifEmpty { year }
        Bg.go({ TraktSync.showWatched(prefs, showTmdb, title, y) }) { r ->
            val set = r.getOrNull() ?: return@go
            if (isFinishing || set.isEmpty()) return@go
            traktSeen = set
            if (seasons.isNotEmpty()) updatePlayButton()
            if (currentSeason in seasons.indices) {
                episodeAdapter.watchedNums = set.filter { it.startsWith("${seasons[currentSeason].number.toIntOrNull() ?: seasons[currentSeason].number}:") }
                    .map { it.substringAfter(":") }.toSet()
                episodeAdapter.notifyDataSetChanged()
            }
        }
    }

    /** Gekeken afleveringen als "seizoen:aflevering" (vers van Trakt als dat er is). */
    private fun seenSet(): Set<String> {
        traktSeen?.let { return it }
        val showTmdb = tvId.ifEmpty { TraktSync.tmdbOf(series) }
        return if (showTmdb.isEmpty()) emptySet() else TraktSync.watchedEpisodes[showTmdb] ?: emptySet()
    }

    private fun keyOf(si: Int, ei: Int): String {
        val s = seasons[si]
        return "${s.number.toIntOrNull() ?: s.number}:${s.episodes[ei].num.toIntOrNull() ?: s.episodes[ei].num}"
    }

    /** Alle afleveringen op volgorde: (seizoen-index, aflevering-index). Specials (seizoen 0) achteraan. */
    private fun ordered(): List<Pair<Int, Int>> =
        seasons.indices.sortedBy { if ((seasons[it].number.toIntOrNull() ?: 0) == 0) Int.MAX_VALUE else it }
            .flatMap { si -> seasons[si].episodes.indices.map { Pair(si, it) } }

    /**
     * Waar verder kijken: de eerstvolgende niet-bekeken aflevering na de laatst bekeken aflevering
     * (eigen geschiedenis en Trakt). Een half gekeken aflevering gaat voor.
     */
    private fun findLastEpisode(): Pair<Int, Int>? {
        val order = ordered()
        if (order.isEmpty()) return null
        val seen = seenSet()
        val pos = HashMap<Pair<Int, Int>, Int>().apply { order.forEachIndexed { i, p -> put(p, i) } }
        val candidates = ArrayList<Int>()
        val lastId = prefs.lastEpisode(series.id)
        if (lastId.isNotEmpty()) {
            val i = order.indexOfFirst { (si, ei) -> seasons[si].episodes[ei].id == lastId }
            if (i >= 0) candidates.add(if (seen.contains(keyOf(order[i].first, order[i].second))) i + 1 else i)
        }
        val lastSeen = order.indices.lastOrNull { i ->
            seen.contains(keyOf(order[i].first, order[i].second)) && (seasons[order[i].first].number.toIntOrNull() ?: 0) > 0
        }
        if (lastSeen != null) candidates.add(lastSeen + 1)
        traktNext()?.let { p -> pos[p]?.let { candidates.add(it) } }
        if (candidates.isEmpty()) return null
        var i = candidates.max()
        while (i < order.size && seen.contains(keyOf(order[i].first, order[i].second))) i++
        return order.getOrNull(i) ?: order.last()
    }

    /** Geen eigen geschiedenis? Dan de volgende ongeziene aflevering volgens Trakt. */
    private fun traktNext(): Pair<Int, Int>? {
        val showTmdb = tvId.ifEmpty { TraktSync.tmdbOf(series) }
        if (showTmdb.isEmpty()) return null
        var (s, e) = TraktSync.nextEpisode(showTmdb) ?: return null
        for (attempt in 0..1) {
            val si = seasons.indexOfFirst { it.number.toIntOrNull() == s }
            if (si >= 0) {
                val ei = seasons[si].episodes.indexOfFirst { it.num.toIntOrNull() == e }
                if (ei >= 0) return Pair(si, ei)
            }
            // Laatste aflevering van het seizoen gezien: eerste van het volgende seizoen
            s += 1; e = 1
        }
        return null
    }

    private fun updatePlayButton() {
        val last = findLastEpisode()
        btnPlay.text = if (last == null) {
            "▶  Afspelen"
        } else {
            val s = seasons[last.first]
            "▶  Verder kijken  S${s.number}:A${s.episodes[last.second].num}"
        }
    }

    private fun playResumeOrFirst() {
        if (seasons.isEmpty()) return
        val last = findLastEpisode()
        val s = seasons[last?.first ?: 0]
        val ep = s.episodes.getOrNull(last?.second ?: 0) ?: return
        play(ep, s.episodes)
    }

    private fun play(ep: Item, list: List<Item>) {
        prefs.setLastEpisode(series.id, ep.id)
        PlayQueue.set(list, ep, series)
        startActivity(Intent(this, PlayerActivity::class.java))
    }
}
