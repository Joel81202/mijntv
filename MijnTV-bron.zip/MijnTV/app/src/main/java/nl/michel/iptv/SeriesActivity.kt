package nl.michel.iptv

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import org.json.JSONObject

class SeriesActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var series: Item
    private lateinit var episodeAdapter: CardAdapter
    private lateinit var seasonAdapter: ChipAdapter
    private lateinit var btnPlay: Button
    private lateinit var btnFav: Button
    private lateinit var epInfo: TextView

    private var seasons: List<Season> = emptyList()
    private var currentSeason = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val json = intent.getStringExtra("item")
        val parsed = json?.let { runCatching { itemFromJson(JSONObject(it)) }.getOrNull() }
        val api = Repo.api
        if (parsed == null || api == null) {
            finish()
            return
        }
        series = parsed
        prefs = Prefs(this)
        setContentView(R.layout.activity_series)

        val backdrop = findViewById<ImageView>(R.id.backdrop)
        val title = findViewById<TextView>(R.id.title)
        val meta = findViewById<TextView>(R.id.meta)
        val plot = findViewById<TextView>(R.id.plot)
        btnPlay = findViewById(R.id.btnPlay)
        btnFav = findViewById(R.id.btnFav)
        epInfo = findViewById(R.id.epInfo)

        title.text = series.name
        meta.text = metaLine(series)
        plot.text = series.plot
        loadImage(backdrop, series.backdrop.ifEmpty { series.icon })
        updateFavButton()

        btnPlay.focusZoomOnFocus()
        btnFav.focusZoomOnFocus()
        btnFav.setOnClickListener {
            prefs.toggleFav(series.favKey)
            updateFavButton()
        }
        btnPlay.setOnClickListener { playResumeOrFirst() }
        btnPlay.text = "Laden…"

        seasonAdapter = ChipAdapter { i -> showSeason(i) }
        episodeAdapter = CardAdapter(
            prefs,
            onClick = { ep, list -> play(ep, list) },
            onLongClick = { },
            onFocus = { ep -> epInfo.text = if (ep.plot.isNotEmpty()) "${ep.num}. ${ep.name}\n${ep.plot}" else "${ep.num}. ${ep.name}" }
        )
        findViewById<RecyclerView>(R.id.seasons).apply {
            layoutManager = LinearLayoutManager(this@SeriesActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = seasonAdapter
        }
        findViewById<RecyclerView>(R.id.episodes).apply {
            layoutManager = LinearLayoutManager(this@SeriesActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = episodeAdapter
        }

        Bg.go({ api.seriesInfo(series.id) }) { result ->
            if (isFinishing) return@go
            result.onSuccess { d ->
                meta.text = metaLine(series, d)
                if (d.plot.isNotEmpty()) plot.text = d.plot
                if (d.backdrop.isNotEmpty()) loadImage(backdrop, d.backdrop)
                seasons = d.seasons
                if (seasons.isEmpty()) {
                    btnPlay.text = "Geen afleveringen"
                    return@onSuccess
                }
                seasonAdapter.submit(seasons.map { "Seizoen ${it.number}" }, 0)
                val last = findLastEpisode()
                showSeason(last?.first ?: 0)
                updatePlayButton()
                btnPlay.requestFocus()
            }.onFailure { e ->
                btnPlay.text = "Laden mislukt"
                epInfo.text = e.message ?: ""
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::episodeAdapter.isInitialized && seasons.isNotEmpty()) {
            episodeAdapter.notifyDataSetChanged()
            updatePlayButton()
        }
    }

    private fun loadImage(view: ImageView, url: String) {
        if (url.isNotEmpty()) Glide.with(view).load(url).into(view)
    }

    private fun Button.focusZoomOnFocus() {
        setOnFocusChangeListener { v, f -> v.focusZoom(f, 1.06f) }
    }

    private fun updateFavButton() {
        btnFav.text = if (prefs.isFav(series.favKey)) "✓  Mijn lijst" else "+  Mijn lijst"
    }

    private fun showSeason(i: Int) {
        if (i !in seasons.indices) return
        currentSeason = i
        seasonAdapter.select(i)
        episodeAdapter.submit(seasons[i].episodes)
    }

    /** Zoek de laatst bekeken aflevering: (seizoen-index, aflevering-index). */
    private fun findLastEpisode(): Pair<Int, Int>? {
        val lastId = prefs.lastEpisode(series.id)
        if (lastId.isEmpty()) return null
        seasons.forEachIndexed { si, s ->
            val ei = s.episodes.indexOfFirst { it.id == lastId }
            if (ei >= 0) return Pair(si, ei)
        }
        return null
    }

    private fun updatePlayButton() {
        val last = findLastEpisode()
        btnPlay.text = if (last == null) {
            "▶  Afspelen"
        } else {
            val s = seasons[last.first]
            "▶  Verder kijken  S${s.number}:A${s.episodes[last.second].num}"
        }
    }

    private fun playResumeOrFirst() {
        if (seasons.isEmpty()) return
        val last = findLastEpisode()
        val s = seasons[last?.first ?: 0]
        val ep = s.episodes.getOrNull(last?.second ?: 0) ?: return
        play(ep, s.episodes)
    }

    private fun play(ep: Item, list: List<Item>) {
        prefs.setLastEpisode(series.id, ep.id)
        PlayQueue.set(list, ep, series)
        startActivity(Intent(this, PlayerActivity::class.java))
    }
}
