package nl.michel.iptv

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Controleert GitHub op een nieuwe versie en installeert die met één knop. */
object Updater {
    data class Release(val version: String, val notes: String, val apkUrl: String, val size: Long)

    private val repo get() = BuildConfig.GITHUB_REPO
    private val apkName get() = if (BuildConfig.HAS_TRAKT) "MijnTV.apk" else "MijnTV-Public.apk"

    fun configured() = repo.contains("/")

    @Volatile private var lastCheck = 0L
    @Volatile private var shownFor = ""

    /** "1.04" > "1.03"? */
    fun newer(remote: String, local: String): Boolean {
        val r = remote.trimStart('v', 'V').split(".").map { it.toIntOrNull() ?: 0 }
        val l = local.trimStart('v', 'V').split(".").map { it.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(r.size, l.size)) {
            val a = r.getOrElse(i) { 0 }
            val b = l.getOrElse(i) { 0 }
            if (a != b) return a > b
        }
        return false
    }

    private fun fetchLatest(): Release? {
        val c = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 15000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "MijnTV")
        try {
            if (c.responseCode !in 200..299) return null
            val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val version = o.optString("tag_name").trimStart('v', 'V')
            val assets = o.optJSONArray("assets") ?: return null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name") == apkName) {
                    return Release(version, cleanNotes(o.optString("body")), a.optString("browser_download_url"), a.optLong("size"))
                }
            }
            return null
        } finally { c.disconnect() }
    }

    /** Alleen de wijzigingen van de nieuwste versie, zonder opmaak. */
    private fun cleanNotes(body: String): String =
        body.substringBefore("<details>").lines()
            .filter { !it.startsWith("## ") }
            .map { it.replace("**", "").replace(Regex("^- "), "•  ") }
            .joinToString("\n").trim()

    /** Bij het openen van de app (hooguit eens per 6 uur), of handmatig via Instellingen. */
    fun check(act: Activity, manual: Boolean = false) {
        if (!configured()) {
            if (manual) Toast.makeText(act, "Updates controleren is in deze versie niet ingesteld", Toast.LENGTH_LONG).show()
            return
        }
        val now = System.currentTimeMillis()
        if (!manual && now - lastCheck < 6 * 3600_000L) return
        lastCheck = now
        if (manual) Toast.makeText(act, "Zoeken naar updates…", Toast.LENGTH_SHORT).show()
        Bg.go({ fetchLatest() }) { r ->
            if (act.isFinishing) return@go
            val rel = r.getOrNull()
            if (rel == null || !newer(rel.version, BuildConfig.VERSION_NAME)) {
                if (manual) Toast.makeText(act, "Je hebt de nieuwste versie (${BuildConfig.VERSION_NAME})", Toast.LENGTH_LONG).show()
                return@go
            }
            if (!manual && shownFor == rel.version) return@go
            shownFor = rel.version
            androidx.appcompat.app.AlertDialog.Builder(act)
                .setTitle("Nieuwe versie: ${rel.version}")
                .setMessage("Je hebt nu ${BuildConfig.VERSION_NAME}.\n\nNieuw:\n${rel.notes.ifEmpty { "Verbeteringen" }}")
                .setPositiveButton("Installeren") { _, _ -> download(act, rel) }
                .setNegativeButton("Later", null)
                .show()
        }
    }

    private fun download(act: Activity, rel: Release) {
        // Android 8+: eenmalig toestemming om apps te installeren
        if (Build.VERSION.SDK_INT >= 26 && !act.packageManager.canRequestPackageInstalls()) {
            Toast.makeText(act, "Zet 'Onbekende apps installeren' aan voor MijnTV en kies daarna opnieuw Installeren", Toast.LENGTH_LONG).show()
            runCatching {
                act.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + act.packageName)))
            }
            shownFor = ""
            lastCheck = 0L
            return
        }
        val pad = dp(act, 20f)
        val bar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val label = TextView(act).apply { text = "Downloaden…" }
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            addView(label); addView(bar)
        }
        val dialog = androidx.appcompat.app.AlertDialog.Builder(act)
            .setTitle("MijnTV ${rel.version}")
            .setView(box)
            .setNegativeButton("Annuleren", null)
            .show()
        val main = android.os.Handler(android.os.Looper.getMainLooper())
        Bg.go({
            val dir = File(if (Build.VERSION.SDK_INT >= 24) act.cacheDir else (act.externalCacheDir ?: act.cacheDir), "updates")
            dir.mkdirs()
            dir.listFiles()?.forEach { it.delete() }
            val out = File(dir, apkName)
            val c = URL(rel.apkUrl).openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 30000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "MijnTV")
            try {
                if (c.responseCode !in 200..299) throw java.io.IOException("Download mislukt (${c.responseCode})")
                val total = c.contentLength.toLong().takeIf { it > 0 } ?: rel.size
                var done = 0L
                var lastPct = -1
                c.inputStream.use { input ->
                    out.outputStream().use { output ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            if (dialog?.isShowing == false) throw java.io.IOException("Geannuleerd")
                            val n = input.read(buf)
                            if (n < 0) break
                            output.write(buf, 0, n)
                            done += n
                            val pct = if (total > 0) (done * 100 / total).toInt() else 0
                            if (pct != lastPct) {
                                lastPct = pct
                                main.post { bar.progress = pct; label.text = "Downloaden…  $pct%" }
                            }
                        }
                    }
                }
            } finally { c.disconnect() }
            out
        }) { r ->
            dialog?.dismiss()
            r.onSuccess { file -> install(act, file) }
                .onFailure { e -> if (e.message != "Geannuleerd") Toast.makeText(act, e.message ?: "Download mislukt", Toast.LENGTH_LONG).show() }
        }
    }

    private fun install(ctx: Context, file: File) {
        val uri = if (Build.VERSION.SDK_INT >= 24)
            androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".files", file)
        else Uri.fromFile(file)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { ctx.startActivity(i) }.onFailure {
            Toast.makeText(ctx, "Installeren kon niet starten: ${it.message}", Toast.LENGTH_LONG).show()
        }
    }
}
