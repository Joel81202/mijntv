package nl.michel.iptv

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

/** Achtergrondwerk met resultaat terug op de UI-thread. */
object Bg {
    private val pool = Executors.newFixedThreadPool(4)
    private val main = Handler(Looper.getMainLooper())

    fun <T> go(work: () -> T, done: (Result<T>) -> Unit) {
        pool.execute {
            val r = runCatching(work)
            main.post { done(r) }
        }
    }
}

fun Item.toJson(): JSONObject = JSONObject()
    .put("id", id).put("name", name).put("icon", icon).put("cat", categoryId)
    .put("type", type.name).put("ext", ext).put("plot", plot).put("rating", rating)
    .put("year", year).put("backdrop", backdrop).put("num", num).put("epg", epg)

fun itemFromJson(o: JSONObject): Item? = try {
    Item(
        o.s("id"), o.s("name"), o.s("icon"), o.s("cat"), Type.valueOf(o.s("type")), o.s("ext"),
        plot = o.s("plot"), rating = o.s("rating"), year = o.s("year"), backdrop = o.s("backdrop"),
        num = o.s("num"), epg = o.s("epg")
    )
} catch (e: Exception) {
    null
}

/** Opgeslagen login, instellingen, favorieten en kijkvoortgang. */
class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("mijntv", Context.MODE_PRIVATE)

    var server: String
        get() = p.getString("server", "") ?: ""
        set(v) { p.edit().putString("server", v).apply() }

    var user: String
        get() = p.getString("user", "") ?: ""
        set(v) { p.edit().putString("user", v).apply() }

    var pass: String
        get() = p.getString("pass", "") ?: ""
        set(v) { p.edit().putString("pass", v).apply() }

    var hls: Boolean
        get() = p.getBoolean("hls", false)
        set(v) { p.edit().putBoolean("hls", v).apply() }

    fun hasLogin(): Boolean = server.isNotEmpty() && user.isNotEmpty()

    fun logout() {
        p.edit().remove("server").remove("user").remove("pass").apply()
    }

    // ----- Mijn lijst -----

    fun favorites(): Set<String> = HashSet(p.getStringSet("favs", emptySet()) ?: emptySet())

    fun isFav(key: String): Boolean = favorites().contains(key)

    /** Geeft true terug als het item nu in Mijn lijst staat. */
    fun toggleFav(key: String): Boolean {
        val set = HashSet(favorites())
        val added = if (set.contains(key)) {
            set.remove(key); false
        } else {
            set.add(key); true
        }
        p.edit().putStringSet("favs", set).apply()
        return added
    }

    // ----- Verder kijken -----

    fun getPos(key: String): Long = p.getLong("pos:$key", 0L)

    fun getProgress(key: String): Int = p.getInt("pct:$key", 0)

    fun savePos(key: String, ms: Long, percent: Int) {
        p.edit().putLong("pos:$key", ms).putInt("pct:$key", percent).apply()
    }

    fun clearPos(key: String) {
        p.edit().remove("pos:$key").remove("pct:$key").apply()
    }

    var lastChannel: String
        get() = p.getString("lastch", "") ?: ""
        set(v) { p.edit().putString("lastch", v).apply() }

    var lastGroup: String
        get() = p.getString("lastgroup", "*") ?: "*"
        set(v) { p.edit().putString("lastgroup", v).apply() }

    fun lastEpisode(seriesId: String): String = p.getString("lastep:$seriesId", "") ?: ""

    fun setLastEpisode(seriesId: String, episodeId: String) {
        p.edit().putString("lastep:$seriesId", episodeId).apply()
    }

    fun recents(): List<Item> {
        val arr = try {
            JSONArray(p.getString("recents", "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }
        return arr.objects().mapNotNull { itemFromJson(it) }
    }

    fun addRecent(item: Item) {
        val list = recents().filter { it.favKey != item.favKey }.toMutableList()
        list.add(0, item)
        saveRecents(list.take(25))
    }

    fun removeRecent(key: String) {
        saveRecents(recents().filter { it.favKey != key })
    }

    private fun saveRecents(list: List<Item>) {
        val arr = JSONArray()
        for (i in list) arr.put(i.toJson())
        p.edit().putString("recents", arr.toString()).apply()
    }
}

/** In-memory cache van alles wat van de server komt. */
object Repo {
    var api: Xtream? = null
    var liveCats: List<Category> = emptyList()
    var vodCats: List<Category> = emptyList()
    var seriesCats: List<Category> = emptyList()
    var live: List<Item> = emptyList()
    var vod: List<Item> = emptyList()
    var series: List<Item> = emptyList()
    var liveByCat: Map<String, List<Item>> = emptyMap()
    var vodByCat: Map<String, List<Item>> = emptyMap()
    var seriesByCat: Map<String, List<Item>> = emptyMap()
    val details = HashMap<String, Details>()
    var liveLoaded = false
    var restLoaded = false
    var historyChanged = false

    fun clear() {
        liveCats = emptyList(); vodCats = emptyList(); seriesCats = emptyList()
        live = emptyList(); vod = emptyList(); series = emptyList()
        liveByCat = emptyMap(); vodByCat = emptyMap(); seriesByCat = emptyMap()
        details.clear()
        liveLoaded = false; restLoaded = false
    }

    fun ensureApi(ctx: Context): Boolean {
        if (api != null) return true
        val prefs = Prefs(ctx)
        if (!prefs.hasLogin()) return false
        api = Xtream(prefs.server, prefs.user, prefs.pass)
        return true
    }
}

/** Afspeellijst voor de speler (zappen / volgende aflevering). */
object PlayQueue {
    var items: List<Item> = emptyList()
    var index = 0
    var parent: Item? = null

    fun set(list: List<Item>, item: Item, parentItem: Item? = null) {
        parent = parentItem
        val i = list.indexOf(item)
        if (i >= 0) {
            items = list; index = i
        } else {
            items = listOf(item); index = 0
        }
    }

    fun current(): Item? = items.getOrNull(index)
}

/** Kaart vergroten bij focus, zoals op een tv-streamingdienst. */
fun View.focusZoom(hasFocus: Boolean, scale: Float = 1.12f) {
    val s = if (hasFocus) scale else 1f
    animate().scaleX(s).scaleY(s).setDuration(150).start()
    translationZ = if (hasFocus) 10f else 0f
}

/** Horizontale rij met kaarten. Het kaarttype volgt uit het soort item. */
class CardAdapter(
    private val prefs: Prefs,
    private val onClick: (Item, List<Item>) -> Unit,
    private val onLongClick: (Item) -> Unit,
    private val onFocus: (Item) -> Unit
) : RecyclerView.Adapter<CardAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.cardImage)
        val fallback: TextView = v.findViewById(R.id.cardFallback)
        val title: TextView? = v.findViewById(R.id.cardTitle)
        val progress: ProgressBar? = v.findViewById(R.id.cardProgress)
    }

    var items: List<Item> = emptyList()
        private set

    fun submit(list: List<Item>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = items.size

    override fun getItemViewType(position: Int): Int = items[position].type.ordinal

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = when (Type.values()[viewType]) {
            Type.LIVE -> R.layout.card_live
            Type.EPISODE -> R.layout.card_episode
            else -> R.layout.card_poster
        }
        return VH(LayoutInflater.from(parent.context).inflate(layout, parent, false))
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        val star = if (prefs.isFav(item.favKey)) "★ " else ""
        h.fallback.text = if (item.type == Type.EPISODE) item.num else item.name
        h.title?.text = when (item.type) {
            Type.EPISODE -> "${item.num}. ${item.name}"
            else -> star + item.name
        }
        if (item.icon.isNotEmpty()) {
            Glide.with(h.img).load(item.icon).into(h.img)
        } else {
            Glide.with(h.img).clear(h.img)
            h.img.setImageDrawable(null)
        }
        h.progress?.let { bar ->
            val pct = prefs.getProgress(item.favKey)
            bar.visibility = if (pct > 0) View.VISIBLE else View.GONE
            bar.progress = pct
        }
        h.itemView.scaleX = 1f
        h.itemView.scaleY = 1f
        h.itemView.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(items[p], items)
        }
        h.itemView.setOnLongClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) {
                onLongClick(items[p])
                notifyItemChanged(p)
            }
            true
        }
        h.itemView.setOnFocusChangeListener { v, hasFocus ->
            v.focusZoom(hasFocus)
            val p = h.bindingAdapterPosition
            if (hasFocus && p != RecyclerView.NO_POSITION) onFocus(items[p])
        }
    }
}

data class Row(val title: String, val items: List<Item>)

/** Verticale lijst van rijen ("Verder kijken", "Nieuwe films", categorieën…). */
class RowsAdapter(
    private val prefs: Prefs,
    private val onClick: (Item, List<Item>) -> Unit,
    private val onLongClick: (Item) -> Unit,
    private val onFocus: (Item) -> Unit
) : RecyclerView.Adapter<RowsAdapter.VH>() {

    private val pool = RecyclerView.RecycledViewPool()

    class VH(v: View, val cards: CardAdapter) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.sectionTitle)
        val list: RecyclerView = v.findViewById(R.id.sectionList)
    }

    var rows: List<Row> = emptyList()
        private set

    fun submit(list: List<Row>) {
        rows = list
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = rows.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_section, parent, false)
        val cards = CardAdapter(prefs, onClick, onLongClick, onFocus)
        val vh = VH(v, cards)
        vh.list.layoutManager = LinearLayoutManager(parent.context, LinearLayoutManager.HORIZONTAL, false)
        vh.list.setRecycledViewPool(pool)
        vh.list.adapter = cards
        return vh
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val row = rows[position]
        h.title.text = row.title
        h.cards.submit(row.items)
        h.list.scrollToPosition(0)
    }
}

/** Kleine knopjes, bijvoorbeeld voor seizoenen. */
class ChipAdapter(
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<ChipAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val text: TextView = v.findViewById(R.id.chipText)
    }

    private var labels: List<String> = emptyList()
    private var sel = 0

    fun submit(list: List<String>, selected: Int) {
        labels = list
        sel = selected
        notifyDataSetChanged()
    }

    fun select(i: Int) {
        val old = sel
        sel = i
        notifyItemChanged(old)
        notifyItemChanged(i)
    }

    override fun getItemCount(): Int = labels.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_chip, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        h.text.text = labels[position]
        h.itemView.isActivated = position == sel
        h.itemView.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(p)
        }
    }
}

fun metaLine(item: Item, d: Details? = null): String {
    val parts = ArrayList<String>()
    when (item.type) {
        Type.LIVE -> parts.add("LIVE")
        Type.MOVIE -> parts.add("Film")
        Type.SERIES -> parts.add("Serie")
        Type.EPISODE -> parts.add("Aflevering ${item.num}")
    }
    val year = d?.year?.ifEmpty { null } ?: item.year
    if (year.isNotEmpty()) parts.add(year)
    val rating = (d?.rating?.ifEmpty { null } ?: item.rating).toDoubleOrNull()
    if (rating != null && rating > 0) parts.add("★ " + String.format(java.util.Locale.US, "%.1f", rating))
    val genre = d?.genre ?: ""
    if (genre.isNotEmpty()) parts.add(genre)
    val dur = d?.duration ?: ""
    if (dur.isNotEmpty()) parts.add(dur)
    return parts.joinToString("   •   ")
}
