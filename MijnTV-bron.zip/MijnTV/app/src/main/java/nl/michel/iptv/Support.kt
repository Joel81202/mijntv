package nl.michel.iptv

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

/** Achtergrondwerk met resultaat terug op de UI-thread. */
object Bg {
    private val pool = Executors.newFixedThreadPool(4)
    private val main = Handler(Looper.getMainLooper())

    fun <T> go(work: () -> T, done: (Result<T>) -> Unit) {
        pool.execute {
            val r = runCatching(work)
            main.post { done(r) }
        }
    }
}

fun Item.toJson(): JSONObject = JSONObject()
    .put("id", id).put("name", name).put("icon", icon).put("cat", categoryId)
    .put("type", type.name).put("ext", ext).put("plot", plot).put("rating", rating)
    .put("year", year).put("backdrop", backdrop).put("num", num).put("epg", epg).put("tmdb", tmdb).put("src", src).put("archive", archive)

fun itemFromJson(o: JSONObject): Item? = try {
    Item(
        o.s("id"), o.s("name"), o.s("icon"), o.s("cat"), Type.valueOf(o.s("type")), o.s("ext"),
        plot = o.s("plot"), rating = o.s("rating"), year = o.s("year"), backdrop = o.s("backdrop"),
        num = o.s("num"), epg = o.s("epg"), tmdb = o.s("tmdb"), src = o.s("src"),
        archive = o.optInt("archive", 0)
    )
} catch (e: Exception) {
    null
}

/** Opgeslagen login, instellingen, favorieten en kijkvoortgang. */
data class Profile(val id: String, val name: String, val server: String, val user: String, val pass: String, val kind: String = "xtream")

class Prefs(private val ctx: Context) {
    /** Opslag van het actieve gebruikersprofiel. */
    private val p = ctx.getSharedPreferences(UserProfiles.file(ctx), Context.MODE_PRIVATE)

    /** Alle gegevens (favorieten, voortgang…) staan nu samen; sleutels bevatten de provider. */
    private val d: android.content.SharedPreferences get() = p

    var activeId: String
        get() = p.getString("active", "") ?: ""
        private set(v) { p.edit().putString("active", v).apply() }

    // ----- Providers -----

    fun profiles(): List<Profile> {
        val raw = p.getString("profiles", null)
        if (raw == null) {
            // Eerste keer: huidige login wordt provider 1
            if (server.isEmpty()) return emptyList()
            val first = Profile("", "Provider 1", server, user, pass)
            saveProfiles(listOf(first))
            return listOf(first)
        }
        return runCatching {
            JSONArray(raw).objects().map {
                Profile(it.s("id"), it.s("name"), it.s("server"), it.s("user"), it.s("pass"), it.s("kind").ifEmpty { "xtream" })
            }
        }.getOrDefault(emptyList())
    }

    private fun saveProfiles(list: List<Profile>) {
        val arr = JSONArray()
        for (pr in list) arr.put(
            JSONObject().put("id", pr.id).put("name", pr.name).put("server", pr.server).put("user", pr.user)
                .put("pass", pr.pass).put("kind", pr.kind)
        )
        p.edit().putString("profiles", arr.toString()).apply()
    }

    fun activeProfile(): Profile? = profiles().firstOrNull { it.id == activeId }

    /** Nieuwe provider opslaan en meteen actief maken. */
    fun addProfile(name: String, server: String, user: String, pass: String, kind: String = "xtream"): Profile {
        val list = profiles().toMutableList()
        val id = if (list.isEmpty()) "" else System.currentTimeMillis().toString()
        val def = if (kind == "enigma2") "Vu+" else "Provider ${list.size + 1}"
        val pr = Profile(id, name.ifBlank { def }, server, user, pass, kind)
        list.add(pr)
        saveProfiles(list)
        switchTo(pr)
        return pr
    }

    fun switchTo(pr: Profile) {
        activeId = pr.id
        p.edit().putString("server", pr.server).putString("user", pr.user).putString("pass", pr.pass)
            .putString("kind", pr.kind).apply()
    }

    fun renameProfile(id: String, name: String) {
        if (name.isBlank()) return
        saveProfiles(profiles().map { if (it.id == id) it.copy(name = name.trim()) else it })
    }

    fun removeProfile(id: String) {
        val list = profiles().filter { it.id != id }
        saveProfiles(list)
        list.firstOrNull()?.let { switchTo(it) } ?: run {
            p.edit().remove("server").remove("user").remove("pass").putString("active", "").apply()
        }
    }

    fun renameActiveProfile(name: String) {
        if (name.isBlank()) return
        saveProfiles(profiles().map { if (it.id == activeId) it.copy(name = name.trim()) else it })
    }

    /** Huidige provider verwijderen; geeft de volgende terug (of null als er geen meer is). */
    fun removeActiveProfile(): Profile? {
        val list = profiles().filter { it.id != activeId }
        saveProfiles(list)
        val next = list.firstOrNull()
        if (next != null) switchTo(next) else {
            p.edit().remove("server").remove("user").remove("pass").putString("active", "").apply()
        }
        return next
    }

    var server: String
        get() = p.getString("server", "") ?: ""
        set(v) { p.edit().putString("server", v).apply() }

    var user: String
        get() = p.getString("user", "") ?: ""
        set(v) { p.edit().putString("user", v).apply() }

    var pass: String
        get() = p.getString("pass", "") ?: ""
        set(v) { p.edit().putString("pass", v).apply() }

    var hls: Boolean
        get() = d.getBoolean("hls", false)
        set(v) { d.edit().putBoolean("hls", v).apply() }

    var tmdbKey: String
        get() = p.getString("tmdbkey", "") ?: ""
        set(v) { p.edit().putString("tmdbkey", v.trim()).apply() }

    var subsOn: Boolean
        get() = p.getBoolean("subs", true)
        set(v) { p.edit().putBoolean("subs", v).apply() }

    /** Ondertitels bij live tv (standaard uit). */
    var subsLive: Boolean
        get() = p.getBoolean("subslive", false)
        set(v) { p.edit().putBoolean("subslive", v).apply() }

    /** Tunneling: beeld rechtstreeks naar de beeldverwerking van de tv (beter beeld bij live tv). */
    /** Speler voor live tv: 0 = automatisch (VLC voor Vu+), 1 = altijd ExoPlayer, 2 = altijd VLC. */
    var liveEngine: Int
        get() = p.getInt("liveengine", 0)
        set(v) { p.edit().putInt("liveengine", v).apply() }

    /** Geluidsvertraging bij VLC in ms (negatief = geluid eerder), zoals in DreamPlayer. */
    var vlcAudioDelay: Int
        get() = p.getInt("vlcdelay", -125)
        set(v) { p.edit().putInt("vlcdelay", v).apply() }

    /** Beeldvullend bij films/series: 0 = passend (zwarte balken), 1 = inzoomen, 2 = uitrekken. */
    var vodResize: Int
        get() = p.getInt("vodresize", 0)
        set(v) { p.edit().putInt("vodresize", v).apply() }

    /** Laatst gekozen provider (of ★ Favorieten) in het live-scherm. */
    var liveSrc: String
        get() = p.getString("livesrc", "") ?: ""
        set(v) { p.edit().putString("livesrc", v).apply() }

    var tunneling: Boolean
        get() = p.getBoolean("tunneling", true)
        set(v) { p.edit().putBoolean("tunneling", v).apply() }

    /** 0 = klein, 1 = normaal, 2 = groot */
    var subsSize: Int
        get() = p.getInt("subssize", 1)
        set(v) { p.edit().putInt("subssize", v).apply() }

    var serverTz: String
        get() = d.getString("servertz", "") ?: ""
        set(v) { d.edit().putString("servertz", v).apply() }

    fun serverTzFor(src: String): String = p.getString("servertz:$src", "") ?: ""
    fun setServerTzFor(src: String, tz: String) { p.edit().putString("servertz:$src", tz).apply() }

    var traktId: String
        get() = p.getString("traktid", "") ?: ""
        set(v) { p.edit().putString("traktid", v.trim()).apply() }

    var traktSecret: String
        get() = p.getString("traktsecret", "") ?: ""
        set(v) { p.edit().putString("traktsecret", v.trim()).apply() }

    var traktToken: String
        get() = p.getString("trakttoken", "") ?: ""
        set(v) { p.edit().putString("trakttoken", v).apply() }

    var traktRefresh: String
        get() = p.getString("traktrefresh", "") ?: ""
        set(v) { p.edit().putString("traktrefresh", v).apply() }

    var osKey: String
        get() = p.getString("oskey", "") ?: ""
        set(v) { p.edit().putString("oskey", v.trim()).apply() }

    var osUser: String
        get() = p.getString("osuser", "") ?: ""
        set(v) { p.edit().putString("osuser", v.trim()).apply() }

    var osPass: String
        get() = p.getString("ospass", "") ?: ""
        set(v) { p.edit().putString("ospass", v).apply() }

    /** Gekozen externe ondertitel per film/aflevering: "pad|taal". */
    fun subFile(key: String): String = d.getString("sub:$key", "") ?: ""

    fun setSubFile(key: String, value: String) {
        if (value.isEmpty()) d.edit().remove("sub:$key").apply() else d.edit().putString("sub:$key", value).apply()
    }

    var kind: String
        get() = p.getString("kind", "xtream") ?: "xtream"
        set(v) { p.edit().putString("kind", v).apply() }

    fun hasLogin(): Boolean = profiles().isNotEmpty()

    fun logout() {
        p.edit().remove("server").remove("user").remove("pass").apply()
    }

    // ----- Mijn lijst -----

    /** Verborgen groepen per provider: "live:<id>", "vod:<id>", "series:<id>". */
    fun hiddenGroups(): Set<String> = HashSet(d.getStringSet("hidden", emptySet()) ?: emptySet())

    fun setHiddenGroups(set: Set<String>) {
        d.edit().putStringSet("hidden", HashSet(set)).apply()
    }

    /** Welke provider je nu bekijkt. */
    var currentSrc: String
        get() = p.getString("cursrc", null) ?: (profiles().firstOrNull()?.id ?: "")
        set(v) { p.edit().putString("cursrc", v).apply() }

    /** Favoriete groepen (komen bovenaan): "live:<id>", "vod:<id>", "series:<id>". */
    fun pinnedGroups(): Set<String> = HashSet(p.getStringSet("pinned", emptySet()) ?: emptySet())

    fun setPinnedGroups(set: Set<String>) {
        p.edit().putStringSet("pinned", HashSet(set)).apply()
    }

    /** Eigen volgorde van groepen: kind = "live", "vod" of "series". */
    fun groupOrder(kind: String): List<String> = runCatching {
        JSONArray(p.getString("order:$kind", "[]")).let { a -> (0 until a.length()).map { a.optString(it) } }
    }.getOrDefault(emptyList())

    fun setGroupOrder(kind: String, ids: List<String>) {
        val a = JSONArray(); ids.forEach { a.put(it) }
        p.edit().putString("order:$kind", a.toString()).apply()
    }

    /** Sortering binnen categorieën van films/series: 0 = standaard, 1 = nieuwst eerst, 2 = A-Z. */
    var itemSort: Int
        get() = p.getInt("itemsort", 0)
        set(v) { p.edit().putInt("itemsort", v).apply() }

    fun favorites(): Set<String> = HashSet(d.getStringSet("favs", emptySet()) ?: emptySet())

    fun isFav(key: String): Boolean = favorites().contains(key)

    /** Geeft true terug als het item nu in Mijn lijst staat. */
    fun toggleFav(key: String): Boolean {
        val set = HashSet(favorites())
        val added = if (set.contains(key)) {
            set.remove(key); false
        } else {
            set.add(key); true
        }
        d.edit().putStringSet("favs", set).apply()
        return added
    }

    // ----- Verder kijken -----

    fun getPos(key: String): Long = d.getLong("pos:$key", 0L)

    fun getProgress(key: String): Int = d.getInt("pct:$key", 0)

    fun savePos(key: String, ms: Long, percent: Int) {
        d.edit().putLong("pos:$key", ms).putInt("pct:$key", percent).apply()
    }

    fun clearPos(key: String) {
        d.edit().remove("pos:$key").remove("pct:$key").apply()
    }

    var lastChannel: String
        get() = d.getString("lastch", "") ?: ""
        set(v) { d.edit().putString("lastch", v).apply() }

    var lastChannelSrc: String
        get() = p.getString("lastchsrc", "") ?: ""
        set(v) { p.edit().putString("lastchsrc", v).apply() }

    /** 0 = Home, 1 = Live TV, 2 = laatste zender meteen afspelen */
    var startMode: Int
        get() = p.getInt("startmode", 0)
        set(v) { p.edit().putInt("startmode", v).apply() }

    var autoStart: Boolean
        get() = p.getBoolean("autostart", false)
        set(v) { p.edit().putBoolean("autostart", v).apply() }

    var lastGroup: String
        get() = d.getString("lastgroup", "*") ?: "*"
        set(v) { d.edit().putString("lastgroup", v).apply() }

    fun lastEpisode(seriesId: String): String = d.getString("lastep:$seriesId", "") ?: ""

    fun setLastEpisode(seriesId: String, episodeId: String) {
        d.edit().putString("lastep:$seriesId", episodeId).apply()
    }

    fun recents(): List<Item> {
        val arr = try {
            JSONArray(d.getString("recents", "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }
        return arr.objects().mapNotNull { itemFromJson(it) }
    }

    fun addRecent(item: Item) {
        if (hiddenContinue().contains(item.favKey)) hideContinue(item.favKey, false)
        val list = recents().filter { it.favKey != item.favKey }.toMutableList()
        list.add(0, item)
        saveRecents(list.take(25))
    }

    fun removeRecent(key: String) {
        saveRecents(recents().filter { it.favKey != key })
    }

    /** Handmatig uit "Verder kijken" gehaald (ook als Trakt hem nog meldt). */
    fun hiddenContinue(): Set<String> = d.getStringSet("hidecont", emptySet()) ?: emptySet()

    fun hideContinue(key: String, hide: Boolean) {
        val s = hiddenContinue().toMutableSet()
        if (hide) s.add(key) else s.remove(key)
        d.edit().putStringSet("hidecont", s).apply()
    }

    private fun saveRecents(list: List<Item>) {
        val arr = JSONArray()
        for (i in list) arr.put(i.toJson())
        d.edit().putString("recents", arr.toString()).apply()
    }
}

/** Groepen in de eigen volgorde; nieuwe groepen komen achteraan in de volgorde van de provider. */
fun orderCats(cats: List<Category>, order: List<String>): List<Category> {
    if (order.isEmpty()) return cats
    val pos = HashMap<String, Int>()
    order.forEachIndexed { i, id -> pos[id] = i }
    return cats.withIndex().sortedBy { (i, c) -> pos[c.id] ?: (order.size + i) }.map { it.value }
}

/** Eigen volgorde, met favoriete groepen bovenaan. */
fun arrangeCats(prefs: Prefs, kind: String, cats: List<Category>): List<Category> {
    val pins = prefs.pinnedGroups()
    return orderCats(cats, prefs.groupOrder(kind)).sortedBy { if (pins.contains("$kind:" + it.id)) 0 else 1 }
}

/** Favoriete groepen kiezen (vinkje = bovenaan). */
fun choosePinned(act: android.app.Activity, prefs: Prefs, kind: String, cats: List<Category>, done: () -> Unit) {
    if (cats.isEmpty()) return
    val pins = prefs.pinnedGroups().toMutableSet()
    val list = arrangeCats(prefs, kind, cats)
    val labels = list.map { it.name as CharSequence }.toTypedArray()
    val checked = BooleanArray(list.size) { pins.contains("$kind:" + list[it].id) }
    androidx.appcompat.app.AlertDialog.Builder(act)
        .setTitle("Favoriete groepen (komen bovenaan)")
        .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
        .setPositiveButton("Opslaan") { _, _ ->
            list.forEachIndexed { i, c -> if (checked[i]) pins.add("$kind:" + c.id) else pins.remove("$kind:" + c.id) }
            prefs.setPinnedGroups(pins)
            done()
        }
        .setNegativeButton("Annuleren", null)
        .show()
}

fun sortItems(items: List<Item>, mode: Int): List<Item> = when (mode) {
    1 -> items.sortedByDescending { it.added }
    2 -> items.sortedBy { Tmdb.cleanTitle(it.name).first.lowercase() }
    else -> items
}

/** Volgorde van groepen wijzigen met de afstandsbediening. */
fun reorderGroups(act: android.app.Activity, prefs: Prefs, kind: String, cats: List<Category>, done: () -> Unit) {
    if (cats.isEmpty()) return
    val current = arrangeCats(prefs, kind, cats).toMutableList()
    val labels = current.mapIndexed { i, c -> "${i + 1}.  ${c.name}" as CharSequence }.toTypedArray()
    androidx.appcompat.app.AlertDialog.Builder(act)
        .setTitle("Kies een groep om te verplaatsen")
        .setItems(labels) { _, which ->
            val moves = arrayOf<CharSequence>("⇈  Helemaal bovenaan", "↑  Eén plek omhoog", "↓  Eén plek omlaag", "⇊  Helemaal onderaan")
            androidx.appcompat.app.AlertDialog.Builder(act)
                .setTitle(current[which].name)
                .setItems(moves) { _, m ->
                    val c = current.removeAt(which)
                    val to = when (m) {
                        0 -> 0
                        1 -> (which - 1).coerceAtLeast(0)
                        2 -> (which + 1).coerceAtMost(current.size)
                        else -> current.size
                    }
                    current.add(to, c)
                    prefs.setGroupOrder(kind, current.map { it.id })
                    done()
                    reorderGroups(act, prefs, kind, cats, done)
                }
                .setNegativeButton("Terug", null)
                .show()
        }
        .setNeutralButton("Standaardvolgorde") { _, _ ->
            prefs.setGroupOrder(kind, emptyList())
            done()
        }
        .setNegativeButton("Klaar", null)
        .show()
}

/** Laatst bekende zenderlijst per provider, voor als een provider even niet reageert. */
object LiveCache {
    private fun file(ctx: Context, src: String) = java.io.File(ctx.filesDir, "live_${src.ifEmpty { "main" }}.json")

    fun save(ctx: Context, src: String, cats: List<Category>, items: List<Item>) = runCatching {
        val o = JSONObject()
        val ca = JSONArray(); cats.forEach { ca.put(JSONObject().put("id", it.id).put("name", it.name)) }
        val ia = JSONArray(); items.forEach { ia.put(it.toJson()) }
        o.put("cats", ca).put("items", ia)
        file(ctx, src).writeText(o.toString())
    }

    fun load(ctx: Context, src: String): Pair<List<Category>, List<Item>>? = runCatching {
        val f = file(ctx, src)
        if (!f.exists()) return null
        val o = JSONObject(f.readText())
        val cats = o.optJSONArray("cats")?.objects()?.map { Category(it.s("id"), it.s("name")) }.orEmpty()
        val items = o.optJSONArray("items")?.objects()?.mapNotNull { itemFromJson(it) }.orEmpty()
        if (items.isEmpty()) null else Pair(cats, items)
    }.getOrNull()
}

/** In-memory cache van alles wat van de server komt. */
object Repo {
    /** Eerste provider (voor algemene controles). */
    var api: Xtream? = null
    /** Alle providers tegelijk, op provider-id. */
    val apis = LinkedHashMap<String, Xtream>()
    /** Providernamen, voor labels als "Vu+ · Favourites". */
    val names = HashMap<String, String>()

    /** Provider die je nu bekijkt, en bij welke provider elke categorie hoort. */
    var current: String = ""
    val catSrc = HashMap<String, String>()

    fun isCurrent(item: Item) = item.src == current
    fun isCurrentCat(c: Category) = (catSrc[c.id] ?: "") == current
    fun currentApi(): Xtream? = apis[current] ?: api
    fun currentName(): String = names[current] ?: "Provider"

    fun apiFor(item: Item): Xtream? = apis[item.src] ?: api
    fun apiFor(src: String): Xtream? = apis[src] ?: api

    var liveCats: List<Category> = emptyList()
    var vodCats: List<Category> = emptyList()
    var seriesCats: List<Category> = emptyList()
    var live: List<Item> = emptyList()
    var vod: List<Item> = emptyList()
    var series: List<Item> = emptyList()
    var liveByCat: Map<String, List<Item>> = emptyMap()
    var vodByCat: Map<String, List<Item>> = emptyMap()
    var seriesByCat: Map<String, List<Item>> = emptyMap()
    val details = HashMap<String, Details>()
    var autoLiveDone = false
    var traktRows: List<Row> = emptyList()
    var liveLoaded = false
    var restLoaded = false
    var historyChanged = false

    private var index: Map<String, Item>? = null

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    /** Zoek een TMDB-titel in je eigen films/series. */
    fun libraryMatch(type: Type, tmdbId: String, titles: List<String>, year: String): Item? {
        if (!restLoaded) return null
        // Index wordt op de achtergrond gebouwd (duurt even bij grote bibliotheken); tot dan geen match
        val idx = index ?: run { buildIndexAsync(); return null }
        idx["id:${type.name}:$tmdbId"]?.let { return it }
        for (t in titles) {
            val n = norm(t)
            if (n.isNotEmpty() && year.isNotEmpty()) idx["t:${type.name}:$n:$year"]?.let { return it }
        }
        for (t in titles) {
            val n = norm(t)
            if (n.isNotEmpty()) idx["t:${type.name}:$n:"]?.let { return it }
        }
        return null
    }

    @Volatile private var indexing = false
    /** Wordt aangeroepen als de index klaar is (bijv. om Verder kijken te verversen). */
    var onIndexReady: (() -> Unit)? = null

    fun buildIndexAsync() {
        if (index != null || indexing || !restLoaded) return
        indexing = true
        Bg.go({ buildIndex() }) { r ->
            indexing = false
            r.getOrNull()?.let { index = it; onIndexReady?.invoke() }
        }
    }

    private fun buildIndex(): Map<String, Item> {
        val m = HashMap<String, Item>()
        for (item in vod.asSequence() + series.asSequence()) {
            if (item.tmdb.isNotEmpty() && item.tmdb != "0") m.putIfAbsent("id:${item.type.name}:${item.tmdb}", item)
            val (clean, y) = Tmdb.cleanTitle(item.name)
            val n = norm(clean)
            if (n.isEmpty()) continue
            val year = item.year.ifEmpty { y }
            if (year.isNotEmpty()) m.putIfAbsent("t:${item.type.name}:$n:$year", item)
            m.putIfAbsent("t:${item.type.name}:$n:", item)
        }
        return m
    }

    fun clear() {
        index = null
        liveCats = emptyList(); vodCats = emptyList(); seriesCats = emptyList()
        live = emptyList(); vod = emptyList(); series = emptyList()
        liveByCat = emptyMap(); vodByCat = emptyMap(); seriesByCat = emptyMap()
        details.clear()
        liveLoaded = false; restLoaded = false
    }

    fun ensureApi(ctx: Context): Boolean {
        if (api != null && apis.isNotEmpty()) return true
        val prefs = Prefs(ctx)
        val list = prefs.profiles()
        if (list.isEmpty()) return false
        apis.clear(); names.clear()
        for (pr in list) {
            apis[pr.id] = Xtream(pr.server, pr.user, pr.pass, pr.kind, pr.id).also { it.serverTz = prefs.serverTzFor(pr.id) }
            names[pr.id] = pr.name
        }
        api = apis.values.first()
        current = prefs.currentSrc.takeIf { apis.containsKey(it) } ?: apis.keys.first()
        return true
    }

    fun reset() {
        clear()
        catSrc.clear()
        apis.clear(); names.clear()
        api = null
        autoLiveDone = false
    }
}

/** Afspeellijst voor de speler (zappen / volgende aflevering). */
object PlayQueue {
    var items: List<Item> = emptyList()
    var index = 0
    var parent: Item? = null

    fun set(list: List<Item>, item: Item, parentItem: Item? = null) {
        parent = parentItem
        val i = list.indexOf(item)
        if (i >= 0) {
            items = list; index = i
        } else {
            items = listOf(item); index = 0
        }
    }

    fun current(): Item? = items.getOrNull(index)
}

/** Kaart vergroten bij focus, zoals op een tv-streamingdienst. */
fun View.focusZoom(hasFocus: Boolean, scale: Float = 1.08f) {
    val s = if (hasFocus) scale else 1f
    animate().scaleX(s).scaleY(s).translationZ(if (hasFocus) 12f else 0f)
        .setDuration(if (hasFocus) 220 else 160)
        .setInterpolator(android.view.animation.DecelerateInterpolator(1.6f))
        .start()
}

/** Afgeronde hoeken: het plaatje wordt afgesneden langs de achtergrondvorm. */
fun View.roundClip() {
    clipToOutline = true
}

/** Horizontale rij met kaarten. Het kaarttype volgt uit het soort item. */
class CardAdapter(
    private val prefs: Prefs,
    private val onClick: (Item, List<Item>) -> Unit,
    private val onLongClick: (Item) -> Unit,
    private val onFocus: (Item) -> Unit
) : RecyclerView.Adapter<CardAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.cardImage)
        val fallback: TextView = v.findViewById(R.id.cardFallback)
        val title: TextView? = v.findViewById(R.id.cardTitle)
        val overlay: TextView? = v.findViewById(R.id.cardOverlay)
        val progress: ProgressBar? = v.findViewById(R.id.cardProgress)
        val badge: View? = v.findViewById(R.id.cardBadge)

        init {
            (v.findViewById<View>(R.id.cardFrame) ?: v).roundClip()
        }
    }

    /** Brede kaarten (zoals "Verder kijken" bij Netflix). */
    var wide = false

    /** Voortgang van de laatst bekeken aflevering van een serie. */
    private fun seriesProgress(series: Item): Int {
        val ep = prefs.lastEpisode(series.id)
        if (ep.isEmpty()) return 0
        val key = if (series.src.isEmpty()) "EPISODE:$ep" else "EPISODE:${series.src}:$ep"
        return prefs.getProgress(key)
    }

    var items: List<Item> = emptyList()
        private set

    fun submit(list: List<Item>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = items.size

    override fun getItemViewType(position: Int): Int =
        if (wide && items[position].type != Type.LIVE) 100 else items[position].type.ordinal

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = if (viewType == 100) R.layout.card_wide else when (Type.values()[viewType]) {
            Type.LIVE -> R.layout.card_live
            Type.EPISODE -> R.layout.card_episode
            else -> R.layout.card_poster
        }
        return VH(LayoutInflater.from(parent.context).inflate(layout, parent, false))
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        val star = if (prefs.isFav(item.favKey)) "★ " else ""
        h.fallback.text = if (item.type == Type.EPISODE) item.num else item.name
        h.title?.text = when (item.type) {
            Type.EPISODE -> "${item.num}. ${item.name}"
            else -> star + item.name
        }
        val meta = Tmdb.cached(item)
        val tmdbPoster = meta?.poster ?: ""
        val isWide = getItemViewType(position) == 100
        val url = if (isWide) (meta?.backdrop ?: "").ifEmpty { item.backdrop }.ifEmpty { tmdbPoster }.ifEmpty { item.icon }
        else tmdbPoster.ifEmpty { item.icon }
        h.overlay?.text = meta?.title?.ifEmpty { null } ?: item.name
        if (url.isNotEmpty()) {
            Glide.with(h.img).load(url).into(h.img)
        } else {
            Glide.with(h.img).clear(h.img)
            h.img.setImageDrawable(null)
        }
        h.badge?.visibility = if (TraktSync.isMovieWatched(item)) View.VISIBLE else View.GONE
        h.itemView.alpha = if (item.id.isEmpty()) 0.45f else 1f
        if (Tmdb.enabled && (item.id.isNotEmpty() || item.icon.isEmpty()) && (item.type == Type.MOVIE || item.type == Type.SERIES) && !Tmdb.known(item)) {
            Tmdb.lookup(item) { m ->
                if (m == null || items.getOrNull(h.bindingAdapterPosition) != item) return@lookup
                val img = if (isWide) m.backdrop.ifEmpty { m.poster } else m.poster
                if (img.isNotEmpty()) Glide.with(h.img).load(img).into(h.img)
                if (m.title.isNotEmpty()) h.overlay?.text = m.title
            }
        }
        h.progress?.let { bar ->
            var pct = if (item.type == Type.SERIES) seriesProgress(item) else prefs.getProgress(item.favKey)
            if (pct == 0 && item.type == Type.MOVIE) pct = TraktSync.progressFor(item, null).toInt()
            bar.visibility = if (pct > 0) View.VISIBLE else View.GONE
            bar.progress = pct
        }
        h.itemView.scaleX = 1f
        h.itemView.scaleY = 1f
        h.itemView.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(items[p], items)
        }
        h.itemView.setOnLongClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) {
                onLongClick(items[p])
                h.itemView.post { if (p < itemCount) notifyItemChanged(p) }
            }
            true
        }
        h.itemView.setOnFocusChangeListener { v, hasFocus ->
            v.focusZoom(hasFocus)
            if (items.getOrNull(h.bindingAdapterPosition)?.id?.isEmpty() == true) v.alpha = if (hasFocus) 1f else 0.45f
            val p = h.bindingAdapterPosition
            if (hasFocus && p != RecyclerView.NO_POSITION) onFocus(items[p])
        }
    }
}

data class Row(val title: String, val items: List<Item>, val wide: Boolean = false)

/** Verticale lijst van rijen ("Verder kijken", "Nieuwe films", categorieën…). */
class RowsAdapter(
    private val prefs: Prefs,
    private val onClick: (Item, List<Item>) -> Unit,
    private val onLongClick: (Item) -> Unit,
    private val onFocus: (Item) -> Unit
) : RecyclerView.Adapter<RowsAdapter.VH>() {

    private val pool = RecyclerView.RecycledViewPool()

    class VH(v: View, val cards: CardAdapter) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.sectionTitle)
        val list: RecyclerView = v.findViewById(R.id.sectionList)
    }

    var rows: List<Row> = emptyList()
        private set

    fun submit(list: List<Row>) {
        rows = list
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = rows.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_section, parent, false)
        val cards = CardAdapter(prefs, onClick, onLongClick, onFocus)
        val vh = VH(v, cards)
        vh.list.layoutManager = LinearLayoutManager(parent.context, LinearLayoutManager.HORIZONTAL, false)
        vh.list.setRecycledViewPool(pool)
        vh.list.adapter = cards
        return vh
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val row = rows[position]
        h.title.text = row.title
        h.cards.wide = row.wide
        h.cards.submit(row.items)
        h.list.scrollToPosition(0)
    }
}

/** Kleine knopjes, bijvoorbeeld voor seizoenen. */
class ChipAdapter(
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<ChipAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val text: TextView = v.findViewById(R.id.chipText)
    }

    private var labels: List<String> = emptyList()
    private var sel = 0

    fun submit(list: List<String>, selected: Int) {
        labels = list
        sel = selected
        notifyDataSetChanged()
    }

    fun select(i: Int) {
        val old = sel
        sel = i
        notifyItemChanged(old)
        notifyItemChanged(i)
    }

    override fun getItemCount(): Int = labels.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_chip, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        h.text.text = labels[position]
        h.itemView.isActivated = position == sel
        h.itemView.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(p)
        }
    }
}

fun metaLine(item: Item, d: Details? = null): String {
    val parts = ArrayList<String>()
    when (item.type) {
        Type.LIVE -> parts.add("LIVE")
        Type.MOVIE -> parts.add("Film")
        Type.SERIES -> parts.add("Serie")
        Type.EPISODE -> parts.add("Aflevering ${item.num}")
        Type.CATCHUP -> parts.add("Terugkijken")
    }
    val year = d?.year?.ifEmpty { null } ?: item.year
    if (year.isNotEmpty()) parts.add(year)
    val rating = (d?.rating?.ifEmpty { null } ?: item.rating).toDoubleOrNull()
    if (rating != null && rating > 0) parts.add("★ " + String.format(java.util.Locale.US, "%.1f", rating))
    val genre = d?.genre ?: ""
    if (genre.isNotEmpty()) parts.add(genre)
    val dur = d?.duration ?: ""
    if (dur.isNotEmpty()) parts.add(dur)
    return parts.joinToString("   •   ")
}
