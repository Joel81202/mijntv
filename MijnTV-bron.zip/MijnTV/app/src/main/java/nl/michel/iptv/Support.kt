package nl.michel.iptv

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

/** Achtergrondwerk met resultaat terug op de UI-thread. */
object Bg {
    private val pool = Executors.newFixedThreadPool(4)
    private val main = Handler(Looper.getMainLooper())

    fun <T> go(work: () -> T, done: (Result<T>) -> Unit) {
        pool.execute {
            val r = runCatching(work)
            main.post { done(r) }
        }
    }
}

fun Item.toJson(): JSONObject = JSONObject()
    .put("id", id).put("name", name).put("icon", icon).put("cat", categoryId)
    .put("type", type.name).put("ext", ext).put("plot", plot).put("rating", rating)
    .put("year", year).put("backdrop", backdrop).put("num", num).put("epg", epg).put("tmdb", tmdb)

fun itemFromJson(o: JSONObject): Item? = try {
    Item(
        o.s("id"), o.s("name"), o.s("icon"), o.s("cat"), Type.valueOf(o.s("type")), o.s("ext"),
        plot = o.s("plot"), rating = o.s("rating"), year = o.s("year"), backdrop = o.s("backdrop"),
        num = o.s("num"), epg = o.s("epg"), tmdb = o.s("tmdb")
    )
} catch (e: Exception) {
    null
}

/** Opgeslagen login, instellingen, favorieten en kijkvoortgang. */
data class Profile(val id: String, val name: String, val server: String, val user: String, val pass: String)

class Prefs(private val ctx: Context) {
    private val p = ctx.getSharedPreferences("mijntv", Context.MODE_PRIVATE)

    /** Gegevens per provider (favorieten, voortgang, laatste zender…). De eerste provider gebruikt het oude bestand. */
    private val d: android.content.SharedPreferences
        get() {
            val id = activeId
            return if (id.isEmpty()) p else ctx.getSharedPreferences("mijntv_p_$id", Context.MODE_PRIVATE)
        }

    var activeId: String
        get() = p.getString("active", "") ?: ""
        private set(v) { p.edit().putString("active", v).apply() }

    // ----- Providers -----

    fun profiles(): List<Profile> {
        val raw = p.getString("profiles", null)
        if (raw == null) {
            // Eerste keer: huidige login wordt provider 1
            if (server.isEmpty()) return emptyList()
            val first = Profile("", "Provider 1", server, user, pass)
            saveProfiles(listOf(first))
            return listOf(first)
        }
        return runCatching {
            JSONArray(raw).objects().map { Profile(it.s("id"), it.s("name"), it.s("server"), it.s("user"), it.s("pass")) }
        }.getOrDefault(emptyList())
    }

    private fun saveProfiles(list: List<Profile>) {
        val arr = JSONArray()
        for (pr in list) arr.put(
            JSONObject().put("id", pr.id).put("name", pr.name).put("server", pr.server).put("user", pr.user).put("pass", pr.pass)
        )
        p.edit().putString("profiles", arr.toString()).apply()
    }

    fun activeProfile(): Profile? = profiles().firstOrNull { it.id == activeId }

    /** Nieuwe provider opslaan en meteen actief maken. */
    fun addProfile(name: String, server: String, user: String, pass: String): Profile {
        val list = profiles().toMutableList()
        val id = if (list.isEmpty()) "" else System.currentTimeMillis().toString()
        val pr = Profile(id, name.ifBlank { "Provider ${list.size + 1}" }, server, user, pass)
        list.add(pr)
        saveProfiles(list)
        switchTo(pr)
        return pr
    }

    fun switchTo(pr: Profile) {
        activeId = pr.id
        p.edit().putString("server", pr.server).putString("user", pr.user).putString("pass", pr.pass).apply()
    }

    fun renameActiveProfile(name: String) {
        if (name.isBlank()) return
        saveProfiles(profiles().map { if (it.id == activeId) it.copy(name = name.trim()) else it })
    }

    /** Huidige provider verwijderen; geeft de volgende terug (of null als er geen meer is). */
    fun removeActiveProfile(): Profile? {
        val list = profiles().filter { it.id != activeId }
        saveProfiles(list)
        val next = list.firstOrNull()
        if (next != null) switchTo(next) else {
            p.edit().remove("server").remove("user").remove("pass").putString("active", "").apply()
        }
        return next
    }

    var server: String
        get() = p.getString("server", "") ?: ""
        set(v) { p.edit().putString("server", v).apply() }

    var user: String
        get() = p.getString("user", "") ?: ""
        set(v) { p.edit().putString("user", v).apply() }

    var pass: String
        get() = p.getString("pass", "") ?: ""
        set(v) { p.edit().putString("pass", v).apply() }

    var hls: Boolean
        get() = d.getBoolean("hls", false)
        set(v) { d.edit().putBoolean("hls", v).apply() }

    var tmdbKey: String
        get() = p.getString("tmdbkey", "") ?: ""
        set(v) { p.edit().putString("tmdbkey", v.trim()).apply() }

    var subsOn: Boolean
        get() = p.getBoolean("subs", true)
        set(v) { p.edit().putBoolean("subs", v).apply() }

    /** 0 = klein, 1 = normaal, 2 = groot */
    var subsSize: Int
        get() = p.getInt("subssize", 1)
        set(v) { p.edit().putInt("subssize", v).apply() }

    var serverTz: String
        get() = d.getString("servertz", "") ?: ""
        set(v) { d.edit().putString("servertz", v).apply() }

    var traktId: String
        get() = p.getString("traktid", "") ?: ""
        set(v) { p.edit().putString("traktid", v.trim()).apply() }

    var traktSecret: String
        get() = p.getString("traktsecret", "") ?: ""
        set(v) { p.edit().putString("traktsecret", v.trim()).apply() }

    var traktToken: String
        get() = p.getString("trakttoken", "") ?: ""
        set(v) { p.edit().putString("trakttoken", v).apply() }

    var traktRefresh: String
        get() = p.getString("traktrefresh", "") ?: ""
        set(v) { p.edit().putString("traktrefresh", v).apply() }

    var osKey: String
        get() = p.getString("oskey", "") ?: ""
        set(v) { p.edit().putString("oskey", v.trim()).apply() }

    var osUser: String
        get() = p.getString("osuser", "") ?: ""
        set(v) { p.edit().putString("osuser", v.trim()).apply() }

    var osPass: String
        get() = p.getString("ospass", "") ?: ""
        set(v) { p.edit().putString("ospass", v).apply() }

    /** Gekozen externe ondertitel per film/aflevering: "pad|taal". */
    fun subFile(key: String): String = d.getString("sub:$key", "") ?: ""

    fun setSubFile(key: String, value: String) {
        if (value.isEmpty()) d.edit().remove("sub:$key").apply() else d.edit().putString("sub:$key", value).apply()
    }

    fun hasLogin(): Boolean = server.isNotEmpty() && user.isNotEmpty()

    fun logout() {
        p.edit().remove("server").remove("user").remove("pass").apply()
    }

    // ----- Mijn lijst -----

    fun favorites(): Set<String> = HashSet(d.getStringSet("favs", emptySet()) ?: emptySet())

    fun isFav(key: String): Boolean = favorites().contains(key)

    /** Geeft true terug als het item nu in Mijn lijst staat. */
    fun toggleFav(key: String): Boolean {
        val set = HashSet(favorites())
        val added = if (set.contains(key)) {
            set.remove(key); false
        } else {
            set.add(key); true
        }
        d.edit().putStringSet("favs", set).apply()
        return added
    }

    // ----- Verder kijken -----

    fun getPos(key: String): Long = d.getLong("pos:$key", 0L)

    fun getProgress(key: String): Int = d.getInt("pct:$key", 0)

    fun savePos(key: String, ms: Long, percent: Int) {
        d.edit().putLong("pos:$key", ms).putInt("pct:$key", percent).apply()
    }

    fun clearPos(key: String) {
        d.edit().remove("pos:$key").remove("pct:$key").apply()
    }

    var lastChannel: String
        get() = d.getString("lastch", "") ?: ""
        set(v) { d.edit().putString("lastch", v).apply() }

    var lastGroup: String
        get() = d.getString("lastgroup", "*") ?: "*"
        set(v) { d.edit().putString("lastgroup", v).apply() }

    fun lastEpisode(seriesId: String): String = d.getString("lastep:$seriesId", "") ?: ""

    fun setLastEpisode(seriesId: String, episodeId: String) {
        d.edit().putString("lastep:$seriesId", episodeId).apply()
    }

    fun recents(): List<Item> {
        val arr = try {
            JSONArray(d.getString("recents", "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }
        return arr.objects().mapNotNull { itemFromJson(it) }
    }

    fun addRecent(item: Item) {
        val list = recents().filter { it.favKey != item.favKey }.toMutableList()
        list.add(0, item)
        saveRecents(list.take(25))
    }

    fun removeRecent(key: String) {
        saveRecents(recents().filter { it.favKey != key })
    }

    private fun saveRecents(list: List<Item>) {
        val arr = JSONArray()
        for (i in list) arr.put(i.toJson())
        d.edit().putString("recents", arr.toString()).apply()
    }
}

/** In-memory cache van alles wat van de server komt. */
object Repo {
    var api: Xtream? = null
    var liveCats: List<Category> = emptyList()
    var vodCats: List<Category> = emptyList()
    var seriesCats: List<Category> = emptyList()
    var live: List<Item> = emptyList()
    var vod: List<Item> = emptyList()
    var series: List<Item> = emptyList()
    var liveByCat: Map<String, List<Item>> = emptyMap()
    var vodByCat: Map<String, List<Item>> = emptyMap()
    var seriesByCat: Map<String, List<Item>> = emptyMap()
    val details = HashMap<String, Details>()
    var traktRows: List<Row> = emptyList()
    var liveLoaded = false
    var restLoaded = false
    var historyChanged = false

    private var index: Map<String, Item>? = null

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    /** Zoek een TMDB-titel in je eigen films/series. */
    @Synchronized
    fun libraryMatch(type: Type, tmdbId: String, titles: List<String>, year: String): Item? {
        if (!restLoaded) return null
        val idx = index ?: buildIndex().also { index = it }
        idx["id:${type.name}:$tmdbId"]?.let { return it }
        for (t in titles) {
            val n = norm(t)
            if (n.isNotEmpty() && year.isNotEmpty()) idx["t:${type.name}:$n:$year"]?.let { return it }
        }
        for (t in titles) {
            val n = norm(t)
            if (n.isNotEmpty()) idx["t:${type.name}:$n:"]?.let { return it }
        }
        return null
    }

    private fun buildIndex(): Map<String, Item> {
        val m = HashMap<String, Item>()
        for (item in vod + series) {
            if (item.tmdb.isNotEmpty() && item.tmdb != "0") m.putIfAbsent("id:${item.type.name}:${item.tmdb}", item)
            val (clean, y) = Tmdb.cleanTitle(item.name)
            val n = norm(clean)
            if (n.isEmpty()) continue
            val year = item.year.ifEmpty { y }
            if (year.isNotEmpty()) m.putIfAbsent("t:${item.type.name}:$n:$year", item)
            m.putIfAbsent("t:${item.type.name}:$n:", item)
        }
        return m
    }

    fun clear() {
        index = null
        liveCats = emptyList(); vodCats = emptyList(); seriesCats = emptyList()
        live = emptyList(); vod = emptyList(); series = emptyList()
        liveByCat = emptyMap(); vodByCat = emptyMap(); seriesByCat = emptyMap()
        details.clear()
        liveLoaded = false; restLoaded = false
    }

    fun ensureApi(ctx: Context): Boolean {
        if (api != null) return true
        val prefs = Prefs(ctx)
        if (!prefs.hasLogin()) return false
        api = Xtream(prefs.server, prefs.user, prefs.pass).also { it.serverTz = prefs.serverTz }
        return true
    }
}

/** Afspeellijst voor de speler (zappen / volgende aflevering). */
object PlayQueue {
    var items: List<Item> = emptyList()
    var index = 0
    var parent: Item? = null

    fun set(list: List<Item>, item: Item, parentItem: Item? = null) {
        parent = parentItem
        val i = list.indexOf(item)
        if (i >= 0) {
            items = list; index = i
        } else {
            items = listOf(item); index = 0
        }
    }

    fun current(): Item? = items.getOrNull(index)
}

/** Kaart vergroten bij focus, zoals op een tv-streamingdienst. */
fun View.focusZoom(hasFocus: Boolean, scale: Float = 1.12f) {
    val s = if (hasFocus) scale else 1f
    animate().scaleX(s).scaleY(s).setDuration(150).start()
    translationZ = if (hasFocus) 10f else 0f
}

/** Horizontale rij met kaarten. Het kaarttype volgt uit het soort item. */
class CardAdapter(
    private val prefs: Prefs,
    private val onClick: (Item, List<Item>) -> Unit,
    private val onLongClick: (Item) -> Unit,
    private val onFocus: (Item) -> Unit
) : RecyclerView.Adapter<CardAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.cardImage)
        val fallback: TextView = v.findViewById(R.id.cardFallback)
        val title: TextView? = v.findViewById(R.id.cardTitle)
        val progress: ProgressBar? = v.findViewById(R.id.cardProgress)
    }

    var items: List<Item> = emptyList()
        private set

    fun submit(list: List<Item>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = items.size

    override fun getItemViewType(position: Int): Int = items[position].type.ordinal

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = when (Type.values()[viewType]) {
            Type.LIVE -> R.layout.card_live
            Type.EPISODE -> R.layout.card_episode
            else -> R.layout.card_poster
        }
        return VH(LayoutInflater.from(parent.context).inflate(layout, parent, false))
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        val star = if (prefs.isFav(item.favKey)) "★ " else ""
        h.fallback.text = if (item.type == Type.EPISODE) item.num else item.name
        h.title?.text = when (item.type) {
            Type.EPISODE -> "${item.num}. ${item.name}"
            else -> star + item.name
        }
        val tmdbPoster = Tmdb.cached(item)?.poster ?: ""
        val url = tmdbPoster.ifEmpty { item.icon }
        if (url.isNotEmpty()) {
            Glide.with(h.img).load(url).into(h.img)
        } else {
            Glide.with(h.img).clear(h.img)
            h.img.setImageDrawable(null)
        }
        h.itemView.alpha = if (item.id.isEmpty()) 0.45f else 1f
        if (Tmdb.enabled && (item.id.isNotEmpty() || item.icon.isEmpty()) && (item.type == Type.MOVIE || item.type == Type.SERIES) && !Tmdb.known(item)) {
            Tmdb.lookup(item) { m ->
                val poster = m?.poster ?: ""
                if (poster.isNotEmpty() && items.getOrNull(h.bindingAdapterPosition) == item) {
                    Glide.with(h.img).load(poster).into(h.img)
                }
            }
        }
        h.progress?.let { bar ->
            val pct = prefs.getProgress(item.favKey)
            bar.visibility = if (pct > 0) View.VISIBLE else View.GONE
            bar.progress = pct
        }
        h.itemView.scaleX = 1f
        h.itemView.scaleY = 1f
        h.itemView.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(items[p], items)
        }
        h.itemView.setOnLongClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) {
                onLongClick(items[p])
                notifyItemChanged(p)
            }
            true
        }
        h.itemView.setOnFocusChangeListener { v, hasFocus ->
            v.focusZoom(hasFocus)
            if (items.getOrNull(h.bindingAdapterPosition)?.id?.isEmpty() == true) v.alpha = if (hasFocus) 1f else 0.45f
            val p = h.bindingAdapterPosition
            if (hasFocus && p != RecyclerView.NO_POSITION) onFocus(items[p])
        }
    }
}

data class Row(val title: String, val items: List<Item>)

/** Verticale lijst van rijen ("Verder kijken", "Nieuwe films", categorieën…). */
class RowsAdapter(
    private val prefs: Prefs,
    private val onClick: (Item, List<Item>) -> Unit,
    private val onLongClick: (Item) -> Unit,
    private val onFocus: (Item) -> Unit
) : RecyclerView.Adapter<RowsAdapter.VH>() {

    private val pool = RecyclerView.RecycledViewPool()

    class VH(v: View, val cards: CardAdapter) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.sectionTitle)
        val list: RecyclerView = v.findViewById(R.id.sectionList)
    }

    var rows: List<Row> = emptyList()
        private set

    fun submit(list: List<Row>) {
        rows = list
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = rows.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_section, parent, false)
        val cards = CardAdapter(prefs, onClick, onLongClick, onFocus)
        val vh = VH(v, cards)
        vh.list.layoutManager = LinearLayoutManager(parent.context, LinearLayoutManager.HORIZONTAL, false)
        vh.list.setRecycledViewPool(pool)
        vh.list.adapter = cards
        return vh
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val row = rows[position]
        h.title.text = row.title
        h.cards.submit(row.items)
        h.list.scrollToPosition(0)
    }
}

/** Kleine knopjes, bijvoorbeeld voor seizoenen. */
class ChipAdapter(
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<ChipAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val text: TextView = v.findViewById(R.id.chipText)
    }

    private var labels: List<String> = emptyList()
    private var sel = 0

    fun submit(list: List<String>, selected: Int) {
        labels = list
        sel = selected
        notifyDataSetChanged()
    }

    fun select(i: Int) {
        val old = sel
        sel = i
        notifyItemChanged(old)
        notifyItemChanged(i)
    }

    override fun getItemCount(): Int = labels.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_chip, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        h.text.text = labels[position]
        h.itemView.isActivated = position == sel
        h.itemView.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(p)
        }
    }
}

fun metaLine(item: Item, d: Details? = null): String {
    val parts = ArrayList<String>()
    when (item.type) {
        Type.LIVE -> parts.add("LIVE")
        Type.MOVIE -> parts.add("Film")
        Type.SERIES -> parts.add("Serie")
        Type.EPISODE -> parts.add("Aflevering ${item.num}")
        Type.CATCHUP -> parts.add("Terugkijken")
    }
    val year = d?.year?.ifEmpty { null } ?: item.year
    if (year.isNotEmpty()) parts.add(year)
    val rating = (d?.rating?.ifEmpty { null } ?: item.rating).toDoubleOrNull()
    if (rating != null && rating > 0) parts.add("★ " + String.format(java.util.Locale.US, "%.1f", rating))
    val genre = d?.genre ?: ""
    if (genre.isNotEmpty()) parts.add(genre)
    val dur = d?.duration ?: ""
    if (dur.isNotEmpty()) parts.add(dur)
    return parts.joinToString("   •   ")
}
