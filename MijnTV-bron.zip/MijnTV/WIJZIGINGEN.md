# Wijzigingen MijnTV

Versienummering: 1.00, 1.01, 1.02 … Grote vernieuwingen worden 2.00.

## 1.01
- Geluidsvertraging bij VLC, standaard −125 ms (zoals in DreamPlayer)
- Tijdens live kijken via VLC: OK lang indrukken om het geluid gelijk te zetten (stappen van 25 ms)
- Instelbaar bij Instellingen → Geluidsvertraging VLC

## 1.00
Eerste officiële versie.

**Algemeen**
- Inloggen met Xtream Codes; meerdere providers, snel wisselen (één tegelijk zichtbaar)
- Vu+ / Enigma2-ontvanger als provider (alleen MijnTV)
- Profielen ("Wie kijkt er?"), kopiëren van het hoofdprofiel zonder Trakt en kijkgeschiedenis, standaardprofiel
- Automatisch starten met de Shield en direct de laatste zender
- Afspelen stopt als de Shield uitgaat, zodat de tv weer mee aangaat
- Twee versies: MijnTV (alles) en MijnTV Public (zonder Trakt, Nuvio en Vu+; eigen TMDB-sleutel)

**Films en series**
- Netflix-stijl met afgeronde tegels, Nederlandse metadata via TMDB
- Detailpagina's met acteurs, acteurpagina's en aanraders
- Series met seizoenen en alle afleveringen, Nederlandse beschrijvingen, gekeken-markering
- "Verder kijken" op het startscherm, geen dubbele rijen
- Sortering, groepen verbergen, vastzetten en herschikken

**Live tv**
- TiviMate-stijl: groepen, zenders met nu/straks, voorbeeldbeeld, programmalijst
- EPG-gids, terugkijken (catch-up), zenderlijst en infobalk in beeld
- Kanaalnummers per boeket vanaf 1, lijst volgt de gezapte zender
- Nederlands geluid standaard, ondertitels bij live standaard uit
- VLC als speler (Vu+ automatisch via VLC), instelbaar: Automatisch / ExoPlayer / VLC

**Ondertitels**
- Aan/uit, laag in beeld, drie groottes
- Downloaden via OpenSubtitles (VIP)

**Koppelingen (alleen MijnTV)**
- Trakt: lijsten op het startscherm, gekeken-status in twee richtingen, verder kijken
- Nuvio voor titels die je provider niet heeft
