# Wijzigingen MijnTV

Versienummering: 1.00, 1.01, 1.02 … Grote vernieuwingen worden 2.00.
Alles geldt voor MijnTV én MijnTV Public, tenzij er "(alleen MijnTV)" bij staat.

## 1.04
- Cloud-back-up via Google Drive: providers, instellingen, profielen, API-sleutels en kijkvoortgang
- Alles versleuteld met een eigen pincode
- Nieuw apparaat: "Herstellen vanuit Google Drive" op het inlogscherm zet alles identiek terug
- Kijkvoortgang wordt tussen apparaten gedeeld (na afspelen en bij openen van de app)
- Trakt-koppeling en apparaat-eigen zaken (laatste zender, gedownloade ondertitels) blijven per apparaat

## 1.03
- Live tv: in de programmalijst nog een keer naar rechts → volledige gids van die zender, per dag tot een week terug
- Terugkijken direct te kiezen in die gids (⏪), programma van nu speelt live af
- Beveiliging: twee keer terug om MijnTV te sluiten, met melding na de eerste keer

## 1.02 (alleen MijnTV)
- Trakt: gekeken afleveringen worden per serie vers opgehaald bij het openen van de seriepagina
- Klopt het TMDB-nummer van de provider niet, dan zoekt MijnTV de serie bij Trakt op titel (en jaar)
- Ophalen van grote Trakt-geschiedenis mag langer duren (geen lege lijst meer bij veel gekeken)

## 1.01
- Geluidsvertraging bij VLC, standaard −125 ms
- Tijdens live kijken via VLC: OK lang indrukken om het geluid gelijk te zetten (stappen van 25 ms)
- Instelbaar bij Instellingen → Geluidsvertraging VLC

## 1.00
Eerste officiële versie.

**Algemeen**
- Inloggen met Xtream Codes; meerdere providers, snel wisselen (één tegelijk zichtbaar)
- Vu+ / Enigma2-ontvanger als provider (alleen MijnTV)
- Profielen ("Wie kijkt er?"), kopiëren van het hoofdprofiel zonder Trakt en kijkgeschiedenis, standaardprofiel
- Automatisch starten met de Shield en direct de laatste zender
- Afspelen stopt als de Shield uitgaat, zodat de tv weer mee aangaat
- Twee versies: MijnTV (alles) en MijnTV Public (zonder Trakt, Nuvio en Vu+; eigen TMDB-sleutel)

**Films en series**
- Netflix-stijl met afgeronde tegels, Nederlandse metadata via TMDB
- Detailpagina's met acteurs, acteurpagina's en aanraders
- Series met seizoenen en alle afleveringen, Nederlandse beschrijvingen, gekeken-markering
- "Verder kijken" op het startscherm, geen dubbele rijen
- Sortering, groepen verbergen, vastzetten en herschikken

**Live tv**
- TiviMate-stijl: groepen, zenders met nu/straks, voorbeeldbeeld, programmalijst
- EPG-gids, terugkijken (catch-up), zenderlijst en infobalk in beeld
- Kanaalnummers per boeket vanaf 1, lijst volgt de gezapte zender
- Nederlands geluid standaard, ondertitels bij live standaard uit
- VLC als speler (Vu+ automatisch via VLC), instelbaar: Automatisch / ExoPlayer / VLC

**Ondertitels**
- Aan/uit, laag in beeld, drie groottes
- Downloaden via OpenSubtitles (VIP)

**Koppelingen (alleen MijnTV)**
- Trakt: lijsten op het startscherm, gekeken-status in twee richtingen, verder kijken
- Nuvio voor titels die je provider niet heeft
