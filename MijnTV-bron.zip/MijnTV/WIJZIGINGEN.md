# Wijzigingen MijnTV

Versienummering: 1.00, 1.01, 1.02 … Grote vernieuwingen worden 2.00.
Alles geldt voor MijnTV én MijnTV Public, tenzij er "(alleen MijnTV)" bij staat.

## 1.11
- Oorzaak van het afsluiten bij Home en OK lang indrukken opgelost: de koppeling tussen Trakt en je bibliotheek wordt nu op de achtergrond opgebouwd
- Titels opschonen gaat veel sneller (merkbaar bij grote bibliotheken met 4 providers)

## 1.10
- Crash bij OK lang indrukken en bij Home aangepakt; fouten worden voortaan gemeld in plaats van dat de app afsluit
- Na een crash toont MijnTV bij de volgende start de foutmelding (om op te sturen)

## 1.09
- "Verder kijken": OK lang indrukken → Verwijderen uit Verder kijken (ook bij Trakt weg)
- Films en series van grote providers worden zuiniger ingeladen (stuk voor stuk), zodat ook de 4e provider meedoet bij zoeken
- Melding als films/series van een provider niet geladen konden worden

## 1.08
- Live tv: in de groepen nog een keer naar links → kolom met providers; kies een provider en je ziet direct zijn groepen
- Providerkolom begint met "★ Favorieten": al je favoriete groepen en zenders van alle providers samen
- Favoriete groepen staan per provider bij elkaar helemaal bovenaan
- ⚽ Matchcenter verplaatst naar het hoofdmenu, met het echte speelschema (Eredivisie, KKD, KNVB Beker, Europese bekers, topcompetities, interlands) en live stand
- Bij elke wedstrijd zoekt MijnTV de zender(s) in je tv-gids
- Zoeken doorzoekt nu alle providers (rijen per provider)

## 1.07
- Films en series: knop "⛶ Beeld" in de speler (passend / inzoomen / uitrekken) tegen zwarte balken; keuze wordt onthouden

## 1.06
- Live tv: alle providers links onder elkaar met een kopje per provider, zonder te wisselen (zoals MYTVOnline 3)
- ⚽ Matchcenter (knop bovenin bij Live tv): voetbalwedstrijden uit de tv-gids, met zender; live direct kijken
- 🎬 Trailer-knop bij films en series (via YouTube)
- Weekgids per zender kijkt nu ook vooruit naar de komende dagen
- Teruggekeken dagen beginnen bovenaan bij het begin van de dag
- Programmalijst in het live-overzicht toont alleen nu en straks; terugkijken zit in de weekgids (→→)

## 1.05
- Updatemelding: bij een nieuwe versie verschijnt een melding met de wijzigingen en een knop Installeren
- Handmatig zoeken via Instellingen → Controleren op updates
- Terug-knop diep in de rijen springt direct naar het menu bovenaan (geen tien keer omhoog meer)

## 1.04
- Cloud-back-up via Google Drive: providers, instellingen, profielen, API-sleutels en kijkvoortgang
- Alles versleuteld met een eigen pincode
- Nieuw apparaat: "Herstellen vanuit Google Drive" op het inlogscherm zet alles identiek terug
- Kijkvoortgang wordt tussen apparaten gedeeld (na afspelen en bij openen van de app)
- Trakt-koppeling en apparaat-eigen zaken (laatste zender, gedownloade ondertitels) blijven per apparaat

## 1.03
- Live tv: in de programmalijst nog een keer naar rechts → volledige gids van die zender, per dag tot een week terug
- Terugkijken direct te kiezen in die gids (⏪), programma van nu speelt live af
- Beveiliging: twee keer terug om MijnTV te sluiten, met melding na de eerste keer

## 1.02 (alleen MijnTV)
- Trakt: gekeken afleveringen worden per serie vers opgehaald bij het openen van de seriepagina
- Klopt het TMDB-nummer van de provider niet, dan zoekt MijnTV de serie bij Trakt op titel (en jaar)
- Ophalen van grote Trakt-geschiedenis mag langer duren (geen lege lijst meer bij veel gekeken)

## 1.01
- Geluidsvertraging bij VLC, standaard −125 ms
- Tijdens live kijken via VLC: OK lang indrukken om het geluid gelijk te zetten (stappen van 25 ms)
- Instelbaar bij Instellingen → Geluidsvertraging VLC

## 1.00
Eerste officiële versie.

**Algemeen**
- Inloggen met Xtream Codes; meerdere providers, snel wisselen (één tegelijk zichtbaar)
- Vu+ / Enigma2-ontvanger als provider (alleen MijnTV)
- Profielen ("Wie kijkt er?"), kopiëren van het hoofdprofiel zonder Trakt en kijkgeschiedenis, standaardprofiel
- Automatisch starten met de Shield en direct de laatste zender
- Afspelen stopt als de Shield uitgaat, zodat de tv weer mee aangaat
- Twee versies: MijnTV (alles) en MijnTV Public (zonder Trakt, Nuvio en Vu+; eigen TMDB-sleutel)

**Films en series**
- Netflix-stijl met afgeronde tegels, Nederlandse metadata via TMDB
- Detailpagina's met acteurs, acteurpagina's en aanraders
- Series met seizoenen en alle afleveringen, Nederlandse beschrijvingen, gekeken-markering
- "Verder kijken" op het startscherm, geen dubbele rijen
- Sortering, groepen verbergen, vastzetten en herschikken

**Live tv**
- TiviMate-stijl: groepen, zenders met nu/straks, voorbeeldbeeld, programmalijst
- EPG-gids, terugkijken (catch-up), zenderlijst en infobalk in beeld
- Kanaalnummers per boeket vanaf 1, lijst volgt de gezapte zender
- Nederlands geluid standaard, ondertitels bij live standaard uit
- VLC als speler (Vu+ automatisch via VLC), instelbaar: Automatisch / ExoPlayer / VLC

**Ondertitels**
- Aan/uit, laag in beeld, drie groottes
- Downloaden via OpenSubtitles (VIP)

**Koppelingen (alleen MijnTV)**
- Trakt: lijsten op het startscherm, gekeken-status in twee richtingen, verder kijken
- Nuvio voor titels die je provider niet heeft
