# MijnTV – IPTV-app voor Android & Android TV

Streaming-stijl: grote banner, poster-rijen, Verder kijken, Mijn lijst, tv-gids, serie-detailpagina

## APK laten bouwen via GitHub (gratis, geen software nodig)
1. Maak een gratis account op github.com en kies **New repository** (naam bijv. `mijntv`, zet hem op **Public** als je de APK direct op je tv wilt downloaden).
2. Klik **uploading an existing file** en sleep de **inhoud** van deze map erin (dus `app`, `gradle`, `.github`, `gradlew` enz.). Klik **Commit changes**.
   - Tip: zie je de map `.github` niet? Zet "verborgen bestanden tonen" aan in je verkenner.
3. Ga naar het tabblad **Actions**: de build start vanzelf (± 5 min).
4. Klaar? Rechts op de repo-pagina onder **Releases** staat `MijnTV.apk`.

## Installeren op Android TV / Google TV
1. Installeer de app **Downloader** (AFTVnews) uit de Play Store.
2. Sta in Instellingen → Apps → Beveiliging "Onbekende apps installeren" toe voor Downloader.
3. Typ in Downloader:
   `https://github.com/JOUW-NAAM/mijntv/releases/latest/download/MijnTV.apk`
4. Installeren → MijnTV verschijnt in je apps.

## Alternatief: Android Studio op je pc
Open deze map in Android Studio → Build → Build APK(s).

## Bediening
- **OK** = openen/afspelen · **OK ingedrukt houden** = toevoegen aan / verwijderen uit Mijn lijst
- Films en afleveringen gaan verder waar je gebleven was
- **Live TV** (TiviMate-stijl): groepen links, zenders met huidig programma, voorbeeldscherm rechts. Knop **Tv-gids** opent het tijdraster.
- In de tv-gids: pijltjes = door de tijd en zenders bladeren, **OK** = zender kijken
- Tijdens live tv: **omhoog/omlaag** of **CH+/CH-** = zappen, **OK** = zenderlijst over het beeld, **links/rechts** = infobalk, **terug** = sluiten
- Favoriete zender: houd **OK** ingedrukt in de zenderlijst
- Series spelen automatisch de volgende aflevering af
- Speelt een zender niet? De app probeert automatisch het andere formaat (TS ↔ HLS) en onthoudt wat werkt.
